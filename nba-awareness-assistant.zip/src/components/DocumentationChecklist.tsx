import React, { useState, useEffect, useMemo } from 'react';
import { 
  CheckSquare, 
  Plus, 
  Search, 
  Filter, 
  Trash2, 
  Edit3, 
  Download, 
  RotateCcw, 
  CheckCircle2, 
  Clock, 
  AlertCircle,
  FolderOpen,
  Calendar,
  User,
  Tag
} from 'lucide-react';
import { ChecklistItem } from '../types';
import { DEFAULT_CHECKLIST } from '../data/nbaKnowledge';

export const DocumentationChecklist: React.FC = () => {
  const [items, setItems] = useState<ChecklistItem[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedStatus, setSelectedStatus] = useState<string>('All');
  const [selectedYear, setSelectedYear] = useState<string>('All');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');

  // Modal / Form state for Add or Edit
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<ChecklistItem | null>(null);

  // Form Fields
  const [formCategory, setFormCategory] = useState('Course files');
  const [formTitle, setFormTitle] = useState('');
  const [formDescription, setFormDescription] = useState('');
  const [formCriterion, setFormCriterion] = useState<number>(3);
  const [formAcademicYear, setFormAcademicYear] = useState('2025-26');
  const [formResponsible, setFormResponsible] = useState('');
  const [formStatus, setFormStatus] = useState<'Not Started' | 'In Progress' | 'Completed'>('Not Started');
  const [formNotes, setFormNotes] = useState('');

  // Categories list
  const categories = [
    'Program Educational Objectives',
    'Program Outcomes and PSOs',
    'Course Outcomes',
    'CO-PO mapping',
    'Course files',
    'Lesson plans',
    'Assessment records',
    'Student performance analysis',
    'Faculty information',
    'Laboratory information',
    'Research and development',
    'Student projects',
    'Industry interaction',
    'Continuous improvement',
    'Departmental quality records'
  ];

  const academicYears = ['2025-26', '2024-25', '2023-24'];

  // Load from server or localStorage
  useEffect(() => {
    fetchChecklist();
  }, []);

  const fetchChecklist = async () => {
    setIsLoading(true);
    try {
      const res = await fetch('/api/checklist');
      if (res.ok) {
        const data = await res.json();
        if (data.items && data.items.length > 0) {
          setItems(data.items);
          localStorage.setItem('nba_checklist_cache', JSON.stringify(data.items));
          setIsLoading(false);
          return;
        }
      }
    } catch (e) {
      console.warn('Backend unavailable, using local cache', e);
    }

    // Fallback to local storage or defaults
    const cached = localStorage.getItem('nba_checklist_cache');
    if (cached) {
      try {
        setItems(JSON.parse(cached));
      } catch {
        setItems(DEFAULT_CHECKLIST);
      }
    } else {
      setItems(DEFAULT_CHECKLIST);
    }
    setIsLoading(false);
  };

  const handleSaveItem = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formTitle.trim()) return;

    const newItem: ChecklistItem = {
      id: editingItem ? editingItem.id : `chk-${Date.now()}`,
      category: formCategory,
      title: formTitle.trim(),
      description: formDescription.trim(),
      criterionNumber: Number(formCriterion) || undefined,
      academicYear: formAcademicYear,
      responsiblePerson: formResponsible.trim() || 'Unassigned',
      status: formStatus,
      lastUpdated: new Date().toISOString().split('T')[0],
      notes: formNotes.trim()
    };

    // Update state immediately
    const updated = editingItem
      ? items.map((i) => (i.id === editingItem.id ? newItem : i))
      : [newItem, ...items];

    setItems(updated);
    localStorage.setItem('nba_checklist_cache', JSON.stringify(updated));
    closeModal();

    // Persist to backend
    try {
      await fetch('/api/checklist', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newItem)
      });
    } catch (err) {
      console.error('Failed to persist to server', err);
    }
  };

  const handleDeleteItem = async (id: string) => {
    if (!window.confirm('Delete this checklist document item?')) return;
    const updated = items.filter((i) => i.id !== id);
    setItems(updated);
    localStorage.setItem('nba_checklist_cache', JSON.stringify(updated));

    try {
      await fetch(`/api/checklist/${id}`, { method: 'DELETE' });
    } catch (err) {
      console.error('Failed to delete on server', err);
    }
  };

  const handleToggleStatus = async (item: ChecklistItem) => {
    const nextStatusMap: Record<string, 'Not Started' | 'In Progress' | 'Completed'> = {
      'Not Started': 'In Progress',
      'In Progress': 'Completed',
      'Completed': 'Not Started'
    };
    const nextStatus = nextStatusMap[item.status];
    const updatedItem = {
      ...item,
      status: nextStatus,
      lastUpdated: new Date().toISOString().split('T')[0]
    };

    const updated = items.map((i) => (i.id === item.id ? updatedItem : i));
    setItems(updated);
    localStorage.setItem('nba_checklist_cache', JSON.stringify(updated));

    try {
      await fetch('/api/checklist', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updatedItem)
      });
    } catch (err) {
      console.error('Failed to sync status', err);
    }
  };

  const handleResetDefaults = async () => {
    if (window.confirm('Reset checklist to standard NBA Criteria template? Any custom items will be overwritten.')) {
      setItems(DEFAULT_CHECKLIST);
      localStorage.setItem('nba_checklist_cache', JSON.stringify(DEFAULT_CHECKLIST));
      try {
        await fetch('/api/checklist/reset', { method: 'POST' });
      } catch (err) {
        console.error('Failed to reset on server', err);
      }
    }
  };

  const openAddModal = () => {
    setEditingItem(null);
    setFormCategory('Course files');
    setFormTitle('');
    setFormDescription('');
    setFormCriterion(3);
    setFormAcademicYear('2025-26');
    setFormResponsible('');
    setFormStatus('Not Started');
    setFormNotes('');
    setIsModalOpen(true);
  };

  const openEditModal = (item: ChecklistItem) => {
    setEditingItem(item);
    setFormCategory(item.category);
    setFormTitle(item.title);
    setFormDescription(item.description);
    setFormCriterion(item.criterionNumber || 1);
    setFormAcademicYear(item.academicYear);
    setFormResponsible(item.responsiblePerson);
    setFormStatus(item.status);
    setFormNotes(item.notes);
    setIsModalOpen(true);
  };

  const closeModal = () => {
    setIsModalOpen(false);
    setEditingItem(null);
  };

  // Filtered and Searched Items
  const filteredItems = useMemo(() => {
    return items.filter((item) => {
      const matchSearch =
        item.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.responsiblePerson.toLowerCase().includes(searchQuery.toLowerCase());

      const matchStatus = selectedStatus === 'All' || item.status === selectedStatus;
      const matchYear = selectedYear === 'All' || item.academicYear === selectedYear;
      const matchCategory = selectedCategory === 'All' || item.category === selectedCategory;

      return matchSearch && matchStatus && matchYear && matchCategory;
    });
  }, [items, searchQuery, selectedStatus, selectedYear, selectedCategory]);

  // Completion Stats
  const totalCount = items.length;
  const completedCount = items.filter((i) => i.status === 'Completed').length;
  const inProgressCount = items.filter((i) => i.status === 'In Progress').length;
  const notStartedCount = items.filter((i) => i.status === 'Not Started').length;
  const completionPercentage = totalCount > 0 ? Math.round((completedCount / totalCount) * 100) : 0;

  // Export CSV
  const handleExportCSV = () => {
    const rows = [
      ['Title', 'Category', 'Criterion', 'Academic Year', 'Responsible Faculty', 'Status', 'Last Updated', 'Notes'],
      ...items.map((i) => [
        `"${i.title.replace(/"/g, '""')}"`,
        `"${i.category}"`,
        i.criterionNumber || '-',
        i.academicYear,
        `"${i.responsiblePerson}"`,
        i.status,
        i.lastUpdated,
        `"${i.notes.replace(/"/g, '""')}"`
      ])
    ];

    const csvContent = 'data:text/csv;charset=utf-8,' + rows.map((e) => e.join(',')).join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `NBA_Documentation_Checklist_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-8 pb-16">
      {/* Page Header */}
      <div className="bg-white p-6 sm:p-8 rounded-xl border border-slate-200 shadow-xs flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-2 text-xs font-semibold text-teal-700 tracking-wide uppercase">
            <span>Accreditation Audit Preparedness</span>
            <span aria-hidden="true">·</span>
            <span>Criterion 1 to 10 Evidence</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 mt-1">
            Departmental Documentation Checklist
          </h1>
          <p className="text-xs sm:text-sm text-slate-600 mt-1">
            Track and verify all 14 mandatory exhibit categories required by the NBA Visiting Team.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={openAddModal}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold shadow-xs transition-colors"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Add Checklist Item</span>
          </button>
          <button
            onClick={handleExportCSV}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-teal-600 hover:bg-teal-700 text-white text-xs font-semibold shadow-xs transition-colors"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export CSV</span>
          </button>
          <button
            onClick={handleResetDefaults}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold border border-slate-200 transition-colors"
            title="Reset to official template"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Reset Template</span>
          </button>
        </div>
      </div>

      {/* Progress & Completion Metrics Bar */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs">
          <div className="text-xs text-slate-500 font-medium">Audit Readiness</div>
          <div className="mt-1 flex items-baseline gap-2">
            <span className="text-2xl font-bold font-mono text-teal-700">{completionPercentage}%</span>
            <span className="text-xs text-slate-500">Completed</span>
          </div>
          <div className="w-full bg-slate-100 rounded-full h-2 mt-2">
            <div
              className="bg-teal-600 h-2 rounded-full transition-all"
              style={{ width: `${completionPercentage}%` }}
            />
          </div>
        </div>

        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs">
          <div className="text-xs text-slate-500 font-medium">Completed Documents</div>
          <div className="mt-1 text-2xl font-bold font-mono text-slate-900">{completedCount}</div>
          <div className="text-xs text-emerald-700 mt-1 flex items-center gap-1">
            <CheckCircle2 className="w-3 h-3" />
            <span>Verified and Bound</span>
          </div>
        </div>

        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs">
          <div className="text-xs text-slate-500 font-medium">In Progress</div>
          <div className="mt-1 text-2xl font-bold font-mono text-amber-700">{inProgressCount}</div>
          <div className="text-xs text-amber-600 mt-1 flex items-center gap-1">
            <Clock className="w-3 h-3" />
            <span>Under Peer Review</span>
          </div>
        </div>

        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs">
          <div className="text-xs text-slate-500 font-medium">Not Started</div>
          <div className="mt-1 text-2xl font-bold font-mono text-slate-500">{notStartedCount}</div>
          <div className="text-xs text-slate-400 mt-1">Pending allocation</div>
        </div>
      </div>

      {/* Search and Filters Toolbar */}
      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs flex flex-wrap items-center justify-between gap-4">
        {/* Search Input */}
        <div className="relative flex-1 min-w-[240px]">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search document title, description, or faculty name..."
            className="w-full pl-9 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs sm:text-sm text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-1 focus:ring-teal-500"
          />
        </div>

        {/* Filter Dropdowns */}
        <div className="flex flex-wrap items-center gap-2">
          {/* Status Filter */}
          <select
            value={selectedStatus}
            onChange={(e) => setSelectedStatus(e.target.value)}
            className="px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs font-semibold text-slate-700 focus:outline-none focus:ring-1 focus:ring-teal-500"
          >
            <option value="All">All Statuses</option>
            <option value="Completed">Completed</option>
            <option value="In Progress">In Progress</option>
            <option value="Not Started">Not Started</option>
          </select>

          {/* Academic Year Filter */}
          <select
            value={selectedYear}
            onChange={(e) => setSelectedYear(e.target.value)}
            className="px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs font-semibold text-slate-700 focus:outline-none focus:ring-1 focus:ring-teal-500 font-mono"
          >
            <option value="All">All Academic Years</option>
            {academicYears.map((yr) => (
              <option key={yr} value={yr}>{yr}</option>
            ))}
          </select>

          {/* Category Filter */}
          <select
            value={selectedCategory}
            onChange={(e) => setSelectedCategory(e.target.value)}
            className="px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs font-semibold text-slate-700 focus:outline-none focus:ring-1 focus:ring-teal-500 max-w-[180px] truncate"
          >
            <option value="All">All 14 Categories</option>
            {categories.map((cat) => (
              <option key={cat} value={cat}>{cat}</option>
            ))}
          </select>
        </div>
      </div>

      {/* Checklist Items Table */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="p-4 bg-slate-50 border-b border-slate-200 flex items-center justify-between text-xs text-slate-600 font-semibold">
          <span>Showing {filteredItems.length} of {totalCount} documented exhibits</span>
          <span className="text-[11px] text-slate-400">Click any status pill to toggle progress</span>
        </div>

        {filteredItems.length === 0 ? (
          <div className="p-12 text-center text-slate-500 space-y-2">
            <FolderOpen className="w-10 h-10 text-slate-300 mx-auto" />
            <div className="text-sm font-semibold text-slate-700">No checklist items found</div>
            <p className="text-xs text-slate-400">Try modifying your search or filter parameters.</p>
          </div>
        ) : (
          <div className="divide-y divide-slate-100">
            {filteredItems.map((item) => (
              <div key={item.id} className="p-4 sm:p-5 flex flex-col md:flex-row md:items-center justify-between gap-4 hover:bg-slate-50/50 transition-colors">
                <div className="space-y-1.5 flex-1">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="text-xs font-semibold text-teal-800 bg-teal-50 px-2 py-0.5 rounded">
                      {item.category}
                    </span>
                    {item.criterionNumber && (
                      <span className="text-xs font-mono text-slate-500">
                        Criterion {item.criterionNumber}
                      </span>
                    )}
                    <span className="text-slate-300">·</span>
                    <span className="text-xs font-mono text-slate-500">{item.academicYear}</span>
                  </div>

                  <h3 className="text-sm sm:text-base font-bold text-slate-900">{item.title}</h3>
                  <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">{item.description}</p>

                  <div className="flex flex-wrap items-center gap-4 text-xs text-slate-500 pt-1">
                    <div className="flex items-center gap-1">
                      <User className="w-3 h-3 text-slate-400" />
                      <span>{item.responsiblePerson}</span>
                    </div>
                    <span>·</span>
                    <div className="flex items-center gap-1">
                      <Calendar className="w-3 h-3 text-slate-400" />
                      <span className="font-mono">Updated: {item.lastUpdated}</span>
                    </div>
                    {item.notes && (
                      <>
                        <span>·</span>
                        <span className="text-slate-600 italic">"{item.notes}"</span>
                      </>
                    )}
                  </div>
                </div>

                <div className="flex items-center gap-3 shrink-0 self-start md:self-center">
                  {/* Status Toggle Button */}
                  <button
                    onClick={() => handleToggleStatus(item)}
                    className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all border ${
                      item.status === 'Completed'
                        ? 'bg-emerald-50 text-emerald-800 border-emerald-200 hover:bg-emerald-100'
                        : item.status === 'In Progress'
                        ? 'bg-amber-50 text-amber-800 border-amber-200 hover:bg-amber-100'
                        : 'bg-slate-100 text-slate-700 border-slate-200 hover:bg-slate-200'
                    }`}
                  >
                    {item.status}
                  </button>

                  <button
                    onClick={() => openEditModal(item)}
                    className="p-1.5 rounded-md text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors"
                    title="Edit Item"
                  >
                    <Edit3 className="w-4 h-4" />
                  </button>

                  <button
                    onClick={() => handleDeleteItem(item.id)}
                    className="p-1.5 rounded-md text-slate-400 hover:text-red-600 hover:bg-red-50 transition-colors"
                    title="Delete Item"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Add / Edit Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-xs">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl border border-slate-200 animate-in fade-in zoom-in-95">
            <h2 className="text-lg font-bold text-slate-900 mb-4">
              {editingItem ? 'Edit Checklist Document' : 'Add New Checklist Document'}
            </h2>

            <form onSubmit={handleSaveItem} className="space-y-4 text-xs">
              <div>
                <label className="block text-slate-600 font-semibold mb-1">Document Category</label>
                <select
                  value={formCategory}
                  onChange={(e) => setFormCategory(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 font-medium"
                >
                  {categories.map((c) => (
                    <option key={c} value={c}>{c}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-slate-600 font-semibold mb-1">Document Title *</label>
                <input
                  type="text"
                  required
                  value={formTitle}
                  onChange={(e) => setFormTitle(e.target.value)}
                  placeholder="e.g. Course Outcomes and Lesson Delivery Log"
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900"
                />
              </div>

              <div>
                <label className="block text-slate-600 font-semibold mb-1">Description</label>
                <textarea
                  rows={2}
                  value={formDescription}
                  onChange={(e) => setFormDescription(e.target.value)}
                  placeholder="Details of required artifacts, signatures, or university proofs..."
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-600 font-semibold mb-1">Related Criterion (1-10)</label>
                  <input
                    type="number"
                    min="1"
                    max="10"
                    value={formCriterion}
                    onChange={(e) => setFormCriterion(Number(e.target.value))}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 font-mono"
                  />
                </div>
                <div>
                  <label className="block text-slate-600 font-semibold mb-1">Academic Year</label>
                  <select
                    value={formAcademicYear}
                    onChange={(e) => setFormAcademicYear(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 font-mono"
                  >
                    {academicYears.map((y) => (
                      <option key={y} value={y}>{y}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-600 font-semibold mb-1">Responsible Person / Cell</label>
                  <input
                    type="text"
                    value={formResponsible}
                    onChange={(e) => setFormResponsible(e.target.value)}
                    placeholder="e.g. Course Coordinator, HOD"
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900"
                  />
                </div>
                <div>
                  <label className="block text-slate-600 font-semibold mb-1">Status</label>
                  <select
                    value={formStatus}
                    onChange={(e) => setFormStatus(e.target.value as any)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 font-semibold"
                  >
                    <option value="Not Started">Not Started</option>
                    <option value="In Progress">In Progress</option>
                    <option value="Completed">Completed</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-slate-600 font-semibold mb-1">Audit Notes</label>
                <input
                  type="text"
                  value={formNotes}
                  onChange={(e) => setFormNotes(e.target.value)}
                  placeholder="Optional notes on file binding, digital backups, etc."
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900"
                />
              </div>

              <div className="pt-3 border-t border-slate-200 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={closeModal}
                  className="px-4 py-2 rounded-lg text-slate-600 hover:bg-slate-100 font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-lg bg-slate-900 hover:bg-slate-800 text-white font-semibold"
                >
                  Save Document
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
