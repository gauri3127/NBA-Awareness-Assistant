import React, { useState } from 'react';
import { 
  Award, 
  CheckCircle2, 
  Calendar, 
  Users, 
  FileText, 
  ShieldCheck, 
  Building2, 
  Clock, 
  HelpCircle,
  ExternalLink,
  ChevronRight
} from 'lucide-react';

export const AccreditationCenter: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'intro' | 'process' | 'preparation' | 'roles'>('intro');

  const peerVisitSchedule = [
    {
      day: 'Day 0 (Evening)',
      title: 'Pre-Visit Briefing & Team Coordination',
      activities: [
        'Visiting team arrives and convenes internal coordination meeting.',
        'Chairman and evaluators review pre-submitted SAR observations and divide criterion assignments.'
      ]
    },
    {
      day: 'Day 1 (Morning & Afternoon)',
      title: 'Presentations, Infrastructure & Lab Audits',
      activities: [
        'Presentation by Head of Institution (Principal/Director) on central facilities.',
        'Comprehensive presentation by Head of Department (HOD) on vision, curriculum, and attainment.',
        'Physical inspection of departmental laboratories, project labs, computing center, and safety equipment.',
        'Interaction with faculty members (without management present) regarding OBE execution and workload.'
      ]
    },
    {
      day: 'Day 2 (Full Day)',
      title: 'Stakeholder Interaction & File Verification',
      activities: [
        'Separate closed-door interviews with current students, alumni, parents, and industry employers.',
        'Detailed scrutiny of Course Files (Criteria 3 & 4), sample answer sheets, and assignment rubrics.',
        'Audit of faculty payroll, appointment orders, and research publications (Criterion 5).',
        'Inspection of central facilities: Central Library, Training & Placement cell, Hostel, Medical, Sports.'
      ]
    },
    {
      day: 'Day 3 (Morning)',
      title: 'Exit Meeting & Report Compilation',
      activities: [
        'Peer team finalizes evaluation scores and marks in the confidential report.',
        'Briefing exit meeting with the Principal, HOD, and NBA coordinator to share qualitative strengths and areas of improvement (no scores disclosed).',
        'Submission of report to NBA Headquarters for review by the Moderation Committee and EAC.'
      ]
    }
  ];

  const committeeRoles = [
    {
      name: 'Departmental Advisory Board (DAB)',
      members: 'HOD, Senior Faculty, Industry Experts, Alumni, Academicians from premier institutes.',
      responsibility: 'Reviews and approves the department’s Vision, Mission, and Program Educational Objectives (PEOs). Meets annually to evaluate long-term educational impact.'
    },
    {
      name: 'Program Assessment Committee (PAC)',
      members: 'HOD, NBA Coordinator, Module Coordinators, Senior Professors.',
      responsibility: 'Monitors the attainment of Course Outcomes (COs) and Program Outcomes (POs). Identifies attainment gaps and formulates the annual Continuous Quality Improvement (CQI) Action Plan.'
    },
    {
      name: 'Course Coordinator',
      members: 'Individual faculty member assigned to a specific course.',
      responsibility: 'Formulates Bloom-compliant Course Outcomes, ensures syllabus coverage, designs question papers with CO mapping, computes direct CO attainment, and maintains the physical course file.'
    },
    {
      name: 'Module Coordinator',
      members: 'Senior faculty overseeing a cluster of related courses (e.g. Systems, Theory, Data Science).',
      responsibility: 'Ensures vertical alignment between prerequisite courses and advanced electives, avoids curricular redundancy, and reviews assessment question paper standards.'
    }
  ];

  return (
    <div className="space-y-8 pb-16">
      {/* Header */}
      <div className="bg-white p-6 sm:p-8 rounded-xl border border-slate-200 shadow-xs flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-2 text-xs font-semibold text-teal-700 tracking-wide uppercase">
            <span>Accreditation Roadmap</span>
            <span aria-hidden="true">·</span>
            <span>Lifecycle & Preparation</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 mt-1">
            NBA Accreditation Learning Center
          </h1>
          <p className="text-xs sm:text-sm text-slate-600 mt-1">
            A comprehensive guide covering the accreditation lifecycle, peer team visit protocols, and committee roles.
          </p>
        </div>

        {/* Tab Buttons */}
        <div className="flex flex-wrap items-center gap-2 border-b border-slate-200 pb-2">
          <button
            onClick={() => setActiveTab('intro')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
              activeTab === 'intro' ? 'bg-slate-900 text-white' : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            Introduction to NBA
          </button>
          <button
            onClick={() => setActiveTab('process')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
              activeTab === 'process' ? 'bg-slate-900 text-white' : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            Accreditation Process & Visit
          </button>
          <button
            onClick={() => setActiveTab('preparation')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
              activeTab === 'preparation' ? 'bg-slate-900 text-white' : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            Institutional Preparation
          </button>
          <button
            onClick={() => setActiveTab('roles')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
              activeTab === 'roles' ? 'bg-slate-900 text-white' : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            Committee Responsibilities
          </button>
        </div>
      </div>

      {/* Tab 1: Intro */}
      {activeTab === 'intro' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-xs space-y-4">
              <h2 className="text-base font-bold text-slate-900">What is the National Board of Accreditation?</h2>
              <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
                The National Board of Accreditation (NBA) is an autonomous Indian accreditation agency established by AICTE in 1994, which became an independent statutory body in 2010. NBA evaluates technical and professional education programs (Engineering, Technology, Management, Pharmacy, Architecture, and Applied Arts) at diploma, undergraduate, and postgraduate levels.
              </p>
              <div className="p-4 rounded-lg bg-teal-50 border border-teal-200 text-xs text-teal-950 space-y-1">
                <span className="font-bold">Washington Accord Signatory Status:</span>
                <p>
                  India became a permanent signatory to the prestigious Washington Accord on June 13, 2014. Engineering programs accredited under NBA Tier-I enjoy reciprocal global recognition across member nations (USA, UK, Canada, Australia, Japan, Singapore, etc.).
                </p>
              </div>
            </div>

            <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-xs space-y-4">
              <h2 className="text-base font-bold text-slate-900">Key Benefits of NBA Accreditation</h2>
              <ul className="space-y-2.5 text-xs sm:text-sm text-slate-700">
                <li className="flex items-start gap-2">
                  <CheckCircle2 className="w-4 h-4 text-teal-600 shrink-0 mt-0.5" />
                  <span><strong>Global Degree Mobility:</strong> Degrees from Tier-I accredited programs are accepted internationally for professional licensure and higher studies.</span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle2 className="w-4 h-4 text-teal-600 shrink-0 mt-0.5" />
                  <span><strong>Funding & Autonomy Eligibility:</strong> AICTE, UGC, and funding agencies prioritize accredited departments for MODROB, research grants, and autonomous status.</span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle2 className="w-4 h-4 text-teal-600 shrink-0 mt-0.5" />
                  <span><strong>Quality Assurance:</strong> Shifts teaching-learning from rote textbook delivery to measurable student competencies and industry-aligned skills.</span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle2 className="w-4 h-4 text-teal-600 shrink-0 mt-0.5" />
                  <span><strong>Industry Placement Edge:</strong> Top multinational recruiters prioritize campuses with accredited branches for campus recruitment.</span>
                </li>
              </ul>
            </div>
          </div>

          {/* NBA vs NAAC Comparison Table */}
          <div className="bg-white rounded-xl border border-slate-200 shadow-xs p-6 space-y-4">
            <h2 className="text-base font-bold text-slate-900">NBA vs NAAC: Understanding the Differences</h2>
            <div className="overflow-x-auto">
              <table className="min-w-full text-xs text-left border border-slate-200">
                <thead className="bg-slate-100 font-bold text-slate-800">
                  <tr>
                    <th className="p-3 border-r border-slate-200">Comparison Dimension</th>
                    <th className="p-3 border-r border-slate-200 bg-teal-50/50 text-teal-950">National Board of Accreditation (NBA)</th>
                    <th className="p-3">National Assessment & Accreditation Council (NAAC)</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200 text-slate-700">
                  <tr>
                    <td className="p-3 font-semibold bg-slate-50 border-r border-slate-200">Level of Evaluation</td>
                    <td className="p-3 border-r border-slate-200 font-semibold text-slate-900">Program-Level (Department specific, e.g. B.Tech CSE, Mech)</td>
                    <td className="p-3">Institutional-Level (The entire college or university as a single unit)</td>
                  </tr>
                  <tr>
                    <td className="p-3 font-semibold bg-slate-50 border-r border-slate-200">Primary Core Philosophy</td>
                    <td className="p-3 border-r border-slate-200">Outcome-Based Education (OBE), CO-PO attainment, graduate competencies</td>
                    <td className="p-3">Comprehensive institutional quality, central governance, infrastructure, extension</td>
                  </tr>
                  <tr>
                    <td className="p-3 font-semibold bg-slate-50 border-r border-slate-200">Scoring Framework</td>
                    <td className="p-3 border-r border-slate-200 font-mono">1000 Marks across 10 Criteria</td>
                    <td className="p-3 font-mono">Cumulative Grade Point Average (CGPA) on 4.0 scale (A++, A+, A, etc.)</td>
                  </tr>
                  <tr>
                    <td className="p-3 font-semibold bg-slate-50 border-r border-slate-200">Accreditation Outcomes</td>
                    <td className="p-3 border-r border-slate-200">Full (6 Years), Provisional (3 Years), or Not Accredited</td>
                    <td className="p-3">Letter Grades: A++ down to C for 5 Years validity</td>
                  </tr>
                  <tr>
                    <td className="p-3 font-semibold bg-slate-50 border-r border-slate-200">International Accord</td>
                    <td className="p-3 border-r border-slate-200">Washington Accord (Signatory since 2014)</td>
                    <td className="p-3">National institutional assessment (No mutual recognition treaty)</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* Tab 2: Accreditation Process & Visit Schedule */}
      {activeTab === 'process' && (
        <div className="space-y-6">
          <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-xs space-y-4">
            <h2 className="text-base font-bold text-slate-900">Step-by-Step Accreditation Lifecycle</h2>
            <div className="grid grid-cols-1 md:grid-cols-6 gap-3 text-xs">
              <div className="p-3 rounded-lg bg-slate-50 border border-slate-200">
                <span className="font-mono font-bold text-teal-700">Step 1</span>
                <div className="font-bold text-slate-900 mt-1">Eligibility Check</div>
                <div className="text-slate-500 mt-0.5">At least two batches graduated from program</div>
              </div>
              <div className="p-3 rounded-lg bg-slate-50 border border-slate-200">
                <span className="font-mono font-bold text-teal-700">Step 2</span>
                <div className="font-bold text-slate-900 mt-1">Pre-Qualifier</div>
                <div className="text-slate-500 mt-0.5">SFR, Ph.D. faculty, HOD qualification verified</div>
              </div>
              <div className="p-3 rounded-lg bg-slate-50 border border-slate-200">
                <span className="font-mono font-bold text-teal-700">Step 3</span>
                <div className="font-bold text-slate-900 mt-1">SAR Submission</div>
                <div className="text-slate-500 mt-0.5">Comprehensive data across Criteria 1–10</div>
              </div>
              <div className="p-3 rounded-lg bg-teal-50 border border-teal-200">
                <span className="font-mono font-bold text-teal-800">Step 4</span>
                <div className="font-bold text-slate-900 mt-1">Peer Team Visit</div>
                <div className="text-slate-600 mt-0.5">3-day on-site rigorous evaluation audit</div>
              </div>
              <div className="p-3 rounded-lg bg-slate-50 border border-slate-200">
                <span className="font-mono font-bold text-teal-700">Step 5</span>
                <div className="font-bold text-slate-900 mt-1">Moderation & EAC</div>
                <div className="text-slate-500 mt-0.5">Evaluation committee reviews report</div>
              </div>
              <div className="p-3 rounded-lg bg-slate-50 border border-slate-200">
                <span className="font-mono font-bold text-teal-700">Step 6</span>
                <div className="font-bold text-slate-900 mt-1">Final Award</div>
                <div className="text-slate-500 mt-0.5">6 Years, 3 Years, or Not Accredited</div>
              </div>
            </div>
          </div>

          {/* 3-Day Peer Visit Protocol */}
          <div className="bg-white rounded-xl border border-slate-200 shadow-xs p-6 space-y-4">
            <h2 className="text-base font-bold text-slate-900">Standard 3-Day Peer Team On-Site Audit Schedule</h2>
            <div className="space-y-4">
              {peerVisitSchedule.map((schedule, idx) => (
                <div key={idx} className="p-4 rounded-lg bg-slate-50 border border-slate-200/80 space-y-2">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-bold text-teal-800 uppercase tracking-wide">{schedule.day}</span>
                    <span className="font-semibold text-slate-800">{schedule.title}</span>
                  </div>
                  <ul className="space-y-1 text-xs text-slate-600 pl-4 list-disc">
                    {schedule.activities.map((act, aIdx) => (
                      <li key={aIdx} className="leading-relaxed">{act}</li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Tab 3: Institutional Preparation */}
      {activeTab === 'preparation' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-xs space-y-4">
            <h2 className="text-base font-bold text-slate-900">Course File Preparation (Criterion 3 Exhibitions)</h2>
            <p className="text-xs text-slate-600">
              The peer visiting team randomly inspects course files for 4–6 courses across odd and even semesters. Ensure each course file includes:
            </p>
            <ol className="space-y-2 text-xs sm:text-sm text-slate-700 list-decimal pl-4">
              <li>Course Syllabus, Objectives, and defined Course Outcomes (COs).</li>
              <li>Academic calendar, teaching plan, and actual lesson delivery log.</li>
              <li>CO-PO mapping matrix with signed justification notes.</li>
              <li>Internal test question papers mapped to COs and Bloom cognitive levels.</li>
              <li>Sample student answer scripts (2 best, 2 average, 2 weak categories).</li>
              <li>Assignment question sheets, rubrics, and evaluated submissions.</li>
              <li>Laboratory journal index, continuous assessment rubrics, and experiment logs.</li>
              <li>CO attainment calculation sheet and action taken on past gaps.</li>
            </ol>
          </div>

          <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-xs space-y-4">
            <h2 className="text-base font-bold text-slate-900">Laboratory & Infrastructure Readiness</h2>
            <ul className="space-y-2.5 text-xs sm:text-sm text-slate-700">
              <li className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-teal-600 shrink-0 mt-0.5" />
                <span><strong>Stock Registers:</strong> Ensure dead stock and consumable registers are up to date with purchase invoices and calibration certificates.</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-teal-600 shrink-0 mt-0.5" />
                <span><strong>Safety Protocol:</strong> Functional fire extinguishers, first aid kits, earthing certificates, and safety signboards in all labs.</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-teal-600 shrink-0 mt-0.5" />
                <span><strong>Licensed & Open-Source Software:</strong> Legitimate license agreements or clear open-source documentation for all lab tools.</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-teal-600 shrink-0 mt-0.5" />
                <span><strong>Beyond-Syllabus Experiments:</strong> Document at least 2 practicals beyond syllabus conducted to bridge industrial gaps.</span>
              </li>
            </ul>
          </div>
        </div>
      )}

      {/* Tab 4: Committee Responsibilities */}
      {activeTab === 'roles' && (
        <div className="space-y-4">
          <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-xs">
            <h2 className="text-base font-bold text-slate-900">Accreditation Committee Architecture</h2>
            <p className="text-xs text-slate-500 mt-1">
              Establishing clear governance and decentralization is mandatory under Criterion 10.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {committeeRoles.map((role, idx) => (
              <div key={idx} className="bg-white p-6 rounded-xl border border-slate-200 shadow-xs space-y-3">
                <div className="flex items-center gap-2">
                  <Users className="w-4 h-4 text-teal-600" />
                  <h3 className="text-sm font-bold text-slate-900">{role.name}</h3>
                </div>
                <div className="text-xs text-slate-600">
                  <span className="font-semibold text-slate-700">Composition: </span>
                  {role.members}
                </div>
                <p className="text-xs sm:text-sm text-slate-700 leading-relaxed bg-slate-50 p-3 rounded-lg border border-slate-200/80">
                  {role.responsibility}
                </p>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
