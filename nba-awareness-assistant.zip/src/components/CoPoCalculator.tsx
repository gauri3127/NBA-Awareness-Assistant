import React, { useState, useMemo } from 'react';
import { 
  Calculator, 
  Download, 
  RotateCcw, 
  Plus, 
  Trash2, 
  Info, 
  HelpCircle, 
  BarChart3, 
  CheckCircle2, 
  AlertTriangle,
  Settings,
  ChevronRight
} from 'lucide-react';
import { SAMPLE_DBMS_COURSE, PROGRAM_OUTCOMES } from '../data/nbaKnowledge';

interface CourseOutcomeItem {
  id: string;
  code: string;
  desc: string;
  targetAttainment: number; // e.g. 2.2
  cieTargetPercent: number; // e.g. 60%
  cieAchievedPercent: number; // e.g. 72%
  seeTargetPercent: number; // e.g. 60%
  seeAchievedPercent: number; // e.g. 68%
  mappings: Record<string, number>; // PO1..PO12, PSO1, PSO2
}

export const CoPoCalculator: React.FC = () => {
  // Configurable Parameters
  const [courseName, setCourseName] = useState('Database Management Systems');
  const [courseCode, setCourseCode] = useState('CS304');
  const [cieWeight, setCieWeight] = useState(30); // 30% CIE
  const [seeWeight, setSeeWeight] = useState(70); // 70% SEE
  const [directWeight, setDirectWeight] = useState(80); // 80% Direct
  const [indirectWeight, setIndirectWeight] = useState(20); // 20% Indirect
  const [calculationMode, setCalculationMode] = useState<'weighted' | 'average'>('weighted');

  // Rubric Level Thresholds (% students meeting target)
  const [level1Threshold, setLevel1Threshold] = useState(50); // 50-59% = Level 1
  const [level2Threshold, setLevel2Threshold] = useState(60); // 60-69% = Level 2
  const [level3Threshold, setLevel3Threshold] = useState(70); // >= 70% = Level 3

  // Course Outcomes State
  const [outcomes, setOutcomes] = useState<CourseOutcomeItem[]>([
    {
      id: 'co-1',
      code: 'CO1',
      desc: 'Explain fundamental database concepts, relational data models, and entity-relationship architecture.',
      targetAttainment: 2.0,
      cieTargetPercent: 60,
      cieAchievedPercent: 78,
      seeTargetPercent: 60,
      seeAchievedPercent: 65,
      mappings: { PO1: 3, PO2: 2, PO3: 1, PO5: 1, PO12: 1, PSO1: 2 }
    },
    {
      id: 'co-2',
      code: 'CO2',
      desc: 'Formulate complex queries using Relational Algebra and Structured Query Language (SQL).',
      targetAttainment: 2.2,
      cieTargetPercent: 60,
      cieAchievedPercent: 82,
      seeTargetPercent: 60,
      seeAchievedPercent: 74,
      mappings: { PO1: 3, PO2: 3, PO3: 2, PO5: 3, PO12: 2, PSO1: 3 }
    },
    {
      id: 'co-3',
      code: 'CO3',
      desc: 'Apply relational database design theory and normalization techniques (1NF, 2NF, 3NF, BCNF).',
      targetAttainment: 2.0,
      cieTargetPercent: 60,
      cieAchievedPercent: 62,
      seeTargetPercent: 60,
      seeAchievedPercent: 58,
      mappings: { PO1: 3, PO2: 3, PO3: 3, PO5: 2, PO12: 2, PSO1: 3 }
    },
    {
      id: 'co-4',
      code: 'CO4',
      desc: 'Analyze transaction processing, ACID properties, serializability, and concurrency control.',
      targetAttainment: 2.0,
      cieTargetPercent: 60,
      cieAchievedPercent: 64,
      seeTargetPercent: 60,
      seeAchievedPercent: 54,
      mappings: { PO1: 2, PO2: 3, PO3: 2, PO4: 2, PO12: 1, PSO1: 2 }
    },
    {
      id: 'co-5',
      code: 'CO5',
      desc: 'Design and implement an end-to-end database application addressing real-world requirements.',
      targetAttainment: 2.4,
      cieTargetPercent: 60,
      cieAchievedPercent: 74,
      seeTargetPercent: 60,
      seeAchievedPercent: 70,
      mappings: { PO1: 2, PO2: 3, PO3: 3, PO4: 2, PO5: 3, PO9: 3, PO10: 2, PO12: 2, PSO1: 3, PSO2: 3 }
    }
  ]);

  // Target PO values
  const poList = useMemo(() => {
    return [
      'PO1', 'PO2', 'PO3', 'PO4', 'PO5', 'PO6', 'PO7', 'PO8', 'PO9', 'PO10', 'PO11', 'PO12', 'PSO1', 'PSO2'
    ];
  }, []);

  // Helper to determine rubric level from student percentage
  const getRubricLevel = (achievedPercent: number) => {
    if (achievedPercent >= level3Threshold) return 3;
    if (achievedPercent >= level2Threshold) return 2;
    if (achievedPercent >= level1Threshold) return 1;
    return 0;
  };

  // Calculate CO Attainment for each outcome
  const coCalculations = useMemo(() => {
    const cieWeightFrac = Math.max(0, cieWeight) / 100;
    const seeWeightFrac = Math.max(0, seeWeight) / 100;

    return outcomes.map((co) => {
      const cieLevel = getRubricLevel(co.cieAchievedPercent);
      const seeLevel = getRubricLevel(co.seeAchievedPercent);
      const computedAttainment = Number((cieWeightFrac * cieLevel + seeWeightFrac * seeLevel).toFixed(2));
      const status = computedAttainment >= co.targetAttainment ? 'Achieved' : 'Gap';
      const gap = Number((co.targetAttainment - computedAttainment).toFixed(2));

      return {
        ...co,
        cieLevel,
        seeLevel,
        computedAttainment,
        status,
        gap
      };
    });
  }, [outcomes, cieWeight, seeWeight, level1Threshold, level2Threshold, level3Threshold]);

  // Calculate PO Attainment Matrix
  const poCalculations = useMemo(() => {
    const directFrac = directWeight / 100;
    const indirectFrac = indirectWeight / 100;

    return poList.map((poKey) => {
      // Find all COs that map to this PO with weight > 0
      const mappedCOs = coCalculations.filter((c) => (c.mappings[poKey] || 0) > 0);

      if (mappedCOs.length === 0) {
        return {
          po: poKey,
          mappedCount: 0,
          avgCorrelation: 0,
          directAttainment: 0,
          indirectAttainment: 0,
          totalAttainment: 0,
          targetAttainment: 2.0,
          gap: 0,
          status: 'Not Mapped'
        };
      }

      let directAttainment = 0;
      let totalMappingStrength = 0;

      if (calculationMode === 'weighted') {
        // Weighted formula: Sum(Correlation_i * CO_Attainment_i) / Sum(Correlation_i)
        let numerator = 0;
        mappedCOs.forEach((c) => {
          const correlation = c.mappings[poKey] || 0;
          numerator += correlation * c.computedAttainment;
          totalMappingStrength += correlation;
        });
        directAttainment = totalMappingStrength > 0 ? numerator / totalMappingStrength : 0;
      } else {
        // Simple Average formula: Sum(CO_Attainment_i) / Number of mapped COs
        const sum = mappedCOs.reduce((acc, c) => acc + c.computedAttainment, 0);
        directAttainment = sum / mappedCOs.length;
        totalMappingStrength = mappedCOs.reduce((acc, c) => acc + (c.mappings[poKey] || 0), 0);
      }

      // Sample indirect survey attainment based on typical exit surveys (e.g. 2.1)
      const sampleIndirect = Number((directAttainment * 0.95).toFixed(2));
      const totalAttainment = Number((directAttainment * directFrac + sampleIndirect * indirectFrac).toFixed(2));
      const targetAttainment = 2.0;
      const gap = Number((targetAttainment - totalAttainment).toFixed(2));

      return {
        po: poKey,
        mappedCount: mappedCOs.length,
        avgCorrelation: Number((totalMappingStrength / mappedCOs.length).toFixed(1)),
        directAttainment: Number(directAttainment.toFixed(2)),
        indirectAttainment: sampleIndirect,
        totalAttainment,
        targetAttainment,
        gap,
        status: totalAttainment >= targetAttainment ? 'Achieved' : 'Gap'
      };
    });
  }, [coCalculations, poList, calculationMode, directWeight, indirectWeight]);

  // Handlers for modifying COs
  const handleUpdateCO = (index: number, field: keyof CourseOutcomeItem, value: any) => {
    setOutcomes((prev) => {
      const copy = [...prev];
      copy[index] = { ...copy[index], [field]: value };
      return copy;
    });
  };

  const handleUpdateMapping = (index: number, po: string, val: number) => {
    setOutcomes((prev) => {
      const copy = [...prev];
      const newMappings = { ...copy[index].mappings };
      if (val === 0) {
        delete newMappings[po];
      } else {
        newMappings[po] = val;
      }
      copy[index] = { ...copy[index], mappings: newMappings };
      return copy;
    });
  };

  const cycleMappingValue = (coIdx: number, po: string) => {
    const current = outcomes[coIdx].mappings[po] || 0;
    const next = (current + 1) % 4; // 0 -> 1 -> 2 -> 3 -> 0
    handleUpdateMapping(coIdx, po, next);
  };

  const handleAddCO = () => {
    const newIdx = outcomes.length + 1;
    const newCO: CourseOutcomeItem = {
      id: `co-${Date.now()}`,
      code: `CO${newIdx}`,
      desc: `Course Outcome ${newIdx} description (Align with Bloom's Taxonomy).`,
      targetAttainment: 2.0,
      cieTargetPercent: 60,
      cieAchievedPercent: 70,
      seeTargetPercent: 60,
      seeAchievedPercent: 65,
      mappings: { PO1: 2, PO2: 2 }
    };
    setOutcomes((prev) => [...prev, newCO]);
  };

  const handleDeleteCO = (id: string) => {
    if (outcomes.length <= 1) {
      alert('A course must have at least one Course Outcome.');
      return;
    }
    setOutcomes((prev) => prev.filter((c) => c.id !== id));
  };

  const handleResetSample = () => {
    if (window.confirm('Reset calculator to the sample Database Management Systems course?')) {
      setCourseName('Database Management Systems');
      setCourseCode('CS304');
      setCieWeight(30);
      setSeeWeight(70);
      setCalculationMode('weighted');
      // reload original sample
      window.location.reload();
    }
  };

  // CSV Export
  const handleExportCSV = () => {
    const rows = [
      ['NBA Awareness Assistant - CO-PO Attainment Calculation Report'],
      ['Course Name', courseName, 'Course Code', courseCode],
      ['Calculation Methodology', calculationMode === 'weighted' ? 'Weighted Average' : 'Simple Average'],
      ['Weights', `CIE: ${cieWeight}%, SEE: ${seeWeight}%, Direct: ${directWeight}%, Indirect: ${indirectWeight}%`],
      [],
      ['--- COURSE OUTCOME ATTAINMENT TABLE ---'],
      ['CO Code', 'Description', 'CIE % Students >= Target', 'CIE Level (0-3)', 'SEE % Students >= Target', 'SEE Level (0-3)', 'Target Attainment', 'Computed Attainment', 'Status', 'Gap'],
      ...coCalculations.map((c) => [
        c.code,
        `"${c.desc.replace(/"/g, '""')}"`,
        `${c.cieAchievedPercent}%`,
        c.cieLevel,
        `${c.seeAchievedPercent}%`,
        c.seeLevel,
        c.targetAttainment,
        c.computedAttainment,
        c.status,
        c.gap
      ]),
      [],
      ['--- PROGRAM OUTCOME (PO) ATTAINMENT TABLE ---'],
      ['PO Code', 'Mapped COs Count', 'Avg Correlation', 'Direct Attainment (80%)', 'Indirect Attainment (20%)', 'Total Attainment', 'Target Benchmark', 'Gap', 'Status'],
      ...poCalculations.map((p) => [
        p.po,
        p.mappedCount,
        p.avgCorrelation,
        p.directAttainment,
        p.indirectAttainment,
        p.totalAttainment,
        p.targetAttainment,
        p.gap,
        p.status
      ])
    ];

    const csvContent = 'data:text/csv;charset=utf-8,' + rows.map((e) => e.join(',')).join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `${courseCode}_CO_PO_Attainment_Report.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-8 pb-16">
      {/* Top Banner & Header */}
      <div className="bg-white p-6 sm:p-8 rounded-xl border border-slate-200 shadow-xs flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-2 text-xs font-semibold text-teal-700 tracking-wide uppercase">
            <span>Criterion 3 Attainment Engine</span>
            <span aria-hidden="true">·</span>
            <span>Configurable Methodology</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 mt-1">
            CO-PO Mapping and Attainment Calculator
          </h1>
          <p className="text-xs sm:text-sm text-slate-600 mt-1">
            Educational tool to simulate Course Outcome attainment, correlation matrices, and Program Outcome closure.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={handleExportCSV}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-teal-600 hover:bg-teal-700 text-white text-xs font-semibold shadow-xs transition-colors"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export CSV</span>
          </button>
          <button
            onClick={handleResetSample}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold border border-slate-200 transition-colors"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Reset Sample</span>
          </button>
        </div>
      </div>

      {/* Institutional Policy Disclaimer */}
      <div className="p-4 rounded-xl bg-amber-50/70 border border-amber-200 flex items-start gap-3 text-xs text-amber-900">
        <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
        <div className="space-y-0.5">
          <span className="font-bold">Important Notice on Attainment Formulas:</span>
          <p className="leading-relaxed">
            No single formula is universally mandated by the NBA for all universities. You can configure assessment weights (CIE/SEE ratio), threshold marks, and calculation methods below to mirror your department's officially approved Academic Council or IQAC policy.
          </p>
        </div>
      </div>

      {/* Settings & Configuration Deck */}
      <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-xs space-y-4">
        <div className="flex items-center gap-2 text-sm font-bold text-slate-900 border-b border-slate-100 pb-3">
          <Settings className="w-4 h-4 text-teal-600" />
          <span>Configurable Calculation Assumptions</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 text-xs">
          <div>
            <label className="block text-slate-500 font-medium mb-1">Course Name</label>
            <input
              type="text"
              value={courseName}
              onChange={(e) => setCourseName(e.target.value)}
              className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 font-semibold focus:outline-none focus:ring-1 focus:ring-teal-500"
            />
          </div>

          <div>
            <label className="block text-slate-500 font-medium mb-1">Course Code</label>
            <input
              type="text"
              value={courseCode}
              onChange={(e) => setCourseCode(e.target.value)}
              className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 font-semibold focus:outline-none focus:ring-1 focus:ring-teal-500 font-mono"
            />
          </div>

          <div>
            <label className="block text-slate-500 font-medium mb-1">Assessment Split (CIE % : SEE %)</label>
            <div className="flex items-center gap-2">
              <input
                type="number"
                min="0"
                max="100"
                value={cieWeight}
                onChange={(e) => {
                  const val = Number(e.target.value);
                  setCieWeight(val);
                  setSeeWeight(100 - val);
                }}
                className="w-1/2 px-2.5 py-2 border border-slate-300 rounded-lg text-slate-900 font-mono text-center"
              />
              <span className="text-slate-400">:</span>
              <input
                type="number"
                disabled
                value={seeWeight}
                className="w-1/2 px-2.5 py-2 border border-slate-200 bg-slate-50 rounded-lg text-slate-600 font-mono text-center"
              />
            </div>
          </div>

          <div>
            <label className="block text-slate-500 font-medium mb-1">PO Attainment Formula</label>
            <select
              value={calculationMode}
              onChange={(e) => setCalculationMode(e.target.value as any)}
              className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 font-semibold focus:outline-none focus:ring-1 focus:ring-teal-500"
            >
              <option value="weighted">Weighted by Mapping (NBA Best Practice)</option>
              <option value="average">Simple Average of Mapped COs</option>
            </select>
          </div>
        </div>

        {/* Threshold Levels */}
        <div className="pt-2 border-t border-slate-100 flex flex-wrap items-center gap-6 text-xs text-slate-600">
          <span className="font-semibold text-slate-700">Rubric Levels (% Students achieving target marks):</span>
          <span>Level 1: ≥ {level1Threshold}%</span>
          <span>Level 2: ≥ {level2Threshold}%</span>
          <span>Level 3: ≥ {level3Threshold}%</span>
          <span className="text-slate-400">· Max Level = 3.0</span>
        </div>
      </div>

      {/* Interactive CO-PO Mapping Matrix */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs p-6 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div>
            <h2 className="text-base font-bold text-slate-900">1. CO-PO Correlation Matrix</h2>
            <p className="text-xs text-slate-500">
              Click any matrix cell to cycle correlation strength: <strong>- (None) → 1 (Slight) → 2 (Moderate) → 3 (Substantial)</strong>.
            </p>
          </div>
          <button
            onClick={handleAddCO}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-900 text-white text-xs font-semibold hover:bg-slate-800 transition-colors self-start sm:self-center"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Add Course Outcome</span>
          </button>
        </div>

        <div className="overflow-x-auto border border-slate-200 rounded-lg">
          <table className="min-w-full text-xs text-center">
            <thead className="bg-slate-100 text-slate-700 font-bold">
              <tr>
                <th className="p-2.5 text-left border-r border-slate-200 w-24">CO Code</th>
                {poList.map((po) => (
                  <th key={po} className="p-2 border-r border-slate-200 w-12 font-mono">
                    {po}
                  </th>
                ))}
                <th className="p-2 w-16">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200 bg-white">
              {outcomes.map((co, idx) => (
                <tr key={co.id} className="hover:bg-slate-50/70">
                  <td className="p-2.5 text-left font-mono font-bold text-teal-800 bg-slate-50 border-r border-slate-200">
                    {co.code}
                  </td>
                  {poList.map((po) => {
                    const val = co.mappings[po] || 0;
                    return (
                      <td
                        key={po}
                        onClick={() => cycleMappingValue(idx, po)}
                        title={`Click to change mapping for ${co.code} to ${po}`}
                        className={`p-2 border-r border-slate-200 font-mono font-bold cursor-pointer transition-colors select-none ${
                          val === 3
                            ? 'bg-teal-700 text-white hover:bg-teal-800'
                            : val === 2
                            ? 'bg-teal-100 text-teal-900 hover:bg-teal-200'
                            : val === 1
                            ? 'bg-slate-100 text-slate-800 hover:bg-slate-200'
                            : 'text-slate-300 hover:bg-slate-50'
                        }`}
                      >
                        {val > 0 ? val : '-'}
                      </td>
                    );
                  })}
                  <td className="p-2">
                    <button
                      onClick={() => handleDeleteCO(co.id)}
                      className="p-1 text-slate-400 hover:text-red-600 rounded transition-colors"
                      title="Delete Course Outcome"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Student Assessment Data & Direct CO Attainment Table */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs p-6 space-y-4">
        <div>
          <h2 className="text-base font-bold text-slate-900">2. Student Assessment Marks & CO Attainment</h2>
          <p className="text-xs text-slate-500">
            Enter the percentage of enrolled students who scored above the institutional benchmark (e.g. 60% marks) in Internal tests (CIE) and Final exam (SEE).
          </p>
        </div>

        <div className="overflow-x-auto border border-slate-200 rounded-lg">
          <table className="min-w-full text-xs text-left">
            <thead className="bg-slate-100 text-slate-700 font-bold">
              <tr>
                <th className="p-2.5">CO Code</th>
                <th className="p-2.5">Outcome Description</th>
                <th className="p-2.5 text-center">CIE % Above Benchmark</th>
                <th className="p-2.5 text-center">CIE Level</th>
                <th className="p-2.5 text-center">SEE % Above Benchmark</th>
                <th className="p-2.5 text-center">SEE Level</th>
                <th className="p-2.5 text-center">Target (0-3)</th>
                <th className="p-2.5 text-center font-bold text-slate-900">Attainment (0-3)</th>
                <th className="p-2.5 text-center">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200 bg-white">
              {coCalculations.map((c, idx) => (
                <tr key={c.id} className="hover:bg-slate-50/60">
                  <td className="p-2.5 font-mono font-bold text-teal-800">{c.code}</td>
                  <td className="p-2.5 max-w-xs text-slate-600 truncate">{c.desc}</td>
                  
                  {/* CIE Input */}
                  <td className="p-2.5 text-center">
                    <input
                      type="number"
                      min="0"
                      max="100"
                      value={c.cieAchievedPercent}
                      onChange={(e) => handleUpdateCO(idx, 'cieAchievedPercent', Number(e.target.value))}
                      className="w-16 px-1.5 py-1 text-center border border-slate-300 rounded font-mono font-bold text-slate-800 focus:outline-none focus:ring-1 focus:ring-teal-500"
                    />
                    <span className="ml-1 text-slate-400">%</span>
                  </td>
                  <td className="p-2.5 text-center font-mono font-bold text-slate-700">{c.cieLevel}</td>

                  {/* SEE Input */}
                  <td className="p-2.5 text-center">
                    <input
                      type="number"
                      min="0"
                      max="100"
                      value={c.seeAchievedPercent}
                      onChange={(e) => handleUpdateCO(idx, 'seeAchievedPercent', Number(e.target.value))}
                      className="w-16 px-1.5 py-1 text-center border border-slate-300 rounded font-mono font-bold text-slate-800 focus:outline-none focus:ring-1 focus:ring-teal-500"
                    />
                    <span className="ml-1 text-slate-400">%</span>
                  </td>
                  <td className="p-2.5 text-center font-mono font-bold text-slate-700">{c.seeLevel}</td>

                  {/* Target Input */}
                  <td className="p-2.5 text-center">
                    <input
                      type="number"
                      step="0.1"
                      min="0"
                      max="3"
                      value={c.targetAttainment}
                      onChange={(e) => handleUpdateCO(idx, 'targetAttainment', Number(e.target.value))}
                      className="w-14 px-1 py-1 text-center border border-slate-300 rounded font-mono text-slate-700 focus:outline-none focus:ring-1 focus:ring-teal-500"
                    />
                  </td>

                  {/* Computed Attainment */}
                  <td className="p-2.5 text-center font-mono font-bold text-slate-900 bg-teal-50/50">
                    {c.computedAttainment}
                  </td>

                  {/* Status Badge */}
                  <td className="p-2.5 text-center">
                    <span
                      className={`inline-block px-2 py-0.5 rounded text-[11px] font-semibold ${
                        c.status === 'Achieved'
                          ? 'bg-emerald-50 text-emerald-800'
                          : 'bg-amber-50 text-amber-800'
                      }`}
                    >
                      {c.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Program Outcome (PO) Attainment Results Table & Gap Analysis */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs p-6 space-y-4">
        <div>
          <h2 className="text-base font-bold text-slate-900">3. Program Outcome (PO & PSO) Attainment Results</h2>
          <p className="text-xs text-slate-500">
            Computed by aggregating mapped Course Outcomes using <strong>{calculationMode === 'weighted' ? 'Weighted Matrix Multiplication' : 'Simple Average'}</strong>.
          </p>
        </div>

        <div className="overflow-x-auto border border-slate-200 rounded-lg">
          <table className="min-w-full text-xs text-center">
            <thead className="bg-slate-100 text-slate-700 font-bold">
              <tr>
                <th className="p-2.5 text-left">PO / PSO</th>
                <th className="p-2.5">Mapped COs</th>
                <th className="p-2.5">Avg Mapping</th>
                <th className="p-2.5">Direct ({directWeight}%)</th>
                <th className="p-2.5">Indirect ({indirectWeight}%)</th>
                <th className="p-2.5 font-bold text-slate-900">Total Attainment</th>
                <th className="p-2.5">Target</th>
                <th className="p-2.5">Gap</th>
                <th className="p-2.5">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200 bg-white">
              {poCalculations.map((p) => (
                <tr key={p.po} className="hover:bg-slate-50/60">
                  <td className="p-2.5 text-left font-mono font-bold text-slate-900">{p.po}</td>
                  <td className="p-2.5 font-mono">{p.mappedCount}</td>
                  <td className="p-2.5 font-mono">{p.avgCorrelation > 0 ? p.avgCorrelation : '-'}</td>
                  <td className="p-2.5 font-mono">{p.directAttainment > 0 ? p.directAttainment : '-'}</td>
                  <td className="p-2.5 font-mono text-slate-500">{p.indirectAttainment > 0 ? p.indirectAttainment : '-'}</td>
                  <td className="p-2.5 font-mono font-bold text-teal-800 bg-teal-50/40">
                    {p.totalAttainment > 0 ? p.totalAttainment : '-'}
                  </td>
                  <td className="p-2.5 font-mono text-slate-600">{p.mappedCount > 0 ? p.targetAttainment : '-'}</td>
                  <td className="p-2.5 font-mono font-semibold">
                    {p.mappedCount === 0 ? (
                      '-'
                    ) : p.gap > 0 ? (
                      <span className="text-amber-700">+{p.gap} Gap</span>
                    ) : (
                      <span className="text-emerald-700">Surpassed</span>
                    )}
                  </td>
                  <td className="p-2.5">
                    {p.mappedCount === 0 ? (
                      <span className="text-slate-400 text-[11px]">Unmapped</span>
                    ) : (
                      <span
                        className={`inline-block px-2 py-0.5 rounded text-[11px] font-semibold ${
                          p.status === 'Achieved'
                            ? 'bg-emerald-50 text-emerald-800'
                            : 'bg-amber-50 text-amber-800'
                        }`}
                      >
                        {p.status}
                      </span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Visual Chart: Attainment vs Target */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs p-6 space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-base font-bold text-slate-900">4. Attainment Visualization Chart</h2>
            <p className="text-xs text-slate-500">Visual comparison of Total Achieved Attainment against Institutional Target (Benchmark 2.0).</p>
          </div>
          <div className="flex items-center gap-4 text-xs font-semibold">
            <div className="flex items-center gap-1.5">
              <div className="w-3 h-3 rounded-xs bg-teal-600" />
              <span>Achieved</span>
            </div>
            <div className="flex items-center gap-1.5">
              <div className="w-3 h-0.5 bg-red-500" />
              <span>Target (2.0)</span>
            </div>
          </div>
        </div>

        {/* Responsive Bar Chart using SVG */}
        <div className="pt-4 pb-2">
          <div className="grid grid-cols-7 sm:grid-cols-14 gap-2 h-44 items-end border-b border-slate-200 pb-2 relative">
            {/* Target line across at 2.0 / 3.0 height (approx 66.6%) */}
            <div
              className="absolute left-0 right-0 border-t-2 border-dashed border-red-400 pointer-events-none z-10"
              style={{ bottom: `${(2.0 / 3.0) * 100}%` }}
              title="Target Benchmark 2.0"
            />

            {poCalculations.map((p) => {
              const heightPercent = p.totalAttainment > 0 ? Math.min(100, (p.totalAttainment / 3.0) * 100) : 0;
              const isBelow = p.totalAttainment > 0 && p.totalAttainment < p.targetAttainment;
              return (
                <div key={p.po} className="flex flex-col items-center h-full justify-end group">
                  <div className="text-[10px] font-mono text-slate-500 opacity-0 group-hover:opacity-100 transition-opacity mb-1 font-bold">
                    {p.totalAttainment > 0 ? p.totalAttainment : ''}
                  </div>
                  <div
                    style={{ height: `${heightPercent}%` }}
                    className={`w-full max-w-[28px] rounded-t transition-all ${
                      p.totalAttainment === 0
                        ? 'bg-slate-100'
                        : isBelow
                        ? 'bg-amber-500 hover:bg-amber-600'
                        : 'bg-teal-600 hover:bg-teal-700'
                    }`}
                  />
                  <div className="text-[11px] font-mono font-semibold text-slate-700 mt-2 truncate w-full text-center">
                    {p.po}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* CQI Action Plan Generator (Closing the Loop) */}
      <div className="bg-slate-900 text-white rounded-xl p-6 sm:p-8 space-y-4 border border-slate-800 shadow-md">
        <div className="flex items-center gap-2">
          <CheckCircle2 className="w-5 h-5 text-teal-400" />
          <h2 className="text-base font-bold text-white">5. Auto-Generated CQI Action Plan (Criterion 7 Closure)</h2>
        </div>
        <p className="text-xs text-slate-300 leading-relaxed">
          NBA visiting peer evaluators require demonstrable interventions based on identified gaps. The following action points are recommended based on this simulation:
        </p>

        <div className="space-y-3 pt-2">
          {poCalculations
            .filter((p) => p.gap > 0 && p.mappedCount > 0)
            .map((p) => (
              <div key={p.po} className="p-3.5 bg-slate-800 rounded-lg border border-slate-700 text-xs space-y-1">
                <div className="flex items-center justify-between font-bold text-teal-300">
                  <span>{p.po} Attainment Gap: {p.gap} points below target (Achieved: {p.totalAttainment} vs Target: {p.targetAttainment})</span>
                  <span className="text-amber-400 text-[11px]">Action Required</span>
                </div>
                <p className="text-slate-300 leading-relaxed">
                  Recommended Action: Conduct 2 hands-on remedial workshops on {p.po === 'PO3' ? 'complex system design & architecture' : p.po === 'PO4' ? 'experimental data interpretation' : 'applied algorithmic problem solving'}. Introduce rubric-graded mini-projects in next cycle's internal assessment (CIE) to close this gap.
                </p>
              </div>
            ))}

          {poCalculations.filter((p) => p.gap > 0 && p.mappedCount > 0).length === 0 && (
            <div className="p-3.5 bg-teal-950/60 border border-teal-800 text-teal-200 rounded-lg text-xs">
              All mapped Program Outcomes meet or exceed the departmental benchmark of 2.0. To maintain continuous quality improvement (CQI), consider raising the target threshold to 2.3 for the subsequent academic batch.
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
