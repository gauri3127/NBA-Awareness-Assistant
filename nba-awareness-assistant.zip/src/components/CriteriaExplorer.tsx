import React, { useState } from 'react';
import { 
  ShieldCheck, 
  Award, 
  Layers, 
  CheckCircle2, 
  Info, 
  Sliders, 
  ChevronRight, 
  FileText,
  AlertTriangle,
  Building,
  GraduationCap
} from 'lucide-react';
import { NBA_CRITERIA } from '../data/nbaKnowledge';
import { Criterion } from '../types';

export const CriteriaExplorer: React.FC = () => {
  const [selectedTier, setSelectedTier] = useState<'tier1' | 'tier2'>('tier2');
  const [selectedCriterion, setSelectedCriterion] = useState<Criterion>(NBA_CRITERIA[0]);
  const [activeView, setActiveView] = useState<'overview' | 'detail' | 'estimator'>('overview');

  // Interactive Scoring Estimator State
  const [scores, setScores] = useState<Record<number, number>>({
    1: 48,
    2: 95,
    3: 98,
    4: 110,
    5: 145,
    6: 68,
    7: 58,
    8: 40,
    9: 42,
    10: 95
  });

  const totalEstimatedScore = Object.values(scores).reduce((a, b) => a + b, 0);

  const getAccreditationVerdict = (totalScore: number) => {
    if (totalScore >= 750) {
      return {
        verdict: 'Full Accreditation (6 Years)',
        badge: 'bg-emerald-50 text-emerald-800 border-emerald-300',
        summary: 'Exceeds the 750-mark benchmark with strong faculty, laboratory, and CQI demonstrations across criteria.'
      };
    }
    if (totalScore >= 600) {
      return {
        verdict: 'Provisional Accreditation (3 Years)',
        badge: 'bg-blue-50 text-blue-800 border-blue-300',
        summary: 'Meets the minimum 600-mark qualification. Compliance report will be required after 3 years.'
      };
    }
    return {
      verdict: 'Not Accredited (< 600 Marks)',
      badge: 'bg-red-50 text-red-800 border-red-300',
      summary: 'Below the 600-mark threshold. Requires substantial strengthening of faculty cadre, laboratories, and attainment evidence.'
    };
  };

  const handleScoreChange = (critId: number, val: number, maxMarks: number) => {
    const clamped = Math.max(0, Math.min(maxMarks, val));
    setScores((prev) => ({ ...prev, [critId]: clamped }));
  };

  return (
    <div className="space-y-8 pb-16">
      {/* Header */}
      <div className="bg-white p-6 sm:p-8 rounded-xl border border-slate-200 shadow-xs flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-2 text-xs font-semibold text-teal-700 tracking-wide uppercase">
            <span>SAR Self-Assessment Framework</span>
            <span aria-hidden="true">·</span>
            <span>1000 Total Marks Matrix</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 mt-1">
            NBA Accreditation Criteria Explorer
          </h1>
          <p className="text-xs sm:text-sm text-slate-600 mt-1">
            Explore the 10 Criteria of the Self-Assessment Report for Undergraduate Engineering.
          </p>
        </div>

        {/* Tier Selector */}
        <div className="flex items-center gap-2 bg-slate-100 p-1 rounded-lg">
          <button
            onClick={() => setSelectedTier('tier2')}
            className={`px-3 py-1.5 rounded-md text-xs font-semibold transition-colors ${
              selectedTier === 'tier2'
                ? 'bg-white text-slate-900 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Tier-II (Affiliated)
          </button>
          <button
            onClick={() => setSelectedTier('tier1')}
            className={`px-3 py-1.5 rounded-md text-xs font-semibold transition-colors ${
              selectedTier === 'tier1'
                ? 'bg-white text-slate-900 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Tier-I (Autonomous)
          </button>
        </div>
      </div>

      {/* View Switcher Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-200 pb-2">
        <button
          onClick={() => setActiveView('overview')}
          className={`px-3.5 py-1.5 text-xs font-semibold rounded-lg transition-colors ${
            activeView === 'overview'
              ? 'bg-slate-900 text-white'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
          }`}
        >
          Criteria Matrix & Marks (1000)
        </button>
        <button
          onClick={() => setActiveView('detail')}
          className={`px-3.5 py-1.5 text-xs font-semibold rounded-lg transition-colors ${
            activeView === 'detail'
              ? 'bg-slate-900 text-white'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
          }`}
        >
          In-Depth Criterion Inspector
        </button>
        <button
          onClick={() => setActiveView('estimator')}
          className={`px-3.5 py-1.5 text-xs font-semibold rounded-lg transition-colors ${
            activeView === 'estimator'
              ? 'bg-slate-900 text-white'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
          }`}
        >
          Self-Assessment Score Estimator
        </button>
      </div>

      {/* Tier Comparison Banner */}
      <div className="bg-slate-900 text-white p-5 rounded-xl border border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="text-xs text-teal-400 font-semibold uppercase">
            Currently Viewing: {selectedTier === 'tier1' ? 'Tier-I (Autonomous / University Departments)' : 'Tier-II (Affiliated Non-Autonomous Institutions)'}
          </div>
          <p className="text-xs text-slate-300">
            {selectedTier === 'tier1'
              ? 'Under the Washington Accord. Programs design their own syllabus, evaluation structure, and academic calendar.'
              : 'Affiliated to State Technical Universities (e.g. VTU, SPPU, AKTU). Curriculum is prescribed; Criterion 2 focuses on content delivery and curriculum gaps.'}
          </p>
        </div>
        <div className="text-xs font-mono font-bold bg-slate-800 px-3 py-1.5 rounded-lg border border-slate-700 text-teal-300 shrink-0">
          Total: 1000 Marks
        </div>
      </div>

      {/* View 1: Overview Matrix */}
      {activeView === 'overview' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Program Level Criteria (1-7) */}
            <div className="bg-white rounded-xl border border-slate-200 shadow-xs p-6 space-y-4">
              <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                <div>
                  <h2 className="text-sm font-bold text-slate-900">Program-Level Criteria (1–7)</h2>
                  <p className="text-xs text-slate-500">Evaluated specifically for the department</p>
                </div>
                <span className="font-mono text-xs font-bold text-teal-800 bg-teal-50 px-2 py-1 rounded">
                  {selectedTier === 'tier1' ? '730' : '780'} Marks
                </span>
              </div>

              <div className="divide-y divide-slate-100 text-xs">
                {NBA_CRITERIA.slice(0, 7).map((c) => {
                  const marks = selectedTier === 'tier1' ? c.tier1Marks : c.tier2Marks;
                  return (
                    <div
                      key={c.id}
                      onClick={() => {
                        setSelectedCriterion(c);
                        setActiveView('detail');
                      }}
                      className="py-3 flex items-center justify-between hover:bg-slate-50 cursor-pointer rounded px-2 transition-colors group"
                    >
                      <div className="space-y-0.5">
                        <div className="flex items-center gap-2">
                          <span className="font-mono font-bold text-slate-900">Criterion {c.number}:</span>
                          <span className="font-semibold text-slate-800 group-hover:text-teal-700">{c.title}</span>
                        </div>
                        <p className="text-[11px] text-slate-500 line-clamp-1">{c.description}</p>
                      </div>
                      <div className="flex items-center gap-3 shrink-0 ml-2">
                        <span className="font-mono font-bold text-slate-900">{marks}M</span>
                        <ChevronRight className="w-3.5 h-3.5 text-slate-400 group-hover:text-teal-600" />
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Institutional Level Criteria (8-10) */}
            <div className="bg-white rounded-xl border border-slate-200 shadow-xs p-6 space-y-4">
              <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                <div>
                  <h2 className="text-sm font-bold text-slate-900">Institutional-Level Criteria (8–10)</h2>
                  <p className="text-xs text-slate-500">Central support, governance, and first-year academics</p>
                </div>
                <span className="font-mono text-xs font-bold text-teal-800 bg-teal-50 px-2 py-1 rounded">
                  {selectedTier === 'tier1' ? '270' : '220'} Marks
                </span>
              </div>

              <div className="divide-y divide-slate-100 text-xs">
                {NBA_CRITERIA.slice(7, 10).map((c) => {
                  const marks = selectedTier === 'tier1' ? c.tier1Marks : c.tier2Marks;
                  return (
                    <div
                      key={c.id}
                      onClick={() => {
                        setSelectedCriterion(c);
                        setActiveView('detail');
                      }}
                      className="py-3 flex items-center justify-between hover:bg-slate-50 cursor-pointer rounded px-2 transition-colors group"
                    >
                      <div className="space-y-0.5">
                        <div className="flex items-center gap-2">
                          <span className="font-mono font-bold text-slate-900">Criterion {c.number}:</span>
                          <span className="font-semibold text-slate-800 group-hover:text-teal-700">{c.title}</span>
                        </div>
                        <p className="text-[11px] text-slate-500 line-clamp-1">{c.description}</p>
                      </div>
                      <div className="flex items-center gap-3 shrink-0 ml-2">
                        <span className="font-mono font-bold text-slate-900">{marks}M</span>
                        <ChevronRight className="w-3.5 h-3.5 text-slate-400 group-hover:text-teal-600" />
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Special Note */}
              <div className="p-4 rounded-lg bg-slate-50 border border-slate-200 text-xs text-slate-600 space-y-1 mt-6">
                <span className="font-bold text-slate-800">Critical Observation:</span>
                <p>
                  Criterion 5 (Faculty Information & Contributions) carries <strong>200 marks</strong> in both Tier-I and Tier-II manuals — the highest single weightage in the Self-Assessment Report. Student-Faculty Ratio (SFR) and Ph.D. cadre are scrutinized vigorously.
                </p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* View 2: Detailed Inspector */}
      {activeView === 'detail' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Criterion Picker Sidebar */}
          <div className="space-y-1.5 bg-white p-4 rounded-xl border border-slate-200 shadow-xs max-h-[600px] overflow-y-auto">
            <div className="text-xs font-semibold text-slate-500 uppercase px-2 mb-2">Select Criterion</div>
            {NBA_CRITERIA.map((crit) => {
              const isSelected = selectedCriterion.id === crit.id;
              const marks = selectedTier === 'tier1' ? crit.tier1Marks : crit.tier2Marks;
              return (
                <button
                  key={crit.id}
                  onClick={() => setSelectedCriterion(crit)}
                  className={`w-full text-left px-3 py-2.5 rounded-lg text-xs transition-colors flex items-center justify-between ${
                    isSelected
                      ? 'bg-slate-900 text-white font-semibold'
                      : 'text-slate-700 hover:bg-slate-100'
                  }`}
                >
                  <span className="font-mono font-bold mr-2">C{crit.number}</span>
                  <span className="truncate flex-1">{crit.title}</span>
                  <span className="font-mono text-[11px] opacity-80 ml-2">{marks}M</span>
                </button>
              );
            })}
          </div>

          {/* Details Card */}
          <div className="lg:col-span-2 bg-white p-6 sm:p-8 rounded-xl border border-slate-200 shadow-xs space-y-6">
            <div className="flex items-center justify-between border-b border-slate-100 pb-4">
              <div>
                <span className="font-mono text-xs font-bold text-teal-800 bg-teal-50 px-2.5 py-1 rounded">
                  Criterion {selectedCriterion.number}
                </span>
                <h2 className="text-xl font-bold text-slate-900 mt-2">{selectedCriterion.title}</h2>
              </div>
              <div className="text-right">
                <div className="text-xs text-slate-500">Max Weightage</div>
                <div className="text-xl font-bold font-mono text-slate-900">
                  {selectedTier === 'tier1' ? selectedCriterion.tier1Marks : selectedCriterion.tier2Marks} Marks
                </div>
              </div>
            </div>

            <div>
              <h3 className="text-xs font-semibold text-slate-500 uppercase mb-1">Scope & Purpose</h3>
              <p className="text-sm text-slate-700 leading-relaxed bg-slate-50 p-4 rounded-lg border border-slate-200">
                {selectedCriterion.description}
              </p>
            </div>

            <div>
              <h3 className="text-xs font-semibold text-slate-500 uppercase mb-2">Key Evaluation Aspects</h3>
              <ul className="space-y-1.5 text-xs sm:text-sm text-slate-700">
                {selectedCriterion.keyAspects.map((aspect, idx) => (
                  <li key={idx} className="flex items-start gap-2">
                    <CheckCircle2 className="w-4 h-4 text-teal-600 shrink-0 mt-0.5" />
                    <span>{aspect}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div>
              <h3 className="text-xs font-semibold text-slate-500 uppercase mb-2">Mandatory Exhibit Documents for Peer Team</h3>
              <ul className="space-y-1.5 text-xs sm:text-sm text-slate-700">
                {selectedCriterion.requiredDocuments.map((doc, idx) => (
                  <li key={idx} className="flex items-start gap-2">
                    <FileText className="w-4 h-4 text-slate-400 shrink-0 mt-0.5" />
                    <span>{doc}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div className="p-4 rounded-lg bg-teal-50/50 border border-teal-200 text-xs text-teal-950 space-y-1">
              <span className="font-bold text-teal-900">Evaluation Guidelines:</span>
              <p className="leading-relaxed">{selectedCriterion.evaluationGuidelines}</p>
            </div>
          </div>
        </div>
      )}

      {/* View 3: Self-Assessment Score Estimator */}
      {activeView === 'estimator' && (
        <div className="bg-white rounded-xl border border-slate-200 shadow-xs p-6 sm:p-8 space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100 pb-4">
            <div>
              <h2 className="text-lg font-bold text-slate-900">SAR Self-Assessment Score Estimator</h2>
              <p className="text-xs text-slate-500">
                Estimate expected marks across all 10 Criteria to evaluate departmental readiness for 3-Year or 6-Year accreditation.
              </p>
            </div>

            <div className="text-right">
              <div className="text-xs text-slate-500">Aggregate Estimated Score</div>
              <div className="text-2xl font-bold font-mono tabular-nums text-slate-900">
                {totalEstimatedScore} / 1000
              </div>
            </div>
          </div>

          {/* Verdict Banner */}
          {(() => {
            const verdictObj = getAccreditationVerdict(totalEstimatedScore);
            return (
              <div className={`p-4 rounded-xl border flex items-start gap-3 ${verdictObj.badge}`}>
                <Award className="w-5 h-5 shrink-0 mt-0.5" />
                <div className="space-y-0.5 text-xs">
                  <div className="font-bold text-sm">{verdictObj.verdict}</div>
                  <p>{verdictObj.summary}</p>
                </div>
              </div>
            );
          })()}

          {/* Sliders / Inputs */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {NBA_CRITERIA.map((crit) => {
              const maxMarks = selectedTier === 'tier1' ? crit.tier1Marks : crit.tier2Marks;
              const currentScore = scores[crit.id] || 0;
              const percentage = Math.round((currentScore / maxMarks) * 100);

              return (
                <div key={crit.id} className="p-4 rounded-lg bg-slate-50 border border-slate-200/80 space-y-2">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-bold text-slate-800">
                      C{crit.number}: {crit.title}
                    </span>
                    <span className="font-mono font-bold text-slate-900">
                      {currentScore} / {maxMarks} ({percentage}%)
                    </span>
                  </div>

                  <input
                    type="range"
                    min="0"
                    max={maxMarks}
                    value={currentScore}
                    onChange={(e) => handleScoreChange(crit.id, Number(e.target.value), maxMarks)}
                    className="w-full accent-teal-600 cursor-pointer"
                  />
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};
