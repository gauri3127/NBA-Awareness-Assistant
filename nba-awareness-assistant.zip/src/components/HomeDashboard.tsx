import React from 'react';
import { 
  Sparkles, 
  ArrowRight, 
  BookOpen, 
  Calculator, 
  CheckSquare, 
  ShieldCheck, 
  FileText, 
  ExternalLink,
  Award,
  BarChart3,
  CheckCircle2,
  HelpCircle,
  Clock,
  Compass
} from 'lucide-react';
import { OFFICIAL_RESOURCES, FAQS_DATA } from '../data/nbaKnowledge';

interface HomeDashboardProps {
  onNavigate: (tab: string) => void;
  onAskQuestion?: (question: string) => void;
}

export const HomeDashboard: React.FC<HomeDashboardProps> = ({ onNavigate, onAskQuestion }) => {
  const popularTopics = [
    'What is the difference between NBA and NAAC?',
    'Explain the 12 Graduate Attributes (Program Outcomes)',
    'How is Course Outcome (CO) attainment calculated?',
    'What is CO-PO mapping and what do levels 1, 2, 3 mean?',
    'What documents are required in a faculty course file?',
    'How does Continuous Quality Improvement (CQI) work?'
  ];

  const coreCards = [
    {
      title: 'NBA Accreditation Guide',
      desc: 'Step-by-step roadmap from pre-qualifiers to SAR submission and 3-day peer team visit.',
      tab: 'criteria',
      icon: Award,
      kicker: 'Process & Timeline'
    },
    {
      title: 'OBE Learning Center',
      desc: 'Master Outcome-Based Education, PEOs, POs, PSOs, and Bloom’s Taxonomy for Course Outcomes.',
      tab: 'obe',
      icon: BookOpen,
      kicker: 'Framework & Concepts'
    },
    {
      title: 'CO-PO Mapping Guide',
      desc: 'Interactive correlation matrices, correlation justification guidelines, and Bloom levels.',
      tab: 'obe',
      icon: Compass,
      kicker: 'Matrix & Justification'
    },
    {
      title: 'CO-PO Attainment Calculator',
      desc: 'Interactive calculator for direct (CIE/SEE) and indirect attainment with gap analysis & CSV export.',
      tab: 'calculator',
      icon: Calculator,
      kicker: 'Interactive Tool'
    },
    {
      title: 'Documentation Checklist',
      desc: 'Organize 14 critical categories of departmental quality records, course files, and exhibits.',
      tab: 'checklist',
      icon: CheckSquare,
      kicker: 'Department Audit'
    },
    {
      title: 'Accreditation Criteria (1-10)',
      desc: 'Complete 1000-mark evaluation rubric breakdown for Tier-I Autonomous and Tier-II Affiliated programs.',
      tab: 'criteria',
      icon: ShieldCheck,
      kicker: 'Mark Rubrics'
    }
  ];

  const verifiedUpdates = [
    {
      title: 'Tier-I & Tier-II SAR Manual Revisions',
      framework: 'Tier-I & Tier-II UG Engineering',
      date: 'Verified March 2026',
      summary: 'Reaffirms Student-to-Faculty Ratio (SFR) benchmarks and emphasis on demonstrable Continuous Quality Improvement (Criterion 7).',
      source: 'NBA Official Documentation'
    },
    {
      title: 'AICTE Examination Reform Policy Compliance',
      framework: 'All Engineering Institutions',
      date: 'Verified February 2026',
      summary: 'Mandates higher-order Bloom levels (Analyze, Evaluate, Create) in question paper design and structured rubrics for laboratory assessments.',
      source: 'AICTE Guidelines'
    },
    {
      title: 'Pre-Qualifier Mandatory Requirements',
      framework: 'Pre-SAR Validation',
      date: 'Verified January 2026',
      summary: 'Programs must demonstrate minimum regular faculty, qualified HOD, and average admissions above 50% over past 3 academic cycles.',
      source: 'NBA E-Portal'
    }
  ];

  return (
    <div className="space-y-12 pb-16">
      {/* Hero Section */}
      <section className="bg-slate-900 text-white rounded-2xl p-8 sm:p-12 lg:p-16 relative overflow-hidden shadow-xl border border-slate-800">
        <div className="max-w-3xl space-y-6 relative z-10">
          <div className="inline-flex items-center gap-2 text-xs font-semibold text-teal-300 tracking-wide">
            <span>OFFICIAL OBE & ACCREDITATION COMPLIANCE</span>
            <span aria-hidden="true">·</span>
            <span>TIER-I & TIER-II MANUALS</span>
          </div>
          
          <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold tracking-tight text-white leading-tight text-balance">
            Understand NBA. Improve Quality. Achieve Excellence.
          </h1>
          
          <p className="text-base sm:text-lg text-slate-300 leading-relaxed font-normal max-w-2xl">
            Your intelligent guide to NBA accreditation, Outcome-Based Education, and continuous academic improvement.
            Designed for engineering colleges, technical institutions, faculty members, and NBA coordinators.
          </p>

          <div className="pt-2 flex flex-wrap items-center gap-4">
            <button
              onClick={() => onNavigate('chat')}
              className="inline-flex items-center gap-2 px-6 py-3 rounded-lg bg-teal-500 hover:bg-teal-400 text-slate-950 font-semibold text-sm transition-colors shadow-md hover:shadow-lg"
            >
              <Sparkles className="w-4 h-4 text-slate-950" />
              <span>Ask NBA Assistant</span>
            </button>
            <button
              onClick={() => onNavigate('criteria')}
              className="inline-flex items-center gap-2 px-6 py-3 rounded-lg bg-slate-800 hover:bg-slate-700 text-white font-medium text-sm border border-slate-700 transition-colors"
            >
              <span>Explore NBA Criteria</span>
              <ArrowRight className="w-4 h-4 text-slate-400" />
            </button>
          </div>
        </div>

        {/* Decorative background accents */}
        <div className="absolute -right-20 -bottom-20 w-96 h-96 bg-teal-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute right-12 top-12 hidden lg:block opacity-20 pointer-events-none">
          <ShieldCheck className="w-64 h-64 text-teal-400 stroke-1" />
        </div>
      </section>

      {/* KPI Overview Strip */}
      <section className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white p-5 rounded-xl border border-slate-200/80 shadow-xs">
          <div className="text-xs text-slate-500 font-medium">Evaluation Scale</div>
          <div className="mt-1 text-2xl font-bold font-mono tabular-nums text-slate-900">1000 Marks</div>
          <div className="text-xs text-slate-500 mt-1">Across 10 SAR Criteria</div>
        </div>
        <div className="bg-white p-5 rounded-xl border border-slate-200/80 shadow-xs">
          <div className="text-xs text-slate-500 font-medium">Graduate Attributes</div>
          <div className="mt-1 text-2xl font-bold font-mono tabular-nums text-teal-700">12 POs</div>
          <div className="text-xs text-slate-500 mt-1">Washington Accord Standard</div>
        </div>
        <div className="bg-white p-5 rounded-xl border border-slate-200/80 shadow-xs">
          <div className="text-xs text-slate-500 font-medium">Program Coverage</div>
          <div className="mt-1 text-2xl font-bold text-slate-900">Tier-I & Tier-II</div>
          <div className="text-xs text-slate-500 mt-1">Autonomous & Affiliated</div>
        </div>
        <div className="bg-white p-5 rounded-xl border border-slate-200/80 shadow-xs">
          <div className="text-xs text-slate-500 font-medium">Accreditation Validity</div>
          <div className="mt-1 text-2xl font-bold font-mono tabular-nums text-slate-900">3 or 6 Years</div>
          <div className="text-xs text-slate-500 mt-1">Provisional or Full Term</div>
        </div>
      </section>

      {/* 6 Core Cards Grid */}
      <section className="space-y-4">
        <div>
          <h2 className="text-xl font-bold text-slate-900">Core Guidance Modules</h2>
          <p className="text-sm text-slate-600">Explore comprehensive tools and manuals for departmental accreditation readiness.</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {coreCards.map((card, idx) => {
            const Icon = card.icon;
            return (
              <div
                key={idx}
                onClick={() => onNavigate(card.tab)}
                className="group cursor-pointer bg-white rounded-xl p-6 border border-slate-200/80 hover:border-teal-500/50 shadow-xs hover:shadow-md transition-all flex flex-col justify-between"
              >
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-slate-500 font-medium">{card.kicker}</span>
                    <div className="w-10 h-10 rounded-lg bg-teal-50 text-teal-700 flex items-center justify-center group-hover:bg-teal-600 group-hover:text-white transition-colors">
                      <Icon className="w-5 h-5" />
                    </div>
                  </div>
                  <h3 className="text-base font-semibold text-slate-900 group-hover:text-teal-700 transition-colors">
                    {card.title}
                  </h3>
                  <p className="text-sm text-slate-600 leading-relaxed">
                    {card.desc}
                  </p>
                </div>
                
                <div className="pt-4 mt-4 border-t border-slate-100 flex items-center text-xs font-semibold text-teal-700 group-hover:translate-x-1 transition-transform">
                  <span>Open module</span>
                  <ArrowRight className="w-3.5 h-3.5 ml-1.5" />
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* Popular NBA Topics & Quick AI Launcher */}
      <section className="bg-slate-100/70 rounded-xl p-6 sm:p-8 border border-slate-200">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-lg font-bold text-slate-900">Popular NBA & OBE Topics</h2>
            <p className="text-xs text-slate-600">Select any question to consult the AI assistant instantly with verified references.</p>
          </div>
          <button
            onClick={() => onNavigate('chat')}
            className="text-xs font-semibold text-teal-800 hover:text-teal-900 flex items-center gap-1"
          >
            <span>Open AI Chat</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {popularTopics.map((topic, i) => (
            <button
              key={i}
              onClick={() => {
                if (onAskQuestion) {
                  onAskQuestion(topic);
                } else {
                  onNavigate('chat');
                }
              }}
              className="text-left p-3.5 rounded-lg bg-white border border-slate-200 hover:border-teal-400 hover:bg-teal-50/30 transition-colors group flex items-start justify-between gap-3"
            >
              <div className="flex items-start gap-2.5">
                <span className="font-mono text-xs font-semibold text-teal-700 pt-0.5">{String(i + 1).padStart(2, '0')}.</span>
                <span className="text-xs sm:text-sm font-medium text-slate-800 group-hover:text-slate-950">
                  {topic}
                </span>
              </div>
              <Sparkles className="w-4 h-4 text-slate-400 group-hover:text-teal-600 shrink-0 mt-0.5" />
            </button>
          ))}
        </div>
      </section>

      {/* Verified Official Updates (Clearly Labeled) */}
      <section className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-xl font-bold text-slate-900">Verified Official Updates</h2>
            <p className="text-xs text-slate-600">
              Curated official guidelines from the National Board of Accreditation and AICTE.
            </p>
          </div>
          <div className="text-xs text-slate-500 font-medium">
            Live updates: Verified against official SAR manuals
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {verifiedUpdates.map((item, idx) => (
            <div key={idx} className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs flex flex-col justify-between">
              <div className="space-y-2">
                <div className="flex items-center justify-between text-xs text-slate-500">
                  <span>{item.framework}</span>
                  <span className="font-mono">{item.date}</span>
                </div>
                <h3 className="text-sm font-bold text-slate-900">{item.title}</h3>
                <p className="text-xs text-slate-600 leading-relaxed">{item.summary}</p>
              </div>
              <div className="pt-3 mt-3 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
                <span>{item.source}</span>
                <CheckCircle2 className="w-4 h-4 text-teal-600" />
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Quick FAQs Highlight */}
      <section className="bg-white rounded-xl p-6 sm:p-8 border border-slate-200">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-lg font-bold text-slate-900">Frequently Asked Questions</h2>
            <p className="text-xs text-slate-600">Essential answers to common institutional accreditation doubts.</p>
          </div>
          <button
            onClick={() => onNavigate('resources')}
            className="text-xs font-semibold text-teal-700 hover:text-teal-800 flex items-center gap-1"
          >
            <span>View All FAQs</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="space-y-4">
          {FAQS_DATA.slice(0, 3).map((faq) => (
            <div key={faq.id} className="p-4 rounded-lg bg-slate-50 border border-slate-200/80">
              <div className="text-xs text-teal-700 font-semibold mb-1">{faq.category}</div>
              <h3 className="text-sm font-bold text-slate-900 mb-2">{faq.question}</h3>
              <p className="text-xs sm:text-sm text-slate-700 leading-relaxed whitespace-pre-line">
                {faq.answer.length > 200 ? `${faq.answer.slice(0, 200)}...` : faq.answer}
              </p>
              {faq.supportingReference && (
                <div className="mt-2 text-xs text-slate-500">
                  Source: {faq.supportingReference}
                </div>
              )}
            </div>
          ))}
        </div>
      </section>

      {/* Official NBA Resource Link Banner */}
      <section className="bg-teal-950 text-white rounded-xl p-6 sm:p-8 flex flex-col md:flex-row items-center justify-between gap-6 border border-teal-900">
        <div className="space-y-2">
          <div className="text-xs text-teal-400 font-semibold tracking-wide">OFFICIAL SOURCE VERIFICATION</div>
          <h2 className="text-xl font-bold">Access the Official NBA India Portal</h2>
          <p className="text-xs sm:text-sm text-slate-300 max-w-xl">
            For formal circulars, e-NBA fee structures, accredited institution directories, and latest notifications, always refer to the official NBA website.
          </p>
        </div>
        <a
          href="https://www.nbaind.org/"
          target="_blank"
          rel="noopener noreferrer"
          className="inline-flex items-center gap-2 px-5 py-2.5 rounded-lg bg-teal-500 hover:bg-teal-400 text-slate-950 text-xs font-bold transition-colors shrink-0 shadow-sm"
        >
          <span>Visit nbaind.org</span>
          <ExternalLink className="w-4 h-4" />
        </a>
      </section>
    </div>
  );
};
