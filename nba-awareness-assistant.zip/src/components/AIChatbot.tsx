import React, { useState, useRef, useEffect } from 'react';
import { 
  Sparkles, 
  Send, 
  Copy, 
  Check, 
  Trash2, 
  BookOpen, 
  ExternalLink, 
  AlertCircle, 
  Globe2,
  RefreshCw,
  Lightbulb
} from 'lucide-react';
import { ChatMessage } from '../types';

interface AIChatbotProps {
  initialPrompt?: string;
  onClearInitialPrompt?: () => void;
}

export const AIChatbot: React.FC<AIChatbotProps> = ({ initialPrompt, onClearInitialPrompt }) => {
  const [messages, setMessages] = useState<ChatMessage[]>(() => {
    const saved = localStorage.getItem('nba_chat_history');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        console.error('Failed to parse saved chat history', e);
      }
    }
    return [
      {
        id: 'welcome-msg',
        sender: 'assistant',
        text: `### Welcome to NBA Awareness Assistant\n\nI am your intelligent consultant specialized in **NBA Accreditation** and **Outcome-Based Education (OBE)**.\n\nI can assist you with:\n- **Accreditation Process**: Pre-qualifiers, Self-Assessment Report (SAR), peer visit audit preparation.\n- **OBE Fundamentals**: Vision/Mission alignment, PEOs, PO1–PO12 Graduate Attributes, PSOs, and Course Outcomes (COs).\n- **CO-PO Mapping**: Correlation matrices (levels 1, 2, 3) and justification documentation.\n- **Attainment Calculations**: Direct (CIE/SEE) and indirect assessment methods, threshold benchmarks, and rubric levels.\n- **Continuous Quality Improvement (CQI)**: Identifying attainment gaps and closing the loop.\n- **Criterion 1 to 10**: Tier-I (Autonomous) and Tier-II (Affiliated) evaluation criteria.\n\n*You may ask in English, Hindi (हिंदी), or Marathi (मराठी).* How can I help you today?`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        sources: ['NBA Tier-I & Tier-II SAR Manuals', 'Official Portal: https://www.nbaind.org/']
      }
    ];
  });

  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [selectedLanguage, setSelectedLanguage] = useState<'en' | 'hi' | 'mr'>('en');
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [errorText, setErrorText] = useState<string | null>(null);

  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    localStorage.setItem('nba_chat_history', JSON.stringify(messages));
  }, [messages]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isLoading]);

  useEffect(() => {
    if (initialPrompt && initialPrompt.trim()) {
      handleSendPrompt(initialPrompt);
      if (onClearInitialPrompt) {
        onClearInitialPrompt();
      }
    }
  }, [initialPrompt]);

  const starterQuestions = [
    'Explain NBA accreditation in simple language.',
    'What is the difference between NBA and NAAC?',
    'Explain the 12 Graduate Attributes (Program Outcomes).',
    'How does CO-PO mapping work with levels 1, 2, and 3?',
    'Explain the CO attainment calculation with an example.',
    'What documents are required in a faculty course file?',
    'What is Continuous Quality Improvement (CQI)?'
  ];

  const handleSendPrompt = async (promptText: string) => {
    if (!promptText.trim() || isLoading) return;

    const userMsg: ChatMessage = {
      id: `usr-${Date.now()}`,
      sender: 'user',
      text: promptText.trim(),
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      language: selectedLanguage
    };

    setMessages((prev) => [...prev, userMsg]);
    setInput('');
    setIsLoading(true);
    setErrorText(null);

    try {
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: promptText.trim(),
          history: messages.slice(-6),
          language: selectedLanguage
        })
      });

      if (!response.ok) {
        throw new Error(`Server returned HTTP ${response.status}`);
      }

      const data = await response.json();

      const assistantMsg: ChatMessage = {
        id: `asst-${Date.now()}`,
        sender: 'assistant',
        text: data.reply || 'No response generated.',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        sources: data.sources || ['NBA Official Documentation', 'https://www.nbaind.org/']
      };

      setMessages((prev) => [...prev, assistantMsg]);
    } catch (err: any) {
      console.error('Chat error:', err);
      setErrorText('Failed to reach AI service. Please verify server connection.');
      const errorMsg: ChatMessage = {
        id: `err-${Date.now()}`,
        sender: 'assistant',
        text: `**Unable to generate response right now.**\n\n${err?.message || 'Connection error'}. Please try asking again or refer directly to the **NBA Criteria Explorer** or **OBE Learning Center** tab.`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };
      setMessages((prev) => [...prev, errorMsg]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    handleSendPrompt(input);
  };

  const handleCopy = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleClearChat = () => {
    if (window.confirm('Are you sure you want to clear your conversation history?')) {
      const initial: ChatMessage[] = [
        {
          id: 'welcome-msg',
          sender: 'assistant',
          text: `Conversation cleared. What NBA accreditation or Outcome-Based Education question would you like to explore?`,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
        }
      ];
      setMessages(initial);
      localStorage.setItem('nba_chat_history', JSON.stringify(initial));
    }
  };

  // Simple Markdown renderer for headings, lists, tables, bold text
  const renderFormattedContent = (content: string) => {
    const lines = content.split('\n');
    const elements: React.ReactNode[] = [];
    let inTable = false;
    let tableRows: string[][] = [];

    const flushTable = (key: string) => {
      if (tableRows.length > 0) {
        const headerRow = tableRows[0];
        const bodyRows = tableRows.slice(1).filter(r => !r.every(c => c.includes('---')));
        elements.push(
          <div key={`table-${key}`} className="my-3 overflow-x-auto rounded-lg border border-slate-200">
            <table className="min-w-full divide-y divide-slate-200 text-xs">
              <thead className="bg-slate-100">
                <tr>
                  {headerRow.map((cell, idx) => (
                    <th key={idx} className="px-3 py-2 text-left font-semibold text-slate-900">
                      {cell.trim()}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 bg-white">
                {bodyRows.map((row, rIdx) => (
                  <tr key={rIdx} className={rIdx % 2 === 0 ? 'bg-white' : 'bg-slate-50'}>
                    {row.map((cell, cIdx) => (
                      <td key={cIdx} className="px-3 py-2 text-slate-700">
                        {cell.trim()}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        );
        tableRows = [];
        inTable = false;
      }
    };

    lines.forEach((line, idx) => {
      // Check if table row
      if (line.trim().startsWith('|') && line.trim().endsWith('|')) {
        inTable = true;
        const cells = line.split('|').slice(1, -1);
        tableRows.push(cells);
        return;
      } else if (inTable) {
        flushTable(`flush-${idx}`);
      }

      if (line.startsWith('### ')) {
        elements.push(
          <h3 key={idx} className="text-base font-bold text-slate-900 mt-3 mb-1">
            {line.replace('### ', '')}
          </h3>
        );
      } else if (line.startsWith('## ')) {
        elements.push(
          <h2 key={idx} className="text-lg font-bold text-slate-900 mt-4 mb-1">
            {line.replace('## ', '')}
          </h2>
        );
      } else if (line.startsWith('# ')) {
        elements.push(
          <h1 key={idx} className="text-xl font-extrabold text-slate-900 mt-4 mb-2">
            {line.replace('# ', '')}
          </h1>
        );
      } else if (line.startsWith('- ') || line.startsWith('• ') || line.startsWith('* ')) {
        const itemText = line.substring(2);
        elements.push(
          <li key={idx} className="ml-4 list-disc text-slate-700 text-xs sm:text-sm leading-relaxed my-0.5">
            {renderInlineMarkdown(itemText)}
          </li>
        );
      } else if (/^\d+\.\s/.test(line)) {
        elements.push(
          <li key={idx} className="ml-4 list-decimal text-slate-700 text-xs sm:text-sm leading-relaxed my-0.5">
            {renderInlineMarkdown(line.replace(/^\d+\.\s/, ''))}
          </li>
        );
      } else if (line.trim() === '') {
        elements.push(<div key={idx} className="h-2" />);
      } else {
        elements.push(
          <p key={idx} className="text-xs sm:text-sm text-slate-700 leading-relaxed my-1">
            {renderInlineMarkdown(line)}
          </p>
        );
      }
    });

    if (inTable) {
      flushTable('end');
    }

    return elements;
  };

  const renderInlineMarkdown = (text: string) => {
    // Basic bold and italic replacer
    const parts = text.split(/(\*\*.*?\*\*|\*.*?\*|`.*?`)/g);
    return parts.map((part, index) => {
      if (part.startsWith('**') && part.endsWith('**')) {
        return <strong key={index} className="font-semibold text-slate-900">{part.slice(2, -2)}</strong>;
      }
      if (part.startsWith('*') && part.endsWith('*')) {
        return <em key={index} className="italic text-slate-800">{part.slice(1, -1)}</em>;
      }
      if (part.startsWith('`') && part.endsWith('`')) {
        return <code key={index} className="px-1.5 py-0.5 bg-slate-100 rounded text-slate-800 font-mono text-xs">{part.slice(1, -1)}</code>;
      }
      return part;
    });
  };

  return (
    <div className="max-w-5xl mx-auto space-y-4">
      {/* Top Controls Bar */}
      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-teal-50 text-teal-700 flex items-center justify-center font-bold">
            <Sparkles className="w-4 h-4" />
          </div>
          <div>
            <h2 className="text-sm font-bold text-slate-900">NBA Accreditation AI Assistant</h2>
            <p className="text-xs text-slate-500">Grounded in Washington Accord & Tier-I/II SAR Guidelines</p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          {/* Language selector */}
          <div className="flex items-center gap-1.5 text-xs text-slate-600 bg-slate-100 p-1 rounded-lg">
            <Globe2 className="w-3.5 h-3.5 text-slate-500 ml-1.5" />
            <button
              onClick={() => setSelectedLanguage('en')}
              className={`px-2.5 py-1 rounded font-medium transition-colors ${
                selectedLanguage === 'en' ? 'bg-white text-slate-900 shadow-xs font-semibold' : 'hover:text-slate-900'
              }`}
            >
              English
            </button>
            <button
              onClick={() => setSelectedLanguage('hi')}
              className={`px-2.5 py-1 rounded font-medium transition-colors ${
                selectedLanguage === 'hi' ? 'bg-white text-slate-900 shadow-xs font-semibold' : 'hover:text-slate-900'
              }`}
            >
              हिंदी
            </button>
            <button
              onClick={() => setSelectedLanguage('mr')}
              className={`px-2.5 py-1 rounded font-medium transition-colors ${
                selectedLanguage === 'mr' ? 'bg-white text-slate-900 shadow-xs font-semibold' : 'hover:text-slate-900'
              }`}
            >
              मराठी
            </button>
          </div>

          <button
            onClick={handleClearChat}
            className="flex items-center gap-1 px-3 py-1.5 text-xs font-medium text-slate-600 hover:text-red-700 hover:bg-red-50 rounded-lg transition-colors border border-slate-200"
            title="Clear Chat History"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Clear Chat</span>
          </button>
        </div>
      </div>

      {/* Suggested Questions Strip */}
      <div className="bg-slate-50 p-3 rounded-xl border border-slate-200/80">
        <div className="flex items-center gap-1.5 text-xs font-medium text-slate-500 mb-2">
          <Lightbulb className="w-3.5 h-3.5 text-amber-500" />
          <span>Recommended Questions:</span>
        </div>
        <div className="flex gap-2 overflow-x-auto pb-1 scrollbar-none">
          {starterQuestions.map((q, idx) => (
            <button
              key={idx}
              onClick={() => handleSendPrompt(q)}
              className="text-xs px-3 py-1.5 bg-white border border-slate-200 hover:border-teal-400 hover:bg-teal-50/40 text-slate-700 hover:text-slate-900 rounded-lg whitespace-nowrap transition-colors shrink-0"
            >
              {q}
            </button>
          ))}
        </div>
      </div>

      {/* Chat Messages Container */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs p-4 sm:p-6 min-h-[500px] max-h-[620px] overflow-y-auto space-y-6">
        {messages.map((msg) => {
          const isUser = msg.sender === 'user';
          return (
            <div
              key={msg.id}
              className={`flex gap-3 ${isUser ? 'justify-end' : 'justify-start'}`}
            >
              {!isUser && (
                <div className="w-8 h-8 rounded-lg bg-slate-900 text-teal-300 flex items-center justify-center shrink-0 mt-1 shadow-xs">
                  <Sparkles className="w-4 h-4" />
                </div>
              )}

              <div
                className={`max-w-[85%] sm:max-w-[80%] rounded-2xl p-4 sm:p-5 relative group ${
                  isUser
                    ? 'bg-slate-900 text-white rounded-br-none'
                    : 'bg-slate-50/80 border border-slate-200/90 text-slate-900 rounded-bl-none'
                }`}
              >
                {/* Message Header */}
                <div className="flex items-center justify-between gap-4 mb-2 text-xs opacity-75">
                  <span className="font-semibold">
                    {isUser ? 'You' : 'NBA Awareness Assistant'}
                  </span>
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-[11px]">{msg.timestamp}</span>
                    {!isUser && (
                      <button
                        onClick={() => handleCopy(msg.id, msg.text)}
                        className="opacity-60 hover:opacity-100 p-1 rounded hover:bg-slate-200 transition-opacity"
                        title="Copy Response"
                      >
                        {copiedId === msg.id ? (
                          <Check className="w-3.5 h-3.5 text-teal-600" />
                        ) : (
                          <Copy className="w-3.5 h-3.5 text-slate-600" />
                        )}
                      </button>
                    )}
                  </div>
                </div>

                {/* Content */}
                <div className="space-y-1">
                  {isUser ? (
                    <p className="text-xs sm:text-sm whitespace-pre-wrap">{msg.text}</p>
                  ) : (
                    renderFormattedContent(msg.text)
                  )}
                </div>

                {/* Sources / Citations */}
                {!isUser && msg.sources && msg.sources.length > 0 && (
                  <div className="mt-4 pt-3 border-t border-slate-200/80 text-[11px] text-slate-500">
                    <div className="font-semibold text-slate-600 mb-1 flex items-center gap-1">
                      <BookOpen className="w-3 h-3 text-teal-600" />
                      <span>Official Reference Sources:</span>
                    </div>
                    <ul className="space-y-0.5">
                      {msg.sources.map((src, sIdx) => (
                        <li key={sIdx} className="flex items-center gap-1 text-slate-600">
                          <span>•</span>
                          <span>{src}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>

              {isUser && (
                <div className="w-8 h-8 rounded-lg bg-teal-600 text-white flex items-center justify-center shrink-0 mt-1 text-xs font-bold">
                  YOU
                </div>
              )}
            </div>
          );
        })}

        {isLoading && (
          <div className="flex gap-3 justify-start items-center">
            <div className="w-8 h-8 rounded-lg bg-slate-900 text-teal-300 flex items-center justify-center shrink-0">
              <RefreshCw className="w-4 h-4 animate-spin" />
            </div>
            <div className="bg-slate-50 border border-slate-200 p-4 rounded-xl rounded-bl-none flex items-center gap-3">
              <div className="flex items-center gap-1.5">
                <div className="w-2 h-2 rounded-full bg-teal-600 animate-bounce" />
                <div className="w-2 h-2 rounded-full bg-teal-600 animate-bounce [animation-delay:0.2s]" />
                <div className="w-2 h-2 rounded-full bg-teal-600 animate-bounce [animation-delay:0.4s]" />
              </div>
              <span className="text-xs text-slate-600 font-medium">
                Consulting NBA Tier-I/II knowledge base and AICTE guidelines...
              </span>
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {errorText && (
        <div className="p-3 bg-red-50 border border-red-200 text-red-800 rounded-lg text-xs flex items-center gap-2">
          <AlertCircle className="w-4 h-4 text-red-600 shrink-0" />
          <span>{errorText}</span>
        </div>
      )}

      {/* Input Box */}
      <form onSubmit={handleSubmit} className="relative">
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder={
            selectedLanguage === 'hi'
              ? 'NBA प्रत्यायन किंवा OBE बद्दल विचारा (उदा. CO-PO मॅपिंग कसे कार्य करते?)...'
              : selectedLanguage === 'mr'
              ? 'NBA मूल्यांकन किंवा OBE संदर्भात प्रश्न विचारा (उदा. Course Outcomes कसे लिहावे?)...'
              : 'Ask any question on NBA, CO-PO mapping, criteria, SAR preparation, or attainment...'
          }
          disabled={isLoading}
          className="w-full pl-4 pr-24 py-3.5 bg-white border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-teal-500/50 focus:border-teal-500 text-xs sm:text-sm text-slate-900 placeholder:text-slate-400 shadow-sm disabled:opacity-60"
        />
        <button
          type="submit"
          disabled={!input.trim() || isLoading}
          className="absolute right-2 top-2 bottom-2 px-4 bg-slate-900 hover:bg-slate-800 disabled:bg-slate-300 text-white rounded-lg text-xs font-semibold transition-colors flex items-center gap-1.5 shadow-xs"
        >
          <span>Ask</span>
          <Send className="w-3.5 h-3.5" />
        </button>
      </form>

      <div className="text-[11px] text-slate-500 text-center flex items-center justify-center gap-1">
        <span>Information is educational and grounded in official NBA & Washington Accord frameworks. Always verify institutional policies with your college's approved handbook.</span>
      </div>
    </div>
  );
};
