import React, { useState, useMemo } from 'react';
import { 
  FileText, 
  ExternalLink, 
  Search, 
  ShieldCheck, 
  CheckCircle2, 
  BookOpen, 
  HelpCircle, 
  Filter, 
  ChevronDown, 
  ChevronUp,
  Sparkles
} from 'lucide-react';
import { OFFICIAL_RESOURCES, FAQS_DATA } from '../data/nbaKnowledge';
import { OfficialResource, FAQItem } from '../types';

interface OfficialResourcesProps {
  onAskAI?: (prompt: string) => void;
}

export const OfficialResources: React.FC<OfficialResourcesProps> = ({ onAskAI }) => {
  const [activeSubTab, setActiveSubTab] = useState<'resources' | 'faqs'>('resources');
  const [resourceSearch, setResourceSearch] = useState('');
  const [selectedFramework, setSelectedFramework] = useState<string>('All');

  // FAQ state
  const [faqSearch, setFaqSearch] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [expandedFaqId, setExpandedFaqId] = useState<string | null>('faq-1');

  const frameworks = ['All', 'Tier-I (Autonomous/Univ)', 'Tier-II (Affiliated)', 'All Engineering'];

  const faqCategories = [
    'All',
    'NBA Basics',
    'Accreditation Process',
    'Outcome-Based Education',
    'CO-PO Mapping',
    'Documentation',
    'Attainment Calculation',
    'Continuous Improvement',
    'Faculty Responsibilities'
  ];

  const filteredResources = useMemo(() => {
    return OFFICIAL_RESOURCES.filter((res) => {
      const matchSearch =
        res.title.toLowerCase().includes(resourceSearch.toLowerCase()) ||
        res.description.toLowerCase().includes(resourceSearch.toLowerCase()) ||
        res.source.toLowerCase().includes(resourceSearch.toLowerCase());

      const matchFramework = selectedFramework === 'All' || res.applicableFramework === selectedFramework;
      return matchSearch && matchFramework;
    });
  }, [resourceSearch, selectedFramework]);

  const filteredFaqs = useMemo(() => {
    return FAQS_DATA.filter((faq) => {
      const matchSearch =
        faq.question.toLowerCase().includes(faqSearch.toLowerCase()) ||
        faq.answer.toLowerCase().includes(faqSearch.toLowerCase());

      const matchCategory = selectedCategory === 'All' || faq.category === selectedCategory;
      return matchSearch && matchCategory;
    });
  }, [faqSearch, selectedCategory]);

  return (
    <div className="space-y-8 pb-16">
      {/* Header */}
      <div className="bg-white p-6 sm:p-8 rounded-xl border border-slate-200 shadow-xs flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-2 text-xs font-semibold text-teal-700 tracking-wide uppercase">
            <span>Verified Knowledge Base</span>
            <span aria-hidden="true">·</span>
            <span>Accreditation Resources & FAQs</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 mt-1">
            Official Resource Center & Knowledge Base
          </h1>
          <p className="text-xs sm:text-sm text-slate-600 mt-1">
            Access genuine, verified documents from NBA, AICTE, and the Washington Accord, alongside an extensive searchable FAQ library.
          </p>
        </div>

        <div className="flex items-center gap-2 bg-slate-100 p-1 rounded-lg">
          <button
            onClick={() => setActiveSubTab('resources')}
            className={`px-3 py-1.5 rounded-md text-xs font-semibold transition-colors ${
              activeSubTab === 'resources'
                ? 'bg-white text-slate-900 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Verified Portals & Manuals
          </button>
          <button
            onClick={() => setActiveSubTab('faqs')}
            className={`px-3 py-1.5 rounded-md text-xs font-semibold transition-colors ${
              activeSubTab === 'faqs'
                ? 'bg-white text-slate-900 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Searchable FAQs
          </button>
        </div>
      </div>

      {/* Sub-tab 1: Verified Portals & Manuals */}
      {activeSubTab === 'resources' && (
        <div className="space-y-6">
          {/* Official Website Highlight Banner */}
          <div className="bg-slate-900 text-white rounded-xl p-6 sm:p-8 border border-slate-800 flex flex-col md:flex-row items-center justify-between gap-6 shadow-md">
            <div className="space-y-2">
              <div className="inline-flex items-center gap-1.5 text-xs font-semibold text-teal-300">
                <ShieldCheck className="w-4 h-4" />
                <span>PRIMARY ACCREDITATION BODY</span>
              </div>
              <h2 className="text-xl font-bold">National Board of Accreditation Official Portal</h2>
              <p className="text-xs sm:text-sm text-slate-300 max-w-2xl leading-relaxed">
                Always confirm your institution's registration, pre-qualifier submission, SAR fee schedules, and peer committee visit slots through the central e-NBA portal.
              </p>
            </div>
            <a
              href="https://www.nbaind.org/"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 px-6 py-3 rounded-lg bg-teal-500 hover:bg-teal-400 text-slate-950 text-xs font-bold transition-colors shrink-0 shadow-sm"
            >
              <span>Launch nbaind.org</span>
              <ExternalLink className="w-4 h-4" />
            </a>
          </div>

          {/* Search and Filters */}
          <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs flex flex-wrap items-center justify-between gap-4">
            <div className="relative flex-1 min-w-[240px]">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
              <input
                type="text"
                value={resourceSearch}
                onChange={(e) => setResourceSearch(e.target.value)}
                placeholder="Search verified official manuals, formats, and guidelines..."
                className="w-full pl-9 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs sm:text-sm text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-1 focus:ring-teal-500"
              />
            </div>

            <div className="flex items-center gap-2">
              <span className="text-xs text-slate-500 font-medium">Framework:</span>
              <select
                value={selectedFramework}
                onChange={(e) => setSelectedFramework(e.target.value)}
                className="px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs font-semibold text-slate-700 focus:outline-none focus:ring-1 focus:ring-teal-500"
              >
                {frameworks.map((f) => (
                  <option key={f} value={f}>{f}</option>
                ))}
              </select>
            </div>
          </div>

          {/* Resources List */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {filteredResources.map((res) => (
              <div key={res.id} className="bg-white rounded-xl border border-slate-200 shadow-xs p-6 flex flex-col justify-between space-y-4 hover:border-teal-500/50 transition-colors">
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-xs text-slate-500">
                    <span className="font-semibold text-teal-800 bg-teal-50 px-2 py-0.5 rounded">
                      {res.category}
                    </span>
                    <span className="font-mono text-[11px]">Verified: {res.verifiedDate}</span>
                  </div>

                  <h3 className="text-base font-bold text-slate-900">{res.title}</h3>
                  <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">{res.description}</p>
                </div>

                <div className="pt-4 border-t border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
                  <div className="space-y-0.5 text-slate-500">
                    <div>Source: <span className="font-semibold text-slate-700">{res.source}</span></div>
                    <div>Applicability: <span className="text-slate-700">{res.applicableFramework}</span></div>
                  </div>

                  <a
                    href={res.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center justify-center gap-1.5 px-3.5 py-2 rounded-lg bg-slate-900 hover:bg-slate-800 text-white font-semibold text-xs transition-colors shrink-0"
                  >
                    <span>Open Official Resource</span>
                    <ExternalLink className="w-3.5 h-3.5" />
                  </a>
                </div>
              </div>
            ))}
          </div>

          {/* Framework Identification Guide */}
          <div className="bg-slate-50 rounded-xl p-6 border border-slate-200 space-y-2">
            <h3 className="text-sm font-bold text-slate-900">Which NBA Manual applies to your institution?</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs text-slate-700 pt-2">
              <div className="p-3 bg-white rounded-lg border border-slate-200">
                <span className="font-bold text-slate-900">Tier-I Manual:</span>
                <p className="mt-1 leading-relaxed">
                  Use Tier-I if your college has Academic Autonomy granted by UGC, or is a University Department or Deemed-to-be University. Evaluated for Washington Accord global equivalency.
                </p>
              </div>
              <div className="p-3 bg-white rounded-lg border border-slate-200">
                <span className="font-bold text-slate-900">Tier-II Manual:</span>
                <p className="mt-1 leading-relaxed">
                  Use Tier-II if your college is affiliated with a State Technical University (non-autonomous) and follows the university's prescribed curriculum and exam schedule.
                </p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Sub-tab 2: Searchable FAQs */}
      {activeSubTab === 'faqs' && (
        <div className="space-y-6">
          {/* FAQ Search and Category Selector */}
          <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-xs space-y-4">
            <div className="relative">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
              <input
                type="text"
                value={faqSearch}
                onChange={(e) => setFaqSearch(e.target.value)}
                placeholder="Search questions (e.g. difference between CO and PO, course file contents, attainment calculation)..."
                className="w-full pl-9 pr-4 py-2.5 bg-slate-50 border border-slate-200 rounded-lg text-xs sm:text-sm text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-1 focus:ring-teal-500"
              />
            </div>

            {/* Category Pills */}
            <div className="flex gap-2 overflow-x-auto pb-1 scrollbar-none">
              {faqCategories.map((cat) => (
                <button
                  key={cat}
                  onClick={() => setSelectedCategory(cat)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-colors shrink-0 ${
                    selectedCategory === cat
                      ? 'bg-slate-900 text-white'
                      : 'bg-slate-100 text-slate-600 hover:bg-slate-200 hover:text-slate-900'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>
          </div>

          {/* FAQ Accordion List */}
          <div className="space-y-3">
            {filteredFaqs.map((faq) => {
              const isExpanded = expandedFaqId === faq.id;
              return (
                <div key={faq.id} className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
                  <button
                    onClick={() => setExpandedFaqId(isExpanded ? null : faq.id)}
                    className="w-full text-left p-4 sm:p-5 flex items-start justify-between gap-4 hover:bg-slate-50 transition-colors"
                  >
                    <div>
                      <span className="text-[11px] font-bold text-teal-700 uppercase tracking-wide">
                        {faq.category}
                      </span>
                      <h3 className="text-sm sm:text-base font-bold text-slate-900 mt-0.5">
                        {faq.question}
                      </h3>
                    </div>
                    <div className="p-1 rounded-md text-slate-400 hover:text-slate-600 shrink-0 mt-1">
                      {isExpanded ? <ChevronUp className="w-5 h-5" /> : <ChevronDown className="w-5 h-5" />}
                    </div>
                  </button>

                  {isExpanded && (
                    <div className="px-4 sm:px-5 pb-5 pt-1 border-t border-slate-100 bg-slate-50/50 space-y-3">
                      <div className="text-xs sm:text-sm text-slate-700 leading-relaxed whitespace-pre-line font-normal">
                        {faq.answer}
                      </div>

                      {faq.supportingReference && (
                        <div className="text-[11px] text-slate-500 pt-2 border-t border-slate-200/60 flex items-center justify-between">
                          <span>Reference: {faq.supportingReference}</span>
                          {onAskAI && (
                            <button
                              onClick={() => onAskAI(faq.question)}
                              className="text-teal-700 font-semibold hover:text-teal-800 flex items-center gap-1"
                            >
                              <Sparkles className="w-3 h-3" />
                              <span>Explore in AI Chat</span>
                            </button>
                          )}
                        </div>
                      )}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};
