import React, { useState, useEffect } from 'react';
import { 
  ShieldCheck, 
  Lock, 
  Unlock, 
  BarChart3, 
  MessageSquare, 
  FileCheck, 
  Plus, 
  CheckCircle2, 
  Clock, 
  User, 
  AlertCircle 
} from 'lucide-react';

export const AdminDashboard: React.FC = () => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [pinInput, setPinInput] = useState('');
  const [pinError, setPinError] = useState(false);

  const [stats, setStats] = useState<{
    totalChecklistItems: number;
    completedChecklistItems: number;
    inProgressChecklistItems: number;
    totalConsultations: number;
    feedbackCount: number;
  }>({
    totalChecklistItems: 14,
    completedChecklistItems: 4,
    inProgressChecklistItems: 9,
    totalConsultations: 34,
    feedbackCount: 3
  });

  const [announcements, setAnnouncements] = useState<Array<{ id: string; title: string; date: string; content: string }>>([
    {
      id: 'ann-1',
      title: 'NBA Internal Academic Audit Schedule',
      date: '2026-03-12',
      content: 'All course files for Criterion 3 must be submitted to the Departmental Quality Assurance Cell (DQAC) by March 30.'
    },
    {
      id: 'ann-2',
      title: 'Outcome-Based Education Faculty Workshop',
      date: '2026-02-28',
      content: 'Hands-on seminar on Bloom-compliant question paper setting and rubrics evaluation scheduled for all faculty coordinators.'
    }
  ]);

  const [newAnnTitle, setNewAnnTitle] = useState('');
  const [newAnnContent, setNewAnnContent] = useState('');

  useEffect(() => {
    fetch('/api/stats')
      .then((res) => res.json())
      .then((data) => {
        if (data && data.totalChecklistItems !== undefined) {
          setStats(data);
        }
      })
      .catch(() => {});
  }, []);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    // Simple institutional administrative PIN (e.g. 2026 or admin)
    if (pinInput === 'admin' || pinInput === '2026' || pinInput === 'nba2026') {
      setIsAuthenticated(true);
      setPinError(false);
    } else {
      setPinError(true);
    }
  };

  const handleAddAnnouncement = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newAnnTitle.trim() || !newAnnContent.trim()) return;

    setAnnouncements((prev) => [
      {
        id: `ann-${Date.now()}`,
        title: newAnnTitle.trim(),
        content: newAnnContent.trim(),
        date: new Date().toISOString().split('T')[0]
      },
      ...prev
    ]);

    setNewAnnTitle('');
    setNewAnnContent('');
  };

  if (!isAuthenticated) {
    return (
      <div className="max-w-md mx-auto my-12 bg-white rounded-2xl border border-slate-200 p-8 shadow-sm space-y-6">
        <div className="text-center space-y-2">
          <div className="w-12 h-12 rounded-xl bg-slate-900 text-teal-400 flex items-center justify-center mx-auto shadow-sm">
            <Lock className="w-6 h-6" />
          </div>
          <h2 className="text-xl font-bold text-slate-900">NBA Coordinator & Admin Access</h2>
          <p className="text-xs text-slate-500">
            Enter institutional coordinator authorization PIN to manage templates, audit announcements, and system usage.
          </p>
        </div>

        <form onSubmit={handleLogin} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-slate-600 mb-1">Coordinator Access PIN</label>
            <input
              type="password"
              value={pinInput}
              onChange={(e) => {
                setPinInput(e.target.value);
                setPinError(false);
              }}
              placeholder="Enter PIN (Default demo: 2026 or admin)"
              className="w-full px-4 py-2.5 bg-slate-50 border border-slate-300 rounded-lg text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-teal-500"
            />
            {pinError && (
              <p className="text-xs text-red-600 mt-1 flex items-center gap-1">
                <AlertCircle className="w-3.5 h-3.5" />
                <span>Incorrect PIN. (Use '2026' or 'admin' for demo access).</span>
              </p>
            )}
          </div>

          <button
            type="submit"
            className="w-full py-2.5 bg-slate-900 hover:bg-slate-800 text-white rounded-lg text-xs font-semibold transition-colors"
          >
            Authenticate Session
          </button>
        </form>

        <div className="text-[11px] text-slate-400 text-center">
          Demo Authorization Key: <code className="bg-slate-100 px-1 py-0.5 rounded text-slate-600">2026</code>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-8 pb-16">
      {/* Top Bar */}
      <div className="bg-white p-6 sm:p-8 rounded-xl border border-slate-200 shadow-xs flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-2 text-xs font-semibold text-teal-700 tracking-wide uppercase">
            <span>Administrative Console</span>
            <span aria-hidden="true">·</span>
            <span>NBA Coordinator Workspace</span>
          </div>
          <h1 className="text-2xl font-extrabold text-slate-900 mt-1">
            Institutional Administration Panel
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Manage departmental announcements, monitor consultation queries, and oversee SAR exhibit readiness.
          </p>
        </div>

        <button
          onClick={() => setIsAuthenticated(false)}
          className="px-3.5 py-1.5 rounded-lg border border-slate-300 hover:bg-slate-100 text-xs font-semibold text-slate-700 transition-colors"
        >
          Lock Session
        </button>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs">
          <div className="text-xs text-slate-500 font-medium">AI Consultations Logged</div>
          <div className="mt-1 text-2xl font-bold font-mono text-slate-900">{stats.totalConsultations}</div>
          <div className="text-[11px] text-teal-700 mt-1">Active Faculty Queries</div>
        </div>

        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs">
          <div className="text-xs text-slate-500 font-medium">Checklist Exhibits</div>
          <div className="mt-1 text-2xl font-bold font-mono text-slate-900">{stats.totalChecklistItems}</div>
          <div className="text-[11px] text-slate-500 mt-1">
            {stats.completedChecklistItems} Completed / {stats.inProgressChecklistItems} Pending
          </div>
        </div>

        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs">
          <div className="text-xs text-slate-500 font-medium">Audit Readiness</div>
          <div className="mt-1 text-2xl font-bold font-mono text-teal-700">
            {stats.totalChecklistItems > 0 ? Math.round((stats.completedChecklistItems / stats.totalChecklistItems) * 100) : 0}%
          </div>
          <div className="text-[11px] text-emerald-700 mt-1">Verified Documentation</div>
        </div>

        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs">
          <div className="text-xs text-slate-500 font-medium">Faculty Feedback Submissions</div>
          <div className="mt-1 text-2xl font-bold font-mono text-slate-900">{stats.feedbackCount}</div>
          <div className="text-[11px] text-slate-500 mt-1">Departmental Reviews</div>
        </div>
      </div>

      {/* Publish Verified Educational Announcements */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Post Form */}
        <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-xs space-y-4">
          <h2 className="text-base font-bold text-slate-900">Publish Departmental NBA Notice</h2>
          <form onSubmit={handleAddAnnouncement} className="space-y-3 text-xs">
            <div>
              <label className="block text-slate-600 font-semibold mb-1">Notice Title</label>
              <input
                type="text"
                required
                value={newAnnTitle}
                onChange={(e) => setNewAnnTitle(e.target.value)}
                placeholder="e.g. SAR Section 5.1 Faculty Ratio Final Verification"
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900"
              />
            </div>

            <div>
              <label className="block text-slate-600 font-semibold mb-1">Notice Content</label>
              <textarea
                rows={3}
                required
                value={newAnnContent}
                onChange={(e) => setNewAnnContent(e.target.value)}
                placeholder="Detailed instructions for course coordinators and laboratory in-charges..."
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900"
              />
            </div>

            <button
              type="submit"
              className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-lg font-semibold"
            >
              Post Department Notice
            </button>
          </form>
        </div>

        {/* Existing Notices */}
        <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-xs space-y-3">
          <h2 className="text-base font-bold text-slate-900">Published Notices</h2>
          <div className="space-y-3 max-h-[300px] overflow-y-auto">
            {announcements.map((ann) => (
              <div key={ann.id} className="p-3.5 rounded-lg bg-slate-50 border border-slate-200 space-y-1">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-bold text-slate-900">{ann.title}</span>
                  <span className="font-mono text-slate-400 text-[11px]">{ann.date}</span>
                </div>
                <p className="text-xs text-slate-600 leading-relaxed">{ann.content}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
