import React, { useState } from 'react';
import { 
  BookOpen, 
  Layers, 
  GitBranch, 
  CheckCircle2, 
  HelpCircle, 
  Compass, 
  ArrowRight, 
  Database,
  Award,
  Zap,
  TrendingUp,
  Sliders,
  ChevronDown,
  ChevronUp
} from 'lucide-react';
import { PROGRAM_OUTCOMES, SAMPLE_DBMS_COURSE } from '../data/nbaKnowledge';

export const OBELearningCenter: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'hierarchy' | 'pos' | 'blooms' | 'casestudy'>('hierarchy');
  const [selectedPO, setSelectedPO] = useState(PROGRAM_OUTCOMES[0]);
  const [expandedConcept, setExpandedConcept] = useState<string | null>('obe');

  const concepts = [
    {
      id: 'obe',
      title: '1. What is Outcome-Based Education (OBE)?',
      summary: 'A learner-centric paradigm focused on what students can demonstrably perform upon graduation.',
      details: `Outcome-Based Education (OBE) is a model of education that rejects traditional input-focused measures (such as hours spent lecturing or syllabus coverage) in favor of demonstrable student capabilities.

Key OBE Pillars:
• Clarity of Focus: Curriculum and instruction are designed around clear final learning outcomes.
• Design Down (Backward Design): Start with graduate competencies (POs/PSOs), derive Course Outcomes (COs), then design lessons and assessments.
• High Expectations: Clear assessment rubrics define proficiency levels.
• Expanded Opportunity: Formative assessments provide feedback and opportunities for mastery.`
    },
    {
      id: 'peos',
      title: '2. Program Educational Objectives (PEOs)',
      summary: 'Broad statements describing career and professional achievements 3 to 5 years after graduation.',
      details: `PEOs reflect institutional mission and the expectations of key stakeholders (employers, alumni, industry leaders).

Characteristics of Strong PEOs:
• Time Horizon: Evaluated 3–5 years post-graduation (not immediately at graduation).
• Typically 3 to 5 objectives per engineering department.
• Example: "Graduates will establish successful professional careers in software engineering, cloud systems, or related computing domains, solving complex industrial problems."
• Must be reviewed periodically through alumni and employer surveys.`
    },
    {
      id: 'pos_psos',
      title: '3. Program Outcomes (POs) and PSOs',
      summary: '12 mandatory Graduate Attributes plus 2–4 department-specific competencies.',
      details: `• Program Outcomes (POs): 12 standardized Graduate Attributes defined by the Washington Accord and NBA. Every engineering graduate must demonstrate these attributes upon completion of the 4-year degree.
• Program Specific Outcomes (PSOs): 2 to 4 discipline-specific competencies formulated by the department's Programme Assessment Committee (PAC).
• Example PSO (Computer Science): "PSO1: Apply core algorithmic paradigms, full-stack software development, and cloud computing principles to build scalable software applications."`
    },
    {
      id: 'cos',
      title: '4. Course Outcomes (COs)',
      summary: 'Specific, measurable statements describing student competencies at the conclusion of a course.',
      details: `Each course typically has 4 to 6 Course Outcomes.
Guidelines for Writing Course Outcomes:
• Must use active, measurable verbs from Bloom's Revised Taxonomy (avoid vague words like "know", "understand", "learn").
• Structure: Action Verb + Object / Knowledge Dimension + Context / Condition.
• Example: "Analyze database transaction schedules for serializability and deadlock avoidance using concurrency control algorithms." (Bloom Level L4: Analyze).`
    },
    {
      id: 'mapping',
      title: '5. CO-PO Mapping & Justification',
      summary: 'Establishing correlation strength (1: Slight, 2: Moderate, 3: Substantial) between COs and POs.',
      details: `A Course Outcome does not need to map to every Program Outcome. Only map where genuine instructional time, laboratory experiments, or assessment weightage exist.

Correlation Levels:
• Level 1 (Slight / Low): Superficial alignment; ~5% to 15% of course content/assessment touches this PO.
• Level 2 (Moderate / Medium): Substantial alignment; ~15% to 30% of course content/assessment addresses this PO.
• Level 3 (Substantial / High): Core alignment; >30% instruction, key projects, or lab exercises directly fulfill this PO.
• 0 or '-' : No correlation.
• Crucial: Faculty must document written justification for mappings of level 2 and 3.`
    },
    {
      id: 'attainment',
      title: '6. Direct & Indirect Attainment Assessment',
      summary: 'Combining examination performance (Direct) with stakeholder perception surveys (Indirect).',
      details: `• Direct Assessment (80% weight typically): Student marks in continuous internal evaluations (CIE), assignments, laboratory performance, and Semester End Examinations (SEE).
• Indirect Assessment (20% weight typically): Program Exit Surveys filled by graduating seniors, Alumni Surveys, and Employer Feedback.
• Calculation: Attainment measures the percentage of students achieving a predefined threshold (e.g. 60% marks in assessment questions mapped to a specific CO).`
    },
    {
      id: 'cqi',
      title: '7. Continuous Quality Improvement (CQI / Closing the Loop)',
      summary: 'The ultimate purpose of OBE: using attainment data to trigger real pedagogical interventions.',
      details: `Criterion 7 is the core of NBA accreditation. If an institution merely calculates numbers on spreadsheets without taking action, it fails the OBE audit.

The CQI Loop:
1. Target Setting: Define expected attainment level (e.g. 2.2 on 3-point scale).
2. Measure Actual Attainment: Compute direct and indirect attainment.
3. Identify Gaps: Where achieved < target (e.g. PO3 Design of Solutions achieved 1.8 vs target 2.2).
4. Root Cause Analysis: Conduct faculty & student audit to discover why students struggled.
5. Action Plan: Introduce targeted interventions (e.g. hands-on design mini-projects, open-book design tests, expert guest lectures).
6. Next Cycle Verification: Check if attainment improved in subsequent academic batches.`
    }
  ];

  const bloomsLevels = [
    {
      level: 'L1: Remember',
      description: 'Retrieve relevant knowledge from long-term memory.',
      verbs: ['Define', 'Describe', 'Identify', 'Label', 'List', 'Name', 'Recall', 'State'],
      color: 'bg-slate-100 text-slate-800'
    },
    {
      level: 'L2: Understand',
      description: 'Construct meaning from instructional messages (oral, written, graphic).',
      verbs: ['Classify', 'Compare', 'Explain', 'Illustrate', 'Interpret', 'Paraphrase', 'Summarize'],
      color: 'bg-sky-50 text-sky-800'
    },
    {
      level: 'L3: Apply',
      description: 'Carry out or use a procedure in a given situation.',
      verbs: ['Apply', 'Calculate', 'Demonstrate', 'Implement', 'Modify', 'Solve', 'Execute'],
      color: 'bg-teal-50 text-teal-800'
    },
    {
      level: 'L4: Analyze',
      description: 'Break material into constituent parts and determine relationships.',
      verbs: ['Analyze', 'Deconstruct', 'Differentiate', 'Discriminate', 'Distinguish', 'Examine'],
      color: 'bg-amber-50 text-amber-900'
    },
    {
      level: 'L5: Evaluate',
      description: 'Make judgments based on criteria and standards.',
      verbs: ['Appraise', 'Assess', 'Criticize', 'Defend', 'Judge', 'Validate', 'Verify'],
      color: 'bg-orange-50 text-orange-900'
    },
    {
      level: 'L6: Create',
      description: 'Put elements together to form a novel, coherent whole or make an original product.',
      verbs: ['Construct', 'Design', 'Develop', 'Formulate', 'Integrate', 'Plan', 'Synthesize'],
      color: 'bg-emerald-50 text-emerald-900'
    }
  ];

  return (
    <div className="space-y-8 pb-16">
      {/* Page Header */}
      <div className="bg-white p-6 sm:p-8 rounded-xl border border-slate-200 shadow-xs">
        <div className="inline-flex items-center gap-2 text-xs font-semibold text-teal-700 tracking-wide uppercase">
          <span>Outcome-Based Education Framework</span>
          <span aria-hidden="true">·</span>
          <span>Washington Accord Aligned</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 mt-2">
          Outcome-Based Education (OBE) Learning Center
        </h1>
        <p className="text-sm sm:text-base text-slate-600 mt-2 max-w-3xl leading-relaxed">
          Explore the hierarchical structure of Outcome-Based Education, the 12 Graduate Attributes (Program Outcomes), 
          Bloom's Taxonomy guidelines, and practical CO-PO correlation matrices with engineering case studies.
        </p>

        {/* Tab Navigation */}
        <div className="mt-6 flex flex-wrap items-center gap-2 border-b border-slate-200 pb-2">
          <button
            onClick={() => setActiveTab('hierarchy')}
            className={`px-3.5 py-1.5 text-xs font-semibold rounded-lg transition-colors ${
              activeTab === 'hierarchy'
                ? 'bg-slate-900 text-white'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            OBE Hierarchy & Concepts
          </button>
          <button
            onClick={() => setActiveTab('pos')}
            className={`px-3.5 py-1.5 text-xs font-semibold rounded-lg transition-colors ${
              activeTab === 'pos'
                ? 'bg-slate-900 text-white'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            12 Program Outcomes (POs)
          </button>
          <button
            onClick={() => setActiveTab('blooms')}
            className={`px-3.5 py-1.5 text-xs font-semibold rounded-lg transition-colors ${
              activeTab === 'blooms'
                ? 'bg-slate-900 text-white'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            Bloom's Taxonomy Guide
          </button>
          <button
            onClick={() => setActiveTab('casestudy')}
            className={`px-3.5 py-1.5 text-xs font-semibold rounded-lg transition-colors ${
              activeTab === 'casestudy'
                ? 'bg-slate-900 text-white'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            Engineering Course Case Study
          </button>
        </div>
      </div>

      {/* Tab 1: Hierarchy and Concepts */}
      {activeTab === 'hierarchy' && (
        <div className="space-y-8">
          {/* Visual Cascade Diagram */}
          <div className="bg-white p-6 sm:p-8 rounded-xl border border-slate-200 shadow-xs space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-base font-bold text-slate-900">The OBE Hierarchy & Feedback Loop</h2>
                <p className="text-xs text-slate-500">How institutional purpose cascades into classroom outcomes and Continuous Quality Improvement.</p>
              </div>
              <span className="text-xs font-semibold text-teal-700 bg-teal-50 px-2.5 py-1 rounded-md">
                Backward Design Philosophy
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-4 gap-3 pt-2">
              <div className="p-4 rounded-lg bg-slate-50 border border-slate-200">
                <div className="text-xs font-bold text-slate-500">Tier 1</div>
                <div className="text-sm font-bold text-slate-900 mt-1">Vision & Mission</div>
                <div className="text-xs text-slate-600 mt-1">Institution & Department core aspirations</div>
              </div>

              <div className="p-4 rounded-lg bg-slate-50 border border-slate-200">
                <div className="text-xs font-bold text-slate-500">Tier 2</div>
                <div className="text-sm font-bold text-slate-900 mt-1">PEOs (3-5 Years)</div>
                <div className="text-xs text-slate-600 mt-1">Professional accomplishments after graduation</div>
              </div>

              <div className="p-4 rounded-lg bg-teal-50/50 border border-teal-200">
                <div className="text-xs font-bold text-teal-700">Tier 3</div>
                <div className="text-sm font-bold text-slate-900 mt-1">POs & PSOs (Graduation)</div>
                <div className="text-xs text-slate-600 mt-1">12 Graduate Attributes + 2-4 program skills</div>
              </div>

              <div className="p-4 rounded-lg bg-teal-50 border border-teal-300">
                <div className="text-xs font-bold text-teal-800">Tier 4</div>
                <div className="text-sm font-bold text-teal-950 mt-1">Course Outcomes (COs)</div>
                <div className="text-xs text-slate-700 mt-1">Measurable skills at end of each semester</div>
              </div>
            </div>

            <div className="p-4 rounded-lg bg-slate-900 text-white flex flex-col sm:flex-row items-center justify-between gap-4 mt-2">
              <div className="space-y-1">
                <div className="text-xs text-teal-300 font-semibold">Continuous Quality Improvement (CQI) Loop</div>
                <div className="text-xs text-slate-300">
                  Assessment Data (CIE & SEE) → CO Attainment → PO Attainment → Gap Analysis → Pedagogical Action Plan → Next Batch Quality Lift
                </div>
              </div>
              <div className="flex items-center gap-1.5 shrink-0 text-xs font-bold text-teal-400 bg-slate-800 px-3 py-1.5 rounded-lg border border-slate-700">
                <TrendingUp className="w-3.5 h-3.5" />
                <span>Closing the Loop</span>
              </div>
            </div>
          </div>

          {/* Interactive Accordion Concepts */}
          <div className="space-y-3">
            <h2 className="text-lg font-bold text-slate-900">Core OBE Concepts Explained</h2>
            <div className="space-y-3">
              {concepts.map((c) => {
                const isExpanded = expandedConcept === c.id;
                return (
                  <div key={c.id} className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
                    <button
                      onClick={() => setExpandedConcept(isExpanded ? null : c.id)}
                      className="w-full text-left p-4 sm:p-5 flex items-center justify-between gap-4 hover:bg-slate-50 transition-colors"
                    >
                      <div>
                        <h3 className="text-sm sm:text-base font-bold text-slate-900">{c.title}</h3>
                        <p className="text-xs text-slate-500 mt-0.5">{c.summary}</p>
                      </div>
                      <div className="p-1 rounded-md text-slate-400 hover:text-slate-600">
                        {isExpanded ? <ChevronUp className="w-5 h-5" /> : <ChevronDown className="w-5 h-5" />}
                      </div>
                    </button>

                    {isExpanded && (
                      <div className="px-4 sm:px-5 pb-5 pt-1 border-t border-slate-100 bg-slate-50/50">
                        <div className="text-xs sm:text-sm text-slate-700 leading-relaxed whitespace-pre-line font-normal">
                          {c.details}
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* Tab 2: 12 Program Outcomes */}
      {activeTab === 'pos' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* PO List */}
          <div className="lg:col-span-1 space-y-2 bg-white p-4 rounded-xl border border-slate-200 shadow-xs max-h-[600px] overflow-y-auto">
            <div className="text-xs font-semibold text-slate-500 uppercase px-2 mb-2">
              12 Graduate Attributes
            </div>
            {PROGRAM_OUTCOMES.map((po) => {
              const isSelected = selectedPO.code === po.code;
              return (
                <button
                  key={po.code}
                  onClick={() => setSelectedPO(po)}
                  className={`w-full text-left px-3 py-2.5 rounded-lg text-xs transition-colors flex items-center justify-between ${
                    isSelected
                      ? 'bg-slate-900 text-white font-semibold'
                      : 'text-slate-700 hover:bg-slate-100'
                  }`}
                >
                  <span className="font-mono font-bold mr-2">{po.code}</span>
                  <span className="truncate flex-1">{po.title}</span>
                  <ArrowRight className={`w-3.5 h-3.5 ml-2 ${isSelected ? 'text-teal-400' : 'text-slate-400'}`} />
                </button>
              );
            })}
          </div>

          {/* Selected PO Details Card */}
          <div className="lg:col-span-2 bg-white p-6 sm:p-8 rounded-xl border border-slate-200 shadow-xs space-y-6">
            <div className="flex items-center justify-between border-b border-slate-100 pb-4">
              <div>
                <span className="font-mono text-xs font-bold text-teal-700 bg-teal-50 px-2.5 py-1 rounded-md">
                  {selectedPO.code} (Graduate Attribute)
                </span>
                <h2 className="text-xl font-bold text-slate-900 mt-2">{selectedPO.title}</h2>
              </div>
              <div className="text-right">
                <div className="text-[11px] text-slate-400 font-medium">Cognitive Depth</div>
                <div className="text-xs font-semibold text-slate-800">{selectedPO.bloomsLevel}</div>
              </div>
            </div>

            <div>
              <h3 className="text-xs font-semibold text-slate-500 uppercase mb-1">Official Washington Accord Statement</h3>
              <p className="text-sm text-slate-800 leading-relaxed p-4 bg-slate-50 rounded-lg border border-slate-200/80">
                "{selectedPO.fullDesc}"
              </p>
            </div>

            <div>
              <h3 className="text-xs font-semibold text-slate-500 uppercase mb-2">Core Engineering Dimensions</h3>
              <div className="flex flex-wrap gap-2">
                {selectedPO.keywords.map((kw, idx) => (
                  <span key={idx} className="text-xs px-3 py-1 bg-slate-100 text-slate-800 rounded-md font-medium">
                    {kw}
                  </span>
                ))}
              </div>
            </div>

            <div className="p-4 rounded-lg bg-teal-50/50 border border-teal-200 text-xs text-teal-950 space-y-1">
              <div className="font-semibold text-teal-900">How to demonstrate {selectedPO.code} in Accreditation:</div>
              <p className="leading-relaxed">
                Include questions in internal assessments that directly evaluate these keywords. Ensure courses addressing {selectedPO.code} provide sample student answer sheets, design project reports, or laboratory rubrics during the peer team audit.
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Tab 3: Bloom's Taxonomy */}
      {activeTab === 'blooms' && (
        <div className="space-y-6">
          <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-xs">
            <h2 className="text-base font-bold text-slate-900">Bloom's Revised Taxonomy in Question Paper Setting</h2>
            <p className="text-xs sm:text-sm text-slate-600 mt-1">
              AICTE and NBA require engineering examinations to test higher-order cognitive skills (Analyze, Evaluate, Create) rather than pure memorization (Remember).
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {bloomsLevels.map((b, idx) => (
              <div key={idx} className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs flex flex-col justify-between space-y-4">
                <div>
                  <div className={`text-xs font-bold px-2.5 py-1 rounded-md inline-block ${b.color}`}>
                    {b.level}
                  </div>
                  <p className="text-xs text-slate-600 mt-2 leading-relaxed">
                    {b.description}
                  </p>
                </div>

                <div className="border-t border-slate-100 pt-3">
                  <div className="text-[11px] font-semibold text-slate-500 uppercase mb-1.5">Actionable Verbs:</div>
                  <div className="flex flex-wrap gap-1">
                    {b.verbs.map((verb, vIdx) => (
                      <span key={vIdx} className="text-[11px] font-mono px-1.5 py-0.5 bg-slate-100 text-slate-700 rounded">
                        {verb}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Tab 4: Engineering Course Case Study */}
      {activeTab === 'casestudy' && (
        <div className="space-y-6">
          <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-xs flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div>
              <div className="text-xs font-semibold text-teal-700 uppercase tracking-wide">
                Illustrative Engineering Case Study
              </div>
              <h2 className="text-lg font-bold text-slate-900 mt-1">
                {SAMPLE_DBMS_COURSE.courseName} ({SAMPLE_DBMS_COURSE.courseCode})
              </h2>
              <p className="text-xs text-slate-500 mt-0.5">
                {SAMPLE_DBMS_COURSE.semester} · {SAMPLE_DBMS_COURSE.credits} Credits · 5 Defined Course Outcomes
              </p>
            </div>
            <div className="text-xs bg-amber-50 text-amber-800 border border-amber-200 px-3 py-1.5 rounded-lg max-w-xs">
              <strong>Notice:</strong> Sample values are illustrative for educational purposes and not a mandatory template.
            </div>
          </div>

          {/* CO Statements */}
          <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
            <div className="p-4 bg-slate-50 border-b border-slate-200 font-semibold text-xs text-slate-700 uppercase">
              Defined Course Outcomes (COs) & Bloom Levels
            </div>
            <div className="divide-y divide-slate-100 text-xs sm:text-sm">
              {SAMPLE_DBMS_COURSE.coStatements.map((co) => (
                <div key={co.code} className="p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 hover:bg-slate-50/50">
                  <div className="flex items-start gap-3">
                    <span className="font-mono font-bold text-teal-700 bg-teal-50 px-2 py-0.5 rounded text-xs shrink-0">
                      {co.code}
                    </span>
                    <span className="text-slate-800 leading-relaxed">{co.description}</span>
                  </div>
                  <div className="shrink-0 text-xs font-medium text-slate-600 bg-slate-100 px-2.5 py-1 rounded-md self-start sm:self-center">
                    {co.bloomsLevel}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Sample Mapping Matrix */}
          <div className="bg-white rounded-xl border border-slate-200 shadow-xs p-6 space-y-4">
            <div>
              <h3 className="text-sm font-bold text-slate-900">Illustrative CO-PO & PSO Mapping Matrix</h3>
              <p className="text-xs text-slate-500">Mapping strengths: 1 = Slight/Low, 2 = Moderate/Medium, 3 = Substantial/High, '-' = No Correlation.</p>
            </div>

            <div className="overflow-x-auto">
              <table className="min-w-full text-xs text-center border border-slate-200">
                <thead className="bg-slate-100 text-slate-700 font-bold">
                  <tr>
                    <th className="p-2 border border-slate-200 text-left">Course Outcome</th>
                    {['PO1', 'PO2', 'PO3', 'PO4', 'PO5', 'PO6', 'PO7', 'PO8', 'PO9', 'PO10', 'PO11', 'PO12', 'PSO1', 'PSO2'].map((p) => (
                      <th key={p} className="p-2 border border-slate-200">{p}</th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200">
                  {SAMPLE_DBMS_COURSE.coStatements.map((co) => (
                    <tr key={co.code} className="hover:bg-slate-50">
                      <td className="p-2 font-mono font-bold text-left border border-slate-200 bg-slate-50">
                        {co.code}
                      </td>
                      {['PO1', 'PO2', 'PO3', 'PO4', 'PO5', 'PO6', 'PO7', 'PO8', 'PO9', 'PO10', 'PO11', 'PO12', 'PSO1', 'PSO2'].map((p) => {
                        const val = (co.mappings as any)[p];
                        return (
                          <td key={p} className={`p-2 border border-slate-200 font-mono ${val ? 'font-bold text-slate-900 bg-teal-50/40' : 'text-slate-400'}`}>
                            {val || '-'}
                          </td>
                        );
                      })}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <div className="text-xs text-slate-500 italic">
              Example Justification Note for CO2 to PO5 (Level 3): High instructional emphasis on hands-on SQL query building and workbench execution using modern RDBMS software.
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
