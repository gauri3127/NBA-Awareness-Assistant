import React, { useState } from 'react';
import { Navbar } from './components/Navbar';
import { HomeDashboard } from './components/HomeDashboard';
import { AIChatbot } from './components/AIChatbot';
import { OBELearningCenter } from './components/OBELearningCenter';
import { CoPoCalculator } from './components/CoPoCalculator';
import { DocumentationChecklist } from './components/DocumentationChecklist';
import { CriteriaExplorer } from './components/CriteriaExplorer';
import { AccreditationCenter } from './components/AccreditationCenter';
import { OfficialResources } from './components/OfficialResources';
import { AdminDashboard } from './components/AdminDashboard';
import { ShieldCheck, BookOpen, ExternalLink, Heart } from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState<string>('dashboard');
  const [chatPrompt, setChatPrompt] = useState<string>('');

  const handleAskQuestionFromOutside = (question: string) => {
    setChatPrompt(question);
    setActiveTab('chat');
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col font-sans text-slate-900 antialiased selection:bg-teal-500 selection:text-white">
      {/* Top Navbar */}
      <Navbar activeTab={activeTab} setActiveTab={setActiveTab} />

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 pt-8">
        {activeTab === 'dashboard' && (
          <HomeDashboard
            onNavigate={(tab) => setActiveTab(tab)}
            onAskQuestion={handleAskQuestionFromOutside}
          />
        )}

        {activeTab === 'chat' && (
          <AIChatbot
            initialPrompt={chatPrompt}
            onClearInitialPrompt={() => setChatPrompt('')}
          />
        )}

        {activeTab === 'obe' && <OBELearningCenter />}

        {activeTab === 'calculator' && <CoPoCalculator />}

        {activeTab === 'checklist' && <DocumentationChecklist />}

        {activeTab === 'criteria' && (
          <div className="space-y-12">
            <CriteriaExplorer />
            <AccreditationCenter />
          </div>
        )}

        {activeTab === 'resources' && (
          <OfficialResources onAskAI={handleAskQuestionFromOutside} />
        )}

        {activeTab === 'admin' && <AdminDashboard />}
      </main>

      {/* Quiet, Clean Institutional Footer (Anti-Slop Discipline) */}
      <footer className="border-t border-slate-200 bg-white mt-auto py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500">
            <div className="flex items-center gap-2">
              <span className="font-bold text-slate-800">NBA Awareness Assistant</span>
              <span aria-hidden="true">·</span>
              <span>Outcome-Based Education Guidance Platform</span>
            </div>

            <div className="flex flex-wrap items-center gap-6">
              <button
                onClick={() => setActiveTab('criteria')}
                className="hover:text-slate-900 transition-colors"
              >
                Accreditation Criteria
              </button>
              <button
                onClick={() => setActiveTab('resources')}
                className="hover:text-slate-900 transition-colors"
              >
                Official Resources
              </button>
              <button
                onClick={() => setActiveTab('admin')}
                className="hover:text-slate-900 transition-colors"
              >
                Coordinator Panel
              </button>
              <a
                href="https://www.nbaind.org/"
                target="_blank"
                rel="noopener noreferrer"
                className="hover:text-teal-700 transition-colors flex items-center gap-1"
              >
                <span>nbaind.org</span>
                <ExternalLink className="w-3 h-3" />
              </a>
            </div>
          </div>
          <div className="mt-4 pt-4 border-t border-slate-100 text-[11px] text-slate-400 text-center">
            Educational resource benchmarked against NBA Tier-I & Tier-II SAR Manuals and Washington Accord Graduate Attributes.
          </div>
        </div>
      </footer>
    </div>
  );
}
