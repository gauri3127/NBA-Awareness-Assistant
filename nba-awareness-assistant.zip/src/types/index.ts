export interface Criterion {
  id: number;
  number: number;
  title: string;
  tier1Marks: number;
  tier2Marks: number;
  description: string;
  keyAspects: string[];
  requiredDocuments: string[];
  evaluationGuidelines: string;
}

export interface ProgramOutcome {
  code: string;
  title: string;
  shortDesc: string;
  fullDesc: string;
  keywords: string[];
  bloomsLevel: string;
}

export interface CourseOutcome {
  id: string;
  code: string;
  description: string;
  bloomsLevel: 'Remember (L1)' | 'Understand (L2)' | 'Apply (L3)' | 'Analyze (L4)' | 'Evaluate (L5)' | 'Create (L6)';
  targetAttainment: number; // e.g. 2.0 or 60%
  mappings: Record<string, number>; // PO1: 3, PO2: 2, etc. (0=none, 1=slight, 2=moderate, 3=substantial)
  justifications?: Record<string, string>;
}

export interface AssessmentRecord {
  coId: string;
  cieTargetPercentage: number; // e.g. 60%
  cieStudentsAchievedPercentage: number; // e.g. 75%
  cieAttainmentLevel: number; // e.g. 3
  seeTargetPercentage: number; // e.g. 60%
  seeStudentsAchievedPercentage: number; // e.g. 68%
  seeAttainmentLevel: number; // e.g. 2
  directAttainment: number; // computed
}

export interface ChecklistItem {
  id: string;
  category: string;
  title: string;
  description: string;
  criterionNumber?: number;
  academicYear: string;
  responsiblePerson: string;
  status: 'Not Started' | 'In Progress' | 'Completed';
  lastUpdated: string;
  notes: string;
}

export interface OfficialResource {
  id: string;
  title: string;
  description: string;
  source: string;
  url: string;
  category: 'Manual' | 'Guideline' | 'Circular' | 'Format' | 'Portal';
  applicableFramework: 'Tier-I (Autonomous/Univ)' | 'Tier-II (Affiliated)' | 'All Engineering' | 'PG / Diploma';
  documentDate?: string;
  verifiedDate: string;
  isOfficial: boolean;
}

export interface FAQItem {
  id: string;
  category: 'NBA Basics' | 'Accreditation Process' | 'Outcome-Based Education' | 'CO-PO Mapping' | 'Documentation' | 'Attainment Calculation' | 'Continuous Improvement' | 'Faculty Responsibilities';
  question: string;
  answer: string;
  supportingReference?: string;
  relatedQuestions?: string[];
}

export interface ChatMessage {
  id: string;
  sender: 'user' | 'assistant' | 'system';
  text: string;
  timestamp: string;
  language?: 'en' | 'hi' | 'mr';
  sources?: string[];
}
