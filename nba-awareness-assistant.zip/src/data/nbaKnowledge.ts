import { Criterion, ProgramOutcome, ChecklistItem, OfficialResource, FAQItem } from '../types';

export const PROGRAM_OUTCOMES: ProgramOutcome[] = [
  {
    code: 'PO1',
    title: 'Engineering Knowledge',
    shortDesc: 'Apply knowledge of mathematics, science, engineering fundamentals to solve complex engineering problems.',
    fullDesc: 'Apply the knowledge of mathematics, science, engineering fundamentals, and an engineering specialization to the solution of complex engineering problems.',
    keywords: ['Mathematics', 'Science', 'Engineering Fundamentals', 'Theory Application'],
    bloomsLevel: 'Apply (L3)'
  },
  {
    code: 'PO2',
    title: 'Problem Analysis',
    shortDesc: 'Identify, formulate, review research literature, and analyze complex engineering problems.',
    fullDesc: 'Identify, formulate, review research literature, and analyze complex engineering problems reaching substantiated conclusions using first principles of mathematics, natural sciences, and engineering sciences.',
    keywords: ['Problem Formulation', 'Literature Review', 'Substantiated Conclusions', 'First Principles'],
    bloomsLevel: 'Analyze (L4)'
  },
  {
    code: 'PO3',
    title: 'Design/Development of Solutions',
    shortDesc: 'Design solutions for complex problems and design system components that meet specified needs.',
    fullDesc: 'Design solutions for complex engineering problems and design system components or processes that meet the specified needs with appropriate consideration for public health and safety, cultural, societal, and environmental considerations.',
    keywords: ['System Design', 'Component Design', 'Public Safety', 'Societal Impact'],
    bloomsLevel: 'Create (L6)'
  },
  {
    code: 'PO4',
    title: 'Conduct Investigations of Complex Problems',
    shortDesc: 'Use research-based knowledge and research methods including design of experiments and analysis of data.',
    fullDesc: 'Use research-based knowledge and research methods including design of experiments, analysis and interpretation of data, and synthesis of the information to provide valid conclusions.',
    keywords: ['Research Methods', 'Design of Experiments', 'Data Interpretation', 'Synthesis'],
    bloomsLevel: 'Analyze (L4) / Evaluate (L5)'
  },
  {
    code: 'PO5',
    title: 'Modern Tool Usage',
    shortDesc: 'Create, select, and apply appropriate techniques, resources, and modern engineering and IT tools.',
    fullDesc: 'Create, select, and apply appropriate techniques, resources, and modern engineering and IT tools including prediction and modeling to complex engineering activities with an understanding of the limitations.',
    keywords: ['IT Tools', 'Simulation Software', 'Modeling Tools', 'Tool Limitations'],
    bloomsLevel: 'Apply (L3)'
  },
  {
    code: 'PO6',
    title: 'The Engineer and Society',
    shortDesc: 'Apply reasoning informed by contextual knowledge to assess societal, health, safety, legal, and cultural issues.',
    fullDesc: 'Apply reasoning informed by the contextual knowledge to assess societal, health, safety, legal and cultural issues and the consequent responsibilities relevant to the professional engineering practice.',
    keywords: ['Societal Impact', 'Legal Responsibilities', 'Health & Safety', 'Professional Ethics'],
    bloomsLevel: 'Understand (L2) / Evaluate (L5)'
  },
  {
    code: 'PO7',
    title: 'Environment and Sustainability',
    shortDesc: 'Understand the impact of professional engineering solutions in societal and environmental contexts.',
    fullDesc: 'Understand the impact of the professional engineering solutions in societal and environmental contexts, and demonstrate the knowledge of, and need for sustainable development.',
    keywords: ['Sustainable Development', 'Ecological Balance', 'Green Engineering', 'Life Cycle'],
    bloomsLevel: 'Understand (L2) / Evaluate (L5)'
  },
  {
    code: 'PO8',
    title: 'Ethics',
    shortDesc: 'Apply ethical principles and commit to professional ethics and responsibilities.',
    fullDesc: 'Apply ethical principles and commit to professional ethics and responsibilities and norms of the engineering practice.',
    keywords: ['Professional Integrity', 'Code of Conduct', 'Academic Honesty', 'Engineering Norms'],
    bloomsLevel: 'Apply (L3)'
  },
  {
    code: 'PO9',
    title: 'Individual and Team Work',
    shortDesc: 'Function effectively as an individual, and as a member or leader in diverse teams.',
    fullDesc: 'Function effectively as an individual, and as a member or leader in diverse teams, and in multidisciplinary settings.',
    keywords: ['Collaboration', 'Leadership', 'Multidisciplinary Settings', 'Role Distribution'],
    bloomsLevel: 'Apply (L3)'
  },
  {
    code: 'PO10',
    title: 'Communication',
    shortDesc: 'Communicate effectively on complex engineering activities with the engineering community and with society.',
    fullDesc: 'Communicate effectively on complex engineering activities with the engineering community and with society at large, such as, being able to comprehend and write effective reports and design documentation, make effective presentations, and give and receive clear instructions.',
    keywords: ['Technical Writing', 'Oral Presentations', 'Report Preparation', 'Active Listening'],
    bloomsLevel: 'Apply (L3)'
  },
  {
    code: 'PO11',
    title: 'Project Management and Finance',
    shortDesc: 'Demonstrate knowledge and understanding of engineering and management principles and apply these to work.',
    fullDesc: 'Demonstrate knowledge and understanding of the engineering and management principles and apply these to one’s own work, as a member and leader in a team, to manage projects and in multidisciplinary environments.',
    keywords: ['Budgeting', 'Project Scheduling', 'Cost Estimation', 'Risk Management'],
    bloomsLevel: 'Apply (L3) / Evaluate (L5)'
  },
  {
    code: 'PO12',
    title: 'Life-long Learning',
    shortDesc: 'Recognize the need for, and have the preparation and ability to engage in independent and life-long learning.',
    fullDesc: 'Recognize the need for, and have the preparation and ability to engage in independent and life-long learning in the broadest context of technological change.',
    keywords: ['Self-directed Learning', 'Technological Adaptation', 'Continuous Education', 'Curiosity'],
    bloomsLevel: 'Understand (L2) / Apply (L3)'
  }
];

export const NBA_CRITERIA: Criterion[] = [
  {
    id: 1,
    number: 1,
    title: 'Vision, Mission and Program Educational Objectives',
    tier1Marks: 50,
    tier2Marks: 60,
    description: 'Establishment, dissemination, and alignment of Vision and Mission with institutional objectives, and the formulation and assessment of Program Educational Objectives (PEOs).',
    keyAspects: [
      'Vision and Mission statements of Institute and Department',
      'Process for defining Vision, Mission, and PEOs with stakeholder involvement',
      'Dissemination among faculty, students, employers, and parents',
      'Consistency of PEOs with Department & Institute Mission statements'
    ],
    requiredDocuments: [
      'Minutes of Departmental Advisory Board (DAB) / PAC meetings',
      'Dissemination records (handbooks, website, lab displays)',
      'Feedback forms and survey analysis from stakeholders (alumni, employers)',
      'PEO formulation policy and periodic review document'
    ],
    evaluationGuidelines: 'Evaluated on clarity, stakeholder participation, relevance to industrial needs, and systematic review processes.'
  },
  {
    id: 2,
    number: 2,
    title: 'Program Curriculum and Teaching-Learning Processes',
    tier1Marks: 100,
    tier2Marks: 120,
    description: 'Curriculum structure, delivery mechanism, adherence to academic calendar, pedagogical innovations, and initiatives to support slow & advanced learners.',
    keyAspects: [
      'Alignment of curriculum with Program Outcomes (POs) and PSOs',
      'Process identifying curriculum gaps and value-added courses offered',
      'Teaching-learning methods (ICT, active learning, flipped classroom)',
      'Assessment of student projects (quality, rubrics, industry relevance)'
    ],
    requiredDocuments: [
      'Curriculum structure & syllabus copy highlighting gaps identified',
      'Course delivery plans & lesson execution logs in course files',
      'Project evaluation rubrics, project reports, and patent/publication records',
      'Documentation of remedial classes and enrichment sessions'
    ],
    evaluationGuidelines: 'Emphasis on curriculum flexibility, modern pedagogy, experimental learning, and structured rubrics.'
  },
  {
    id: 3,
    number: 3,
    title: 'Course Outcomes and Program Outcomes',
    tier1Marks: 120,
    tier2Marks: 120,
    description: 'Statement of Course Outcomes (COs), their correlation with POs/PSOs, and the structured attainment assessment process (Direct and Indirect).',
    keyAspects: [
      'Well-articulated Course Outcomes aligned with Bloom’s Taxonomy',
      'CO-PO and CO-PSO mapping matrices with justification matrix',
      'Direct assessment tools (internal tests, lab exams, SEE, assignments)',
      'Indirect assessment tools (exit survey, alumni feedback, employer survey)',
      'Target setting and attainment calculation methodology'
    ],
    requiredDocuments: [
      'Course Outcome sheets signed by faculty with Bloom level indicators',
      'CO-PO mapping matrices with rationale/justification notes',
      'Sample answer sheets, assessment rubrics, and marks verification records',
      'Attainment calculation spreadsheets and gap identification reports'
    ],
    evaluationGuidelines: 'Rigorous inspection of attainment calculation integrity, sample verification of student marks, and consistency in rubrics.'
  },
  {
    id: 4,
    number: 4,
    title: 'Students’ Performance',
    tier1Marks: 150,
    tier2Marks: 150,
    description: 'Enrolment ratio, success rate without backlogs, academic performance index (API), placement, higher studies, and entrepreneurship tracking.',
    keyAspects: [
      'Enrolment ratio over the last three academic years',
      'Success rate without backlogs in stipulated duration (4 years)',
      'Success rate with backlogs in stipulated duration',
      'Academic Performance Index (API) in 2nd, 3rd, and final years',
      'Placement index, qualifying exam clearing (GATE/GRE/CAT), startups'
    ],
    requiredDocuments: [
      'University result sheets, tabulation registers, and grade cards',
      'Offer letters, salary package proofs, and placement records',
      'Admission letters for higher studies and scorecards of competitive exams',
      'Registration certificates and incubation proofs of student startups'
    ],
    evaluationGuidelines: 'Strict numerical verification based on NBA formulas: API = Mean CGPA / 10; Placement Index = (Placed + Higher Studies + Startups) / Eligible students.'
  },
  {
    id: 5,
    number: 5,
    title: 'Faculty Information and Contributions',
    tier1Marks: 200,
    tier2Marks: 200,
    description: 'Student-to-Faculty Ratio (SFR), faculty cadre ratio, faculty qualification (Ph.D.), retention rate, research publications, patents, and consultancy.',
    keyAspects: [
      'Student-Faculty Ratio (Target: 1:15 for Tier-I / 1:20 for Tier-II)',
      'Faculty Cadre Ratio (Target: 1 Professor : 2 Associate : 6 Assistant)',
      'Faculty with Ph.D. qualification percentage',
      'Faculty retention over 3 consecutive academic years',
      'Research publications in SCI/Scopus journals, sponsored projects, and patents'
    ],
    requiredDocuments: [
      'Faculty appointment orders, joining reports, and salary disbursement proofs',
      'Ph.D. degree certificates and AICTE approval documentation',
      'Scopus/SCI indexed research papers with citation reports',
      'Sanction letters for funded research projects and consultancy receipt challans'
    ],
    evaluationGuidelines: 'Highest weightage criterion (200 marks). Scrutinized for valid payroll, full-time regular faculty tenure, and verifiable research impact.'
  },
  {
    id: 6,
    number: 6,
    title: 'Facilities and Technical Support',
    tier1Marks: 80,
    tier2Marks: 80,
    description: 'Adequacy of laboratories, equipment maintenance, safety measures, technical staff qualification, computing infrastructure, and licensed software.',
    keyAspects: [
      'Well-equipped laboratories matching curriculum and beyond-syllabus needs',
      'Equipment calibration, maintenance logs, and stock registers',
      'Laboratory safety equipment (fire extinguishers, first aid, earthing)',
      'Technical supporting staff qualification and competence',
      'High-speed internet bandwidth and computing equipment availability'
    ],
    requiredDocuments: [
      'Dead stock registers, purchase invoices, and calibration records',
      'Logbooks of laboratory utilization and experiments conducted',
      'Licensed software agreements and open-source tool documentation',
      'Service books and qualification certificates of laboratory assistants'
    ],
    evaluationGuidelines: 'Physical inspection during peer visit; check if students independently perform practicals and verify software licenses.'
  },
  {
    id: 7,
    number: 7,
    title: 'Continuous Improvement',
    tier1Marks: 50,
    tier2Marks: 75,
    description: 'Action taken on PO/PSO attainment gaps, improvement in teaching-learning, placement, academic performance, and institutional continuous quality improvement (CQI).',
    keyAspects: [
      'Actions taken based on results of evaluation of each PO & PSO',
      'Improvement in success index of students over 3 cycles',
      'Improvement in placement percentage, average CTC, and higher education',
      'Improvement in faculty publications, R&D funding, and consultancy'
    ],
    requiredDocuments: [
      'Departmental CQI audit reports with before-and-after metrics',
      'Minutes of Programme Assessment Committee (PAC) reviewing attainment gaps',
      'Evidence of remedial workshops, expert lectures, and bridge courses held',
      'Year-on-year comparative trend graphs for all PO attainments'
    ],
    evaluationGuidelines: 'Crucial for accreditation duration. Peer team checks whether the institution actually acted upon past gaps or just calculated numbers on paper.'
  },
  {
    id: 8,
    number: 8,
    title: 'First Year Academics',
    tier1Marks: 50,
    tier2Marks: 50,
    description: 'First-year Student-Faculty Ratio, faculty qualifications, teaching-learning in common courses, and attainment of course outcomes in 1st year.',
    keyAspects: [
      'First-year Student-Faculty Ratio (SFR)',
      'Qualification of faculty teaching basic sciences and engineering sciences',
      'First-year academic performance and pass percentage',
      'Attainment of First-Year Course Outcomes (Maths, Physics, Chem, Basic Engg)'
    ],
    requiredDocuments: [
      'First-year faculty list with appointment and salary records',
      'First-year course files, question papers, and CO attainment sheets',
      'Induction program reports and mentor-mentee records for freshers',
      'Results analysis of first-year university examinations'
    ],
    evaluationGuidelines: 'Assesses foundational preparation; checks basic science faculty retention and mentoring systems.'
  },
  {
    id: 9,
    number: 9,
    title: 'Student Support Systems',
    tier1Marks: 50,
    tier2Marks: 50,
    description: 'Mentoring system, feedback collection and corrective actions, career guidance, co-curricular and extra-curricular facilities, and alumni network.',
    keyAspects: [
      'Mentoring system (student-to-faculty mentor ratio and meeting records)',
      'Feedback collection (facilities, teaching) and actionable redressal',
      'Training & Placement cell activities, gate coaching, and soft skills training',
      'Student participation in hackathons, sports, cultural events, and clubs'
    ],
    requiredDocuments: [
      'Mentor-mentee record books with counselling logs and parent interactions',
      'Action Taken Reports (ATR) on student feedback',
      'Certificates and awards won by students in national/international competitions',
      'Alumni association registration certificate and meet records'
    ],
    evaluationGuidelines: 'Focuses on student-centric ecosystem; peer team interviews current students and alumni separately without management present.'
  },
  {
    id: 10,
    number: 10,
    title: 'Governance, Institutional Support and Financial Resources',
    tier1Marks: 120,
    tier2Marks: 120,
    description: 'Institutional governance, decentralization, transparency, budget allocation, fund utilization, library resources, and administrative support.',
    keyAspects: [
      'Organization structure, Governing Body, Academic Council, and decentralization',
      'Strategic plan and deployment document',
      'Budget allocation vs actual expenditure for the department (Capital & Recurring)',
      'Library resources (e-journals, physical titles, DELNET, IEEE subscriptions)'
    ],
    requiredDocuments: [
      'Governing body meeting minutes and resolutions over past 3 years',
      'Audited financial balance sheets and utilization certificates',
      'Department budget sanction requests and expenditure ledgers',
      'Library accession registers, e-subscription licenses, and footfall logs'
    ],
    evaluationGuidelines: 'Examines institutional financial health, adequate recurring funding for departmental labs, and genuine autonomy of department heads.'
  }
];

export const DEFAULT_CHECKLIST: ChecklistItem[] = [
  {
    id: 'chk-1',
    category: 'Program Educational Objectives',
    title: 'Department Vision, Mission & PEO Formulations',
    description: 'Formulation process document, stakeholder feedback, and DAB/PAC approval minutes.',
    criterionNumber: 1,
    academicYear: '2025-26',
    responsiblePerson: 'HOD & NBA Coordinator',
    status: 'In Progress',
    lastUpdated: '2026-03-10',
    notes: 'Stakeholder surveys completed; PAC minutes compiled.'
  },
  {
    id: 'chk-2',
    category: 'Program Outcomes and PSOs',
    title: 'PSO Formulation & Correlation Matrix with POs',
    description: 'Formal statement of 2 to 4 Program Specific Outcomes with rationale and mapping.',
    criterionNumber: 1,
    academicYear: '2025-26',
    responsiblePerson: 'NBA Core Committee',
    status: 'Completed',
    lastUpdated: '2026-02-15',
    notes: '2 PSOs approved for Computer Engineering department.'
  },
  {
    id: 'chk-3',
    category: 'Course Outcomes',
    title: 'Course Outcomes (CO) Statements for all Subjects',
    description: 'Blooms-compliant CO statements (4 to 6 COs per course) signed by course coordinators.',
    criterionNumber: 3,
    academicYear: '2025-26',
    responsiblePerson: 'All Course Coordinators',
    status: 'In Progress',
    lastUpdated: '2026-03-12',
    notes: 'Odd semester verified; even semester under peer review.'
  },
  {
    id: 'chk-4',
    category: 'CO-PO mapping',
    title: 'CO-PO & CO-PSO Mapping Matrices with Justifications',
    description: 'Correlation matrices (levels 1, 2, 3) along with written justification for each mapping.',
    criterionNumber: 3,
    academicYear: '2025-26',
    responsiblePerson: 'Course Coordinators & DAC',
    status: 'In Progress',
    lastUpdated: '2026-03-01',
    notes: 'Mapping rationale templates issued to all faculty.'
  },
  {
    id: 'chk-5',
    category: 'Course files',
    title: 'Complete Course Files Preparation (Criterion 3 Exhibitions)',
    description: 'Syllabus, teaching plan, question papers with CO mapping, rubrics, sample answer scripts.',
    criterionNumber: 3,
    academicYear: '2025-26',
    responsiblePerson: 'All Faculty Members',
    status: 'Not Started',
    lastUpdated: '2026-02-01',
    notes: 'Audit scheduled by Internal Quality Assurance Cell (IQAC).'
  },
  {
    id: 'chk-6',
    category: 'Assessment records',
    title: 'Direct Assessment Tools & Rubrics Documentation',
    description: 'Internal assessment question papers, bloom analysis, assignments, and practical rubrics.',
    criterionNumber: 3,
    academicYear: '2025-26',
    responsiblePerson: 'Internal Examination Committee',
    status: 'In Progress',
    lastUpdated: '2026-03-05',
    notes: 'Rubrics created for Mini-project, Seminars, and Lab journals.'
  },
  {
    id: 'chk-7',
    category: 'Student performance analysis',
    title: 'Success Rate & API Calculations (Past 3 Batches)',
    description: 'Calculation sheets for Success Rate without backlogs and Academic Performance Index.',
    criterionNumber: 4,
    academicYear: '2024-25',
    responsiblePerson: 'Academic In-charge',
    status: 'Completed',
    lastUpdated: '2026-01-20',
    notes: 'Tables 4.1 to 4.5 filled with verified university grade cards.'
  },
  {
    id: 'chk-8',
    category: 'Faculty information',
    title: 'Student-Faculty Ratio (SFR) & Cadre Ratio Proofs',
    description: 'Form 5.1 data with appointment letters, salary statements, and Form 16 proofs.',
    criterionNumber: 5,
    academicYear: '2025-26',
    responsiblePerson: 'HOD & Establishment Section',
    status: 'Completed',
    lastUpdated: '2026-02-28',
    notes: 'Current SFR is 1:16.8 (Compliant for Tier-II and Tier-I).'
  },
  {
    id: 'chk-9',
    category: 'Laboratory information',
    title: 'Laboratory Stock Registers, Safety & Calibration Logs',
    description: 'Dead stock registers, annual maintenance contracts, safety equipment certifications.',
    criterionNumber: 6,
    academicYear: '2025-26',
    responsiblePerson: 'Lab In-charges & Technical Assistants',
    status: 'In Progress',
    lastUpdated: '2026-03-08',
    notes: 'Networking and AI labs upgraded with GPU servers.'
  },
  {
    id: 'chk-10',
    category: 'Research and development',
    title: 'Faculty Research Publications, Patents & Grants (Criterion 5.7)',
    description: 'SCI/Scopus publication reprints, patent grant/publication journals, and sanction letters.',
    criterionNumber: 5,
    academicYear: '2025-26',
    responsiblePerson: 'R&D Coordinator',
    status: 'In Progress',
    lastUpdated: '2026-03-14',
    notes: 'Compiled 24 Scopus papers for the current academic year.'
  },
  {
    id: 'chk-11',
    category: 'Student projects',
    title: 'Capstone Project Evaluation & Industrial Relevance Records',
    description: 'Project allocation process, guide allotment, mid-term rubrics, and project reports.',
    criterionNumber: 2,
    academicYear: '2025-26',
    responsiblePerson: 'Project Coordinator',
    status: 'In Progress',
    lastUpdated: '2026-03-11',
    notes: '38% projects developed in collaboration with local industries.'
  },
  {
    id: 'chk-12',
    category: 'Industry interaction',
    title: 'MoUs, Internships & Industrial Visits Documentation',
    description: 'Active MoUs with industry partners, student internship completion certificates.',
    criterionNumber: 2,
    academicYear: '2025-26',
    responsiblePerson: 'Industry-Institute Interaction Cell',
    status: 'In Progress',
    lastUpdated: '2026-02-18',
    notes: '8 active MoUs with tangible activities logged.'
  },
  {
    id: 'chk-13',
    category: 'Continuous improvement',
    title: 'Closing the Loop: Action Taken on PO/PSO Attainment Gaps',
    description: 'Annual CQI report identifying weak POs and specific pedagogical actions executed.',
    criterionNumber: 7,
    academicYear: '2024-25',
    responsiblePerson: 'PAC & HOD',
    status: 'Completed',
    lastUpdated: '2026-01-15',
    notes: 'Remedial coding bootcamps introduced to address PO3 gap.'
  },
  {
    id: 'chk-14',
    category: 'Departmental quality records',
    title: 'Minutes of DAC, PAC, and Department Faculty Meetings',
    description: 'Signed attendance sheets and minutes for all Department Advisory Committee sessions.',
    criterionNumber: 10,
    academicYear: '2025-26',
    responsiblePerson: 'Department Academic Secretary',
    status: 'Completed',
    lastUpdated: '2026-03-02',
    notes: 'All files indexed and hard-bound for peer visit.'
  }
];

export const OFFICIAL_RESOURCES: OfficialResource[] = [
  {
    id: 'res-1',
    title: 'National Board of Accreditation (NBA) Official Portal',
    description: 'Primary portal for accreditation announcements, e-NBA application system, guidelines, and accredited programs directory.',
    source: 'National Board of Accreditation, India',
    url: 'https://www.nbaind.org/',
    category: 'Portal',
    applicableFramework: 'All Engineering',
    documentDate: '2026',
    verifiedDate: '2026-03-15',
    isOfficial: true
  },
  {
    id: 'res-2',
    title: 'SAR Manual for Undergraduate Engineering Programs (Tier-I)',
    description: 'Comprehensive manual and Self Assessment Report guidelines for Autonomous Engineering Colleges and University Departments (Washington Accord compliant).',
    source: 'NBA Official Documentation',
    url: 'https://www.nbaind.org/tier-1-manual',
    category: 'Manual',
    applicableFramework: 'Tier-I (Autonomous/Univ)',
    documentDate: '2023 Revision',
    verifiedDate: '2026-03-10',
    isOfficial: true
  },
  {
    id: 'res-3',
    title: 'SAR Manual for Undergraduate Engineering Programs (Tier-II)',
    description: 'Comprehensive manual and Self Assessment Report guidelines for Non-Autonomous Engineering Colleges affiliated to State Technical Universities.',
    source: 'NBA Official Documentation',
    url: 'https://www.nbaind.org/tier-2-manual',
    category: 'Manual',
    applicableFramework: 'Tier-II (Affiliated)',
    documentDate: '2023 Revision',
    verifiedDate: '2026-03-10',
    isOfficial: true
  },
  {
    id: 'res-4',
    title: 'NBA Pre-Qualifier Format and Guidelines for UG Engineering',
    description: 'Essential pre-requisite compliance criteria (SFR, Ph.D. faculty, admissions, HOD qualification) required prior to SAR submission.',
    source: 'NBA E-Accreditation Portal',
    url: 'https://www.nbaind.org/pre-qualifiers',
    category: 'Format',
    applicableFramework: 'All Engineering',
    documentDate: '2024',
    verifiedDate: '2026-03-01',
    isOfficial: true
  },
  {
    id: 'res-5',
    title: 'AICTE Examination Reform Policy (OBE & Bloom’s Taxonomy Guidelines)',
    description: 'Official framework for designing Bloom’s Taxonomy compliant question papers, rubrics, and direct attainment assessments.',
    source: 'All India Council for Technical Education (AICTE)',
    url: 'https://www.aicte-india.org/',
    category: 'Guideline',
    applicableFramework: 'All Engineering',
    documentDate: 'AICTE Policy Document',
    verifiedDate: '2026-02-20',
    isOfficial: true
  },
  {
    id: 'res-6',
    title: 'International Engineering Alliance (IEA) Washington Accord Graduate Attributes',
    description: 'Foundational 12 Graduate Attributes and Professional Competencies benchmarked globally for reciprocal recognition of engineering degrees.',
    source: 'International Engineering Alliance (IEA)',
    url: 'https://www.ieagreements.org/accords/washington/',
    category: 'Guideline',
    applicableFramework: 'Tier-I (Autonomous/Univ)',
    documentDate: '2021 Update',
    verifiedDate: '2026-01-15',
    isOfficial: true
  }
];

export const FAQS_DATA: FAQItem[] = [
  {
    id: 'faq-1',
    category: 'NBA Basics',
    question: 'What is NBA accreditation and why is it important for engineering colleges?',
    answer: 'The National Board of Accreditation (NBA) is an autonomous body in India that accredits technical education programs (engineering, management, pharmacy, architecture). Unlike institutional accreditation (like NAAC), NBA evaluates specific programs at the department level. Accreditation ensures quality education, facilitates global mobility under the Washington Accord (Tier-I), enhances graduate employability, and is often required for government grants, autonomy, and research funding.',
    supportingReference: 'NBA General Information Brochure & Constitution',
    relatedQuestions: [
      'What is the difference between NBA and NAAC?',
      'What is the Washington Accord status of India?'
    ]
  },
  {
    id: 'faq-2',
    category: 'NBA Basics',
    question: 'What is the fundamental difference between NBA and NAAC?',
    answer: 'The primary difference lies in the unit of evaluation:\n• NBA focuses on Program-Level accreditation (e.g., B.Tech in Computer Science, B.Tech in Mechanical Engineering). It assesses Outcome-Based Education, curriculum delivery, and student competencies in that specific discipline against 1000 marks across 10 Criteria.\n• NAAC focuses on Institutional-Level accreditation (evaluating the college or university as an entire whole: infrastructure, central governance, overall faculty, financial health, library across all disciplines) on a 4-point CGPA grading scale (A++, A+, A, etc.).',
    supportingReference: 'NBA vs NAAC Comparative Guidance Document',
    relatedQuestions: [
      'Can an institution apply for NBA without NAAC?',
      'Which accreditation manual applies to affiliated vs autonomous colleges?'
    ]
  },
  {
    id: 'faq-3',
    category: 'NBA Basics',
    question: 'What is the difference between Tier-I and Tier-II accreditation?',
    answer: '• Tier-I: Applicable to Autonomous Engineering Institutions, Deemed-to-be Universities, University Departments, and Institutes of National Importance that design their own curricula and examination systems. Degrees from Tier-I accredited programs enjoy international mutual recognition under the Washington Accord.\n• Tier-II: Applicable to Non-Autonomous engineering colleges affiliated to a State or Central Technical University (e.g., VTU, Anna University, SPPU, AKTU). Here, curriculum is prescribed by the affiliating university, so Criterion 2 focuses on content delivery, gap identification, and beyond-syllabus activities.',
    supportingReference: 'NBA Tier-I & Tier-II SAR Manuals (Criterion 2)',
    relatedQuestions: [
      'How does mark distribution differ between Tier-I and Tier-II?',
      'Can Tier-II institutions get Washington Accord recognition?'
    ]
  },
  {
    id: 'faq-4',
    category: 'Outcome-Based Education',
    question: 'What is Outcome-Based Education (OBE)?',
    answer: 'Outcome-Based Education (OBE) is a student-centric educational philosophy where curriculum, teaching-learning processes, and assessment methods are structured around predetermined learning outcomes that students are expected to demonstrate upon graduation. Instead of focusing merely on input (hours taught, books in library) or process (lecturing), OBE measures what the student can actually DO (skills, knowledge, ethical reasoning, and problem-solving abilities).',
    supportingReference: 'AICTE / NBA OBE Guidelines',
    relatedQuestions: [
      'What are PEOs, POs, PSOs, and COs in the OBE hierarchy?',
      'How does Bloom’s Taxonomy integrate with Course Outcomes?'
    ]
  },
  {
    id: 'faq-5',
    category: 'Outcome-Based Education',
    question: 'What are PEOs, POs, PSOs, and Course Outcomes (COs)?',
    answer: 'The OBE hierarchy cascades from institutional vision to individual classroom topics:\n1. Vision & Mission: Institutional and Departmental long-term goals.\n2. Program Educational Objectives (PEOs): Broad career statements describing what graduates are expected to achieve 3 to 5 years after graduation.\n3. Program Outcomes (POs): 12 standardized Graduate Attributes defined by NBA/Washington Accord that students must possess at the time of graduation.\n4. Program Specific Outcomes (PSOs): 2 to 4 discipline-specific competencies defined by the department.\n5. Course Outcomes (COs): 4 to 6 measurable statements per course describing the specific knowledge and skills acquired upon course completion.',
    supportingReference: 'NBA SAR Criterion 1 & 3 Documentation',
    relatedQuestions: [
      'How should a course coordinator write measurable COs?',
      'What action verbs should be used for Bloom levels?'
    ]
  },
  {
    id: 'faq-6',
    category: 'CO-PO Mapping',
    question: 'How does CO-PO mapping work and what do levels 1, 2, and 3 mean?',
    answer: "CO-PO mapping correlates each Course Outcome to the relevant Program Outcomes based on instructional hours, assessment weightage, and skill relevance.\n• Level 1 (Slight / Low): Low correlation; the CO touches upon the PO superficially (e.g., ~5-15% of course content/assessment).\n• Level 2 (Moderate / Medium): Medium correlation; significant instruction and assessment dedicated to this PO (e.g., ~15-30% of content).\n• Level 3 (Substantial / High): Strong correlation; the CO directly fulfills the core essence of the PO (e.g., >30% instruction, key laboratory experiments, or major design project).\n• '-' or 0: No correlation.\nCrucially, NBA peer evaluators expect written justifications for all mappings of level 2 and 3.",
    supportingReference: 'NBA Criterion 3 Evaluation Guidelines',
    relatedQuestions: [
      'How do you write justifications for CO-PO mapping?',
      'Can all COs map to all 12 POs?'
    ]
  },
  {
    id: 'faq-7',
    category: 'Attainment Calculation',
    question: 'How is Course Outcome (CO) attainment calculated in practice?',
    answer: 'Institutions define their approved attainment rubric. A widely accepted approach is:\n1. Target Benchmark: The department fixes a threshold mark percentage (e.g., 60% marks in internal exams / SEE).\n2. Rubric Levels:\n   • Level 1: 50% to 59% of students score >= threshold mark.\n   • Level 2: 60% to 69% of students score >= threshold mark.\n   • Level 3: >= 70% of students score >= threshold mark.\n3. Direct Attainment = Weightage_CIE × CIE_Level + Weightage_SEE × SEE_Level (for example, 20% CIE + 80% SEE or 30% CIE + 70% SEE as per approved policy).\n4. Overall Course Attainment is evaluated against the set departmental target (e.g., Target 2.0 on a 3-point scale).',
    supportingReference: 'NBA Criterion 3 Guidelines & AICTE Examination Reform Policy',
    relatedQuestions: [
      'How is Program Outcome (PO) attainment calculated from CO attainment?',
      'What role do indirect assessments play in PO attainment?'
    ]
  },
  {
    id: 'faq-8',
    category: 'Continuous Improvement',
    question: 'What is Continuous Quality Improvement (CQI) and "Closing the Loop"?',
    answer: 'CQI is Criterion 7 (and the heart of NBA). It ensures that assessment is not just an arithmetic exercise but leads to actual quality enhancement. When PO/PSO attainment is calculated:\n1. Identify Gaps: Compare Achieved Attainment with Target Attainment for each PO.\n2. Gap Analysis: If PO3 (Design of Solutions) achieved is 1.7 against target 2.2, identify why (e.g., students struggled with system-level architecture in tests).\n3. Action Plan ("Closing the Loop"): Formulate specific interventions for the next batch (e.g., add 2 hands-on design assignments, organize an industry hackathon, upgrade simulation lab).\n4. Verification: Measure next year’s attainment to confirm improvement.',
    supportingReference: 'NBA Criterion 7 Manual (Continuous Improvement)',
    relatedQuestions: [
      'What evidence does the NBA visiting team seek for CQI?',
      'Who reviews the CQI action plans?'
    ]
  },
  {
    id: 'faq-9',
    category: 'Faculty Responsibilities',
    question: 'What is expected in a faculty Course File during an NBA visit?',
    answer: 'A comprehensive Course File must contain:\n1. Course syllabus, course objectives, and CO statements.\n2. Academic calendar and detailed lesson delivery execution plan.\n3. CO-PO mapping matrix with justification.\n4. Internal examination question papers with mapped COs and Bloom levels.\n5. Scheme of evaluation and rubrics for assignments/lab/projects.\n6. Sample student answer sheets (best, average, weak categories).\n7. Result analysis and student marks distribution.\n8. CO attainment calculation sheet.\n9. Action taken / pedagogical modifications based on previous year’s attainment.',
    supportingReference: 'NBA Course File Exhibition Checklist',
    relatedQuestions: [
      'How many sample answer books must be retained?',
      'What is the role of the Course Coordinator vs Module Coordinator?'
    ]
  },
  {
    id: 'faq-10',
    category: 'Accreditation Process',
    question: 'What are the possible accreditation outcomes awarded by the NBA?',
    answer: 'Based on the evaluation of the Self Assessment Report and the 3-day on-site peer committee audit, NBA awards:\n1. Accredited for 6 Years (Full Accreditation): Meets all stringent requirements, typically >= 750 marks out of 1000, with minimum 60% in each criterion, no significant deficiencies.\n2. Accredited for 3 Years (Provisional Accreditation): Typically >= 600 marks out of 1000, with no severe deficiency in core criteria (Faculty, Labs, Curriculum).\n3. Not Accredited: < 600 marks or major deficiencies (e.g., student-faculty ratio worse than 1:25, inadequate Ph.D. cadre, lack of lab infrastructure).',
    supportingReference: 'NBA Guidelines on Decision Making (EAC Regulations)',
    relatedQuestions: [
      'What are Weaknesses vs Deficiencies vs Concerns in an NBA report?',
      'What is the compliance report submitted after 3 years?'
    ]
  }
];

export const SAMPLE_DBMS_COURSE = {
  courseCode: 'CS304',
  courseName: 'Database Management Systems',
  credits: 4,
  semester: '5th Semester B.Tech (Computer Engineering)',
  coStatements: [
    {
      code: 'CO1',
      description: 'Explain fundamental database concepts, relational data models, and entity-relationship architecture.',
      bloomsLevel: 'Understand (L2)' as const,
      targetAttainment: 2.0,
      mappings: { PO1: 3, PO2: 2, PO3: 1, PO5: 1, PO12: 1, PSO1: 2 }
    },
    {
      code: 'CO2',
      description: 'Formulate complex queries using Relational Algebra and Structured Query Language (SQL).',
      bloomsLevel: 'Apply (L3)' as const,
      targetAttainment: 2.2,
      mappings: { PO1: 3, PO2: 3, PO3: 2, PO5: 3, PO12: 2, PSO1: 3 }
    },
    {
      code: 'CO3',
      description: 'Apply relational database design theory and normalization techniques (1NF, 2NF, 3NF, BCNF) to eliminate redundancies.',
      bloomsLevel: 'Apply (L3)' as const,
      targetAttainment: 2.0,
      mappings: { PO1: 3, PO2: 3, PO3: 3, PO5: 2, PO12: 2, PSO1: 3 }
    },
    {
      code: 'CO4',
      description: 'Analyze transaction processing, ACID properties, serializability, and concurrency control protocols.',
      bloomsLevel: 'Analyze (L4)' as const,
      targetAttainment: 2.0,
      mappings: { PO1: 2, PO2: 3, PO3: 2, PO4: 2, PO12: 1, PSO1: 2 }
    },
    {
      code: 'CO5',
      description: 'Design and implement an end-to-end database application addressing real-world societal or organizational requirements.',
      bloomsLevel: 'Create (L6)' as const,
      targetAttainment: 2.4,
      mappings: { PO1: 2, PO2: 3, PO3: 3, PO4: 2, PO5: 3, PO6: 1, PO8: 1, PO9: 3, PO10: 2, PO11: 2, PO12: 2, PSO1: 3, PSO2: 3 }
    }
  ]
};
