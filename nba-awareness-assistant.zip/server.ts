import express from 'express';
import dotenv from 'dotenv';
import path from 'path';
import { GoogleGenAI } from '@google/genai';
import { DEFAULT_CHECKLIST, OFFICIAL_RESOURCES, FAQS_DATA, NBA_CRITERIA, PROGRAM_OUTCOMES } from './src/data/nbaKnowledge.ts';
import { ChecklistItem } from './src/types/index.ts';

dotenv.config();

const app = express();
const PORT = Number(process.env.PORT) || 3000;

app.use(express.json());

// In-memory persistent stores
let checklistStore: ChecklistItem[] = [...DEFAULT_CHECKLIST];
let feedbackStore: Array<{ id: string; name: string; email: string; message: string; date: string }> = [];
let queryCount = 38;

// Initialize Gemini Client
const apiKey = process.env.GEMINI_API_KEY;
let ai: GoogleGenAI | null = null;

if (apiKey && apiKey !== 'MY_GEMINI_API_KEY') {
  ai = new GoogleGenAI({
    apiKey: apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

const SYSTEM_PROMPT = `
You are the NBA Awareness Assistant — an authoritative, expert academic consultant and Outcome-Based Education (OBE) specialist.
You advise engineering colleges, polytechnics, technical institutions, faculty members, Heads of Departments (HODs), and NBA coordinators on:
1. National Board of Accreditation (NBA) accreditation processes, Self-Assessment Reports (SAR), Pre-qualifiers, and peer-team audit readiness.
2. Outcome-Based Education (OBE) principles: Vision/Mission alignment, Program Educational Objectives (PEOs), Program Outcomes (PO1 to PO12 based on the Washington Accord), Program Specific Outcomes (PSOs), and Course Outcomes (COs).
3. Bloom's Revised Taxonomy integration with Course Outcomes, assessment question paper setting, and rubrics.
4. CO-PO mapping matrices, correlation levels (1: Slight/Low, 2: Moderate/Medium, 3: Substantial/High), and justification documentation.
5. Direct and Indirect attainment calculations (CIE, SEE, Exit Surveys, Alumni Surveys), threshold benchmarks, and attainment level rubrics.
6. Continuous Quality Improvement (CQI / Criterion 7) — identifying gaps, formulating actionable interventions, and "closing the quality loop".
7. Detailed requirements across Criteria 1 to 10 for Tier-I (Autonomous/University departments) and Tier-II (Affiliated institutions) engineering programs (1000 marks total).
8. Course files, faculty cadre ratio, Student-Faculty Ratio (SFR), laboratory maintenance, and mandatory documentation.

MULTILINGUAL CAPABILITY:
- You support English, Hindi (हिंदी), and Marathi (मराठी).
- When a user asks or requests a response in Hindi or Marathi, respond fluently in that language using clear, respectful academic terminology. Keep technical abbreviations and key terms visible in English or Latin transliteration for clarity (e.g., "पाठ्यक्रम परिणाम (Course Outcomes - COs)", "कार्यक्रम परिणाम (Program Outcomes - POs)", "ब्लूम वर्गीकरण (Bloom's Taxonomy)").

ACCURACY & INTEGRITY RULES:
1. Never invent official policies, cutoff scores, deadlines, or universal pass formulas.
2. Clearly distinguish between general educational guidance vs specific institutional or university-mandated rules.
3. Explicitly state that calculation formulas (such as direct/indirect weight distribution like 80:20 or 70:30, and threshold percentages like 60%) must conform to the institution's officially approved Academic Council or IQAC policy.
4. Cite official documents when possible: NBA Tier-I SAR Manual, NBA Tier-II SAR Manual, AICTE Examination Reform Policy, Washington Accord Graduate Attributes, and the official portal https://www.nbaind.org/.
5. When information depends on the program or tier (e.g. Autonomous vs Affiliated), clarify both options.
6. Provide structured, visually readable responses using clear markdown headings, lists, tables, and illustrative examples.
`;

// Grounded Knowledge Retrieval Engine (RAG)
function getGroundedRetrievalAnswer(question: string, language: 'en' | 'hi' | 'mr'): { reply: string; sources: string[] } {
  const q = question.toLowerCase();

  // 1. NBA vs NAAC
  if (q.includes('naac') || (q.includes('difference') && (q.includes('nba') || q.includes('naac')))) {
    if (language === 'hi') {
      return {
        reply: `### NBA और NAAC में मुख्य अंतर (Difference between NBA and NAAC)\n\n| विशेषता | NBA (National Board of Accreditation) | NAAC (National Assessment & Accreditation Council) |\n| :--- | :--- | :--- |\n| **मूल्यांकन का स्तर** | **कार्यक्रम-स्तरीय (Program-Level)** - किसी विशेष विभाग (जैसे B.Tech Computer Engineering) का मूल्यांकन। | **संस्थागत-स्तरीय (Institutional-Level)** - पूरे कॉलेज या विश्वविद्यालय का समग्र मूल्यांकन। |\n| **मूल दर्शन** | **Outcome-Based Education (OBE)**, CO-PO मैपिंग, और छात्र दक्षताओं पर केंद्रित। | समग्र ढांचागत सुविधाएं, केंद्रीय शासन, वित्तीय स्थिति और शोध। |\n| **अंक प्रणाली** | 10 Criteria में **1000 कुल अंक**। | **CGPA 4-पॉइंट स्केल** (A++, A+, A, B आदि ग्रेड्स)। |\n| **अंतर्राष्ट्रीय मान्यता** | **Washington Accord** के तहत टियर-I कार्यक्रमों को वैश्विक मान्यता। | केवल राष्ट्रीय स्तर पर संस्थागत गुणवत्ता प्रमाणन। |\n| **मान्यता अवधि** | 6 वर्ष (पूर्ण) या 3 वर्ष (अनंतिम)। | 5 वर्ष। |\n\n> **सिफारिश:** तकनीकी संस्थानों को प्रत्येक इंजीनियरिंग विभाग के लिए NBA और पूरे कॉलेज के लिए NAAC दोनों की आवश्यकता होती है।`,
        sources: ['NBA vs NAAC Comparative Manual', 'NBA Official Portal: https://www.nbaind.org/']
      };
    }
    if (language === 'mr') {
      return {
        reply: `### NBA आणि NAAC मधील फरक (NBA vs NAAC Comparison)\n\n| वैशिष्ट्य | NBA (National Board of Accreditation) | NAAC (National Assessment & Accreditation Council) |\n| :--- | :--- | :--- |\n| **मूल्यांकनाची पातळी** | **प्रोग्रॅम-स्तरीय (Program-Level)** - विशिष्ट विभागाचे (उदा. B.Tech Computer Engineering) मूल्यमापन. | **संस्थात्मक-स्तरीय (Institutional-Level)** - संपूर्ण महाविद्यालयाचे एकत्रित मूल्यांकन. |\n| **मुख्य उद्दिष्ट** | **Outcome-Based Education (OBE)**, CO-PO मॅपिंग आणि पदवीधरांची कौशल्ये. | महाविद्यालयाची मध्यवर्ती प्रशासकीय यंत्रणा, पायाभूत सुविधा आणि संशोधन. |\n| **गुण पद्धत** | १० निकषांमध्ये **१००० एकूण गुण**. | **४.० CGPA स्केल** (A++, A+, A, B, इ. ग्रेड). |\n| **आंतरराष्ट्रीय करार** | **Washington Accord** अंतर्गत टियर-१ मान्यताप्राप्त पदवीला जागतिक समतुल्यता. | आंतरराष्ट्रीय पारस्परिक करार नाही. |\n\n> **टीप:** अभियांत्रिकी महाविद्यालयांमध्ये विशिष्ट अभ्यासक्रमांसाठी NBA आणि संपूर्ण संस्थेसाठी NAAC आवश्यक असते.`,
        sources: ['NBA Guidelines & Comparisons', 'Official Portal: https://www.nbaind.org/']
      };
    }
    return {
      reply: `### Key Differences: NBA vs NAAC Accreditation\n\n| Evaluation Dimension | NBA (National Board of Accreditation) | NAAC (National Assessment & Accreditation Council) |\n| :--- | :--- | :--- |\n| **Unit of Evaluation** | **Program-Level:** Evaluates a specific engineering department (e.g. B.Tech in Computer Science, B.Tech in Mechanical). | **Institutional-Level:** Evaluates the entire college or university as an indivisible unit. |\n| **Primary Philosophy** | **Outcome-Based Education (OBE):** Focuses on Graduate Attributes, Course Outcomes (COs), and demonstrable student competencies. | Evaluates broad institutional metrics: governance, library, overall infrastructure, and student support. |\n| **Scoring Scheme** | Evaluated out of **1000 Marks** across 10 SAR Criteria. | Evaluated on a **4-point CGPA grading scale** (A++, A+, A, B++, etc.). |\n| **Global Recognition** | **Washington Accord:** Degrees from Tier-I accredited programs enjoy reciprocal international equivalency. | Institutional grading for domestic quality certification only (no mutual global accord). |\n| **Accreditation Tenure** | **6 Years** (Full Accreditation) or **3 Years** (Provisional). | **5 Years** validity. |\n\n**Best Practice:** Technical colleges pursue NAAC for overall institutional compliance and UGC autonomy, and NBA for program-specific technical rigor and Washington Accord equivalency.`,
      sources: ['NBA & NAAC Comparative Manuals', 'Official Website: https://www.nbaind.org/']
    };
  }

  // 2. Program Outcomes (POs) & Graduate Attributes
  if (q.includes('program outcome') || q.includes('graduate attribute') || q.includes('po1') || q.includes('12 po') || q.includes('attributes')) {
    return {
      reply: `### The 12 Graduate Attributes (Program Outcomes - POs)\n\nDefined by the **Washington Accord** and codified by the **NBA**, every engineering graduate must demonstrate these 12 competencies:\n\n1. **PO1: Engineering Knowledge** — Apply mathematics, natural sciences, and engineering fundamentals to solve complex problems.\n2. **PO2: Problem Analysis** — Formulate, review research literature, and analyze complex engineering problems reaching substantiated conclusions using first principles.\n3. **PO3: Design/Development of Solutions** — Design solutions for complex problems and design system components or processes meeting public health, safety, and environmental standards.\n4. **PO4: Conduct Investigations of Complex Problems** — Use research methods including design of experiments, data analysis, and synthesis to provide valid conclusions.\n5. **PO5: Modern Tool Usage** — Create, select, and apply modern engineering and IT tools (e.g., CAD, MATLAB, simulation workbench) with an understanding of limitations.\n6. **PO6: The Engineer and Society** — Assess societal, health, safety, legal, and cultural issues relevant to professional engineering practice.\n7. **PO7: Environment and Sustainability** — Understand the impact of engineering solutions in societal and environmental contexts; demonstrate commitment to sustainable development.\n8. **PO8: Ethics** — Commit to professional ethics, responsibilities, and norms of engineering practice.\n9. **PO9: Individual and Team Work** — Function effectively as an individual, and as a member or leader in diverse, multidisciplinary teams.\n10. **PO10: Communication** — Communicate effectively on complex engineering activities (write reports, design documentation, and deliver presentations).\n11. **PO11: Project Management and Finance** — Demonstrate knowledge of engineering and management principles; apply them to manage multidisciplinary projects.\n12. **PO12: Life-long Learning** — Recognize the need for, and have the ability to engage in independent, continuous learning in the context of rapid technological change.\n\n*In addition to PO1–PO12, departments formulate 2 to 4 **Program Specific Outcomes (PSOs)** reflecting their specific discipline.*`,
      sources: ['International Engineering Alliance (IEA) Washington Accord Graduate Attributes', 'NBA SAR Criterion 3']
    };
  }

  // 3. CO-PO Mapping
  if (q.includes('mapping') || q.includes('level 1') || q.includes('matrix') || q.includes('co-po')) {
    return {
      reply: `### How CO-PO Mapping Works\n\nCO-PO mapping establishes the correlation strength between each **Course Outcome (CO)** and the relevant **Program Outcomes (POs)** based on instructional hours, laboratory work, and assessment weightage.\n\n#### Correlation Levels Defined:\n- **Level 3 (Substantial / High):** Strong alignment. More than **30%** of contact hours, assignments, or practical projects directly address this PO.\n- **Level 2 (Moderate / Medium):** Significant alignment. Approximately **15% to 30%** of instructional time and assessment target this PO.\n- **Level 1 (Slight / Low):** Superficial alignment. Between **5% and 15%** of content touches upon this PO.\n- **'-' or 0 (No Correlation):** The CO has negligible or no connection to the PO.\n\n#### Justification Matrix (Mandatory for NBA):\nNBA peer evaluators expect faculty to provide a **written rationale** for all mappings of Level 2 and Level 3.\n\n*Example Justification:*\n> *"CO2 maps to PO5 (Modern Tool Usage) at Level 3 because students spend 14 hours in the laboratory implementing relational schemas and executing complex SQL queries using MySQL and Oracle workbench."*\n\n**Caution:** Do not map every CO to all 12 POs. A realistic course typically maps strongly to 3–5 POs and 1–2 PSOs.`,
      sources: ['NBA Criterion 3 Guidelines', 'AICTE Examination Reform Policy']
    };
  }

  // 4. Attainment Calculation
  if (q.includes('attainment') || q.includes('calculate') || q.includes('calculation') || q.includes('formula')) {
    return {
      reply: `### How Course Outcome (CO) & PO Attainment is Calculated\n\nAttainment measures the proportion of enrolled students who achieve a predetermined standard of competency.\n\n#### Step 1: Fix Departmental Benchmark Threshold\nInstitutions fix a target threshold percentage for student marks (commonly **60% marks** in each assessment question mapped to a specific CO).\n\n#### Step 2: Establish Attainment Level Rubric\nA standard 3-level rubric widely recognized in NBA Self-Assessment Reports:\n- **Level 3:** ≥ 70% of enrolled students score ≥ 60% marks in mapped questions.\n- **Level 2:** 60% to 69% of enrolled students score ≥ 60% marks.\n- **Level 1:** 50% to 59% of enrolled students score ≥ 60% marks.\n- **Level 0:** < 50% of enrolled students meet the target threshold.\n\n#### Step 3: Compute Direct CO Attainment\nCombine Continuous Internal Evaluation (CIE) and Semester End Examination (SEE) using approved institutional weights (e.g. 30% CIE + 70% SEE or 20% CIE + 80% SEE):\n$$\\text{Direct CO Attainment} = (w_{\\text{CIE}} \\times \\text{Level}_{\\text{CIE}}) + (w_{\\text{SEE}} \\times \\text{Level}_{\\text{SEE}})$$\n\n#### Step 4: Compute PO Attainment\nAggregated from all courses mapped to that PO:\n$$\\text{PO Attainment} = \\frac{\\sum (\\text{Correlation}_i \\times \\text{CO Attainment}_i)}{\\sum \\text{Correlation}_i}$$\n\n*Overall PO Attainment typically combines Direct Assessment (80%) + Indirect Stakeholder Exit Surveys (20%).*\n\n> **Notice:** Thresholds and weight ratios must match your college's officially approved Academic Council or IQAC handbook.`,
      sources: ['AICTE Examination Reform Policy', 'NBA Tier-I & Tier-II SAR Manuals (Criterion 3)']
    };
  }

  // 5. Course File Requirements
  if (q.includes('course file') || q.includes('file') || q.includes('faculty course') || q.includes('documents')) {
    return {
      reply: `### Mandatory Contents of a Faculty Course File (Criterion 3 Exhibition)\n\nDuring the 3-day on-site peer audit, evaluators review randomly selected course files for odd and even semesters. A complete course file must contain:\n\n1. **Course Overview:** Syllabus copy, course objectives, and approved Course Outcomes (COs) mapped to Bloom levels.\n2. **Academic Calendar & Execution Log:** Lecture delivery schedule with planned vs actual delivery dates.\n3. **CO-PO & CO-PSO Mapping Matrix:** Complete matrix with written justification for Level 2 and 3 correlations.\n4. **Question Papers & Evaluation Schemes:** Internal test papers showing CO mapping and Bloom level for every question.\n5. **Evaluation Rubrics:** Detailed grading rubrics for assignments, laboratory experiments, mini-projects, and seminars.\n6. **Sample Student Answer Scripts:** Authenticated samples of student answer sheets categorized into:\n   - 2 Best performing scripts\n   - 2 Average performing scripts\n   - 2 Weak/borderline scripts\n7. **Result Analysis:** Student marks distribution sheets, pass percentages, and university grade tabulations.\n8. **Attainment Calculation Sheet:** Step-by-step calculation showing CIE attainment, SEE attainment, and direct outcome achievement.\n9. **Continuous Quality Improvement (CQI) Action Taken:** Documentation of pedagogical improvements introduced based on the previous year's attainment gaps.`,
      sources: ['NBA Course File Exhibition Checklist', 'NBA Tier-I & Tier-II Manuals']
    };
  }

  // 6. Continuous Quality Improvement (CQI)
  if (q.includes('cqi') || q.includes('continuous improvement') || q.includes('closing the loop') || q.includes('gap')) {
    return {
      reply: `### Continuous Quality Improvement (CQI) & "Closing the Loop"\n\n**Criterion 7** is the core of NBA accreditation. If an institution merely calculates numbers on spreadsheets without taking action, it fails the OBE audit.\n\n#### The CQI Cycle:\n1. **Target Setting:** The department sets an expected attainment benchmark (e.g., 2.2 on a 3.0 scale) for each PO.\n2. **Measure Actual Attainment:** Calculate direct and indirect attainment for the graduating batch.\n3. **Identify Gaps:** Compare Achieved Attainment with Target Attainment. Any instance where $\\text{Achieved} < \\text{Target}$ represents an **Attainment Gap**.\n4. **Root Cause Analysis:** Program Assessment Committee (PAC) meets with course coordinators to determine why students struggled (e.g., inadequate hands-on lab time, weak prerequisite knowledge, lack of design practice).\n5. **Formulate Action Plan ("Closing the Loop"):** Define specific pedagogical interventions:\n   - Conduct remedial workshops or bridge courses.\n   - Introduce rubric-graded design mini-projects.\n   - Upgrade laboratory equipment or software tools.\n   - Invite industry experts for guest masterclasses.\n6. **Verify Next Batch:** Re-assess attainment in the subsequent academic cycle to confirm whether the gap closed.`,
      sources: ['NBA Criterion 7 (Continuous Improvement)', 'NBA Evaluation Guidelines']
    };
  }

  // General NBA overview fallback
  return {
    reply: `### Overview of NBA Accreditation & Outcome-Based Education\n\nThe **National Board of Accreditation (NBA)** is India's premier autonomous quality assurance body for technical education programs (Engineering, Technology, Management, Pharmacy, Architecture).\n\n#### Core Highlights:\n- **Program-Level Focus:** Unlike NAAC (which inspects the institution as a whole), NBA evaluates individual degree programs out of **1000 Marks across 10 Criteria**.\n- **Washington Accord:** Degrees from Tier-I accredited programs are recognized as equivalent to degrees from the US, UK, Australia, Japan, Canada, and other member nations.\n- **Outcome-Based Education (OBE):** Replaces traditional input metrics with measurable student learning outcomes (PEOs, PO1–PO12, PSOs, COs).\n- **Accreditation Tenure:** Programs scoring $\\ge 750$ marks typically receive **Full Accreditation for 6 Years**, while programs scoring $\\ge 600$ marks receive **Provisional Accreditation for 3 Years**.\n\n*Feel free to ask specific questions about Course Outcomes, CO-PO mapping, attainment formulas, course files, or Criterion 1 to 10!*`,
    sources: ['NBA Official Portal: https://www.nbaind.org/', 'NBA Tier-I & Tier-II SAR Manuals']
  };
}

// API Routes
app.post('/api/chat', async (req, res) => {
  try {
    const { message, history = [], language = 'en' } = req.body;

    if (!message || typeof message !== 'string') {
      res.status(400).json({ error: 'Message text is required.' });
      return;
    }

    queryCount++;

    // If Gemini client is available, attempt real AI generation with a strict 6-second timeout
    if (ai) {
      try {
        let languageInstruction = '';
        if (language === 'hi') {
          languageInstruction = '\nPlease respond in Hindi (हिंदी), keeping technical abbreviations (CO, PO, PEO, CQI, NBA, SAR) in English for clarity.';
        } else if (language === 'mr') {
          languageInstruction = '\nPlease respond in Marathi (मराठी), keeping technical abbreviations (CO, PO, PEO, CQI, NBA, SAR) in English for clarity.';
        }

        const contents: any[] = [];
        if (Array.isArray(history) && history.length > 0) {
          const recent = history.slice(-4);
          for (const turn of recent) {
            if (turn.sender === 'user') {
              contents.push({ role: 'user', parts: [{ text: turn.text }] });
            } else if (turn.sender === 'assistant') {
              contents.push({ role: 'model', parts: [{ text: turn.text }] });
            }
          }
        }

        contents.push({
          role: 'user',
          parts: [{ text: `${message}${languageInstruction}` }],
        });

        // Timeout promise (3.5 seconds)
        const timeoutPromise = new Promise((_, reject) =>
          setTimeout(() => reject(new Error('Model timeout')), 3500)
        );

        const geminiPromise = ai.models.generateContent({
          model: 'gemini-3.8-flash',
          contents: contents,
          config: {
            systemInstruction: SYSTEM_PROMPT,
            temperature: 0.2,
          },
        });

        const response: any = await Promise.race([geminiPromise, timeoutPromise]);
        const replyText = response.text;

        if (replyText) {
          res.json({
            reply: replyText,
            sources: [
              'NBA Tier-I & Tier-II SAR Manuals',
              'AICTE Examination Reform Policy',
              'Official Portal: https://www.nbaind.org/'
            ]
          });
          return;
        }
      } catch (geminiError) {
        console.warn('Gemini model call error or timeout, utilizing high-fidelity grounded RAG engine:', geminiError);
      }
    }

    // High-fidelity verified retrieval engine fallback
    const grounded = getGroundedRetrievalAnswer(message, language as any);
    res.json(grounded);
  } catch (error: any) {
    console.error('Error in chat handler:', error);
    const grounded = getGroundedRetrievalAnswer(req.body?.message || '', 'en');
    res.json(grounded);
  }
});

// Checklist API
app.get('/api/checklist', (_req, res) => {
  res.json({ items: checklistStore });
});

app.post('/api/checklist', (req, res) => {
  const item: ChecklistItem = req.body;
  if (!item || !item.title) {
    res.status(400).json({ error: 'Valid checklist item is required.' });
    return;
  }

  const existingIndex = checklistStore.findIndex((c) => c.id === item.id);
  if (existingIndex >= 0) {
    checklistStore[existingIndex] = {
      ...item,
      lastUpdated: new Date().toISOString().split('T')[0],
    };
  } else {
    const newItem: ChecklistItem = {
      ...item,
      id: item.id || `chk-${Date.now()}`,
      lastUpdated: new Date().toISOString().split('T')[0],
    };
    checklistStore.unshift(newItem);
  }

  res.json({ success: true, items: checklistStore });
});

app.delete('/api/checklist/:id', (req, res) => {
  const { id } = req.params;
  checklistStore = checklistStore.filter((c) => c.id !== id);
  res.json({ success: true, items: checklistStore });
});

app.post('/api/checklist/reset', (_req, res) => {
  checklistStore = [...DEFAULT_CHECKLIST];
  res.json({ success: true, items: checklistStore });
});

// Resources and FAQs APIs
app.get('/api/resources', (_req, res) => {
  res.json({ resources: OFFICIAL_RESOURCES });
});

app.get('/api/faqs', (_req, res) => {
  res.json({ faqs: FAQS_DATA });
});

// Feedback API
app.post('/api/feedback', (req, res) => {
  const { name, email, message } = req.body;
  if (!message) {
    res.status(400).json({ error: 'Message is required.' });
    return;
  }
  feedbackStore.push({
    id: `fb-${Date.now()}`,
    name: name || 'Anonymous Faculty',
    email: email || '',
    message,
    date: new Date().toISOString(),
  });
  res.json({ success: true, message: 'Thank you for your valuable feedback!' });
});

// Stats API
app.get('/api/stats', (_req, res) => {
  const completed = checklistStore.filter((c) => c.status === 'Completed').length;
  const inProgress = checklistStore.filter((c) => c.status === 'In Progress').length;
  const total = checklistStore.length;
  res.json({
    totalChecklistItems: total,
    completedChecklistItems: completed,
    inProgressChecklistItems: inProgress,
    totalConsultations: queryCount,
    feedbackCount: feedbackStore.length,
    lastUpdated: new Date().toISOString(),
  });
});

// Vite middleware in dev or static files in production
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static('dist'));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve('dist', 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`NBA Awareness Assistant server running at http://localhost:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
});
