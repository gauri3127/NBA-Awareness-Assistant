# NBA Awareness Assistant

**AI-Powered Accreditation Guidance and Outcome-Based Education (OBE) Platform**

An intelligent, full-stack educational web application designed for engineering colleges, technical institutions, faculty members, Heads of Departments (HODs), and NBA coordinators. The platform provides authoritative guidance on National Board of Accreditation (NBA) compliance, the 10 Criteria of the Self-Assessment Report (SAR), Course Outcomes (COs), Program Outcomes (POs), Bloom's Revised Taxonomy, and Continuous Quality Improvement (CQI).

---

## Key Features

1. **AI Chatbot (Gemini API & Grounded RAG)**
   - Specialized in NBA Tier-I (Autonomous) and Tier-II (Affiliated) SAR guidelines.
   - Multilingual support: **English**, **Hindi (हिंदी)**, and **Marathi (मराठी)**.
   - Structured responses with markdown tables, formulas, lists, and official citations.
   - Copy-to-clipboard, conversation history persistence, and suggested starter questions.

2. **Outcome-Based Education (OBE) Learning Center**
   - Hierarchical exploration: Vision/Mission → PEOs (3–5 years) → POs (12 Graduate Attributes) → PSOs → COs.
   - Full interactive PO1–PO12 browser aligned with the International Engineering Alliance (IEA) Washington Accord.
   - Bloom’s Revised Taxonomy guide with actionable engineering action verbs (L1 to L6).
   - Real-world engineering course case study: Database Management Systems (CS304) with illustrative CO-PO mapping matrix.

3. **CO-PO Mapping and Attainment Calculator**
   - Configurable assessment weights (CIE % : SEE % split, e.g., 30:70 or 20:80).
   - Configurable rubric threshold levels (Level 1: ≥50%, Level 2: ≥60%, Level 3: ≥70%).
   - Selectable PO calculation formula: Weighted Matrix Multiplication vs Simple Average.
   - Student assessment marks entry and automatic direct/indirect attainment calculation.
   - Responsive visual SVG bar charts comparing Achieved vs Institutional Benchmark (2.0).
   - Automatic Gap Analysis and Continuous Quality Improvement (CQI / Criterion 7) Action Plan generator.
   - Complete data export to CSV.

4. **Departmental Documentation Checklist**
   - 14 standard exhibit categories covering PEOs, POs/PSOs, course files, laboratory logs, faculty cadre, student projects, and CQI minutes.
   - Add, edit, delete, and toggle document status (Not Started, In Progress, Completed).
   - Multi-parameter filtering by status, academic year, and category, with keyword search.
   - Real-time audit readiness completion progress bar.
   - Synchronized with persistent backend REST API (`/api/checklist`) and CSV export.

5. **Accreditation Criteria Explorer (Criteria 1–10)**
   - 1000-mark evaluation matrix for both Tier-I (Autonomous) and Tier-II (Affiliated) programs.
   - In-depth sub-criteria breakdown, mandatory exhibit checklist, and peer audit guidelines.
   - Interactive Self-Assessment Score Estimator: predicts 6-Year Full Accreditation (≥750 marks), 3-Year Provisional Accreditation (≥600 marks), or Not Accredited (<600 marks).
   - 3-Day Peer Team On-Site Audit schedule breakdown (Day 0 to Day 3) and Committee governance matrix (DAB, PAC, Course Coordinators).

6. **Official Resource Center & Searchable FAQs**
   - Direct, authentic links to the official portal (`https://www.nbaind.org/`), Tier-I & Tier-II SAR manuals, Pre-qualifier formats, and AICTE Examination Reform Policy.
   - Framework selector to identify whether Tier-I or Tier-II applies to your college.
   - Searchable, categorized FAQs with expandable answers and one-click transfer to AI Chat.

7. **Institutional Coordinator Administration Panel**
   - Protected coordinator workspace (PIN: `2026`).
   - Consultation metrics, documentation readiness analytics, and departmental notices publisher.

---

## Technology Stack

- **Frontend:** React 19, TypeScript, Tailwind CSS v4, Lucide React icons.
- **Backend Server:** Node.js, Express, tsx.
- **AI SDK:** `@google/genai` (Gemini 3.8 Flash model) with grounded Retrieval-Augmented Generation (RAG) fallback.
- **Build Tool:** Vite 8.

---

## Environment Variables

Configure the following in `.env` or your environment secrets:

```env
# Required for real-time Gemini AI chat completions:
GEMINI_API_KEY="your_gemini_api_key_here"

# Application hosting port (default 3000):
PORT=3000
```

---

## Installation & Local Development

1. Clone or open the repository.
2. Install dependencies:
   ```bash
   npm install
   ```
3. Start the development server (runs full-stack Express + Vite):
   ```bash
   npm run dev
   ```
4. Open your browser at `http://localhost:3000`.

---

## Build & Deployment Commands

- **Typecheck & Lint:**
  ```bash
  npm run lint
  ```
- **Production Build:**
  ```bash
  npm run build
  ```
- **Production Start:**
  ```bash
  npm start
  ```

---

## Educational Notice & Known Limitations

- **Institutional Discretion:** Attainment calculation formulas and rubrics in the calculator are educational models. Institutions must configure weights and thresholds according to their officially approved Academic Council or IQAC manual.
- **Official Policies:** Always verify the latest fee structures, SAR formats, and notification circulars directly on the official portal at [nbaind.org](https://www.nbaind.org/).
